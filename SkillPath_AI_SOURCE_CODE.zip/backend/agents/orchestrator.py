import uuid
import datetime
from typing import Dict, Any, List, Optional
from sqlalchemy.orm import Session

from app.models.models import (
    User, LearnerProfile, LearnerSkill, CareerRole, CareerRequirement,
    LearningResource, LearningRoadmap, RoadmapVersion, RoadmapItem,
    AssessmentAttempt, AgentExecution, Skill, MentorConversation
)
from backend.agents.context import LearnerContext
from backend.agents.profile_agent import ProfileAgent
from backend.agents.skill_agent import SkillAnalysisAgent
from backend.agents.career_agent import CareerAgent
from backend.agents.learning_agent import LearningAgent
from backend.agents.progress_agent import ProgressAgent
from backend.agents.mentor_agent import AIMentorAgent

class CustomOrchestrator:
    """
    Central Custom Orchestrator executing the Technical Architect blueprint.
    Operates over a shared Pydantic LearnerContext.
    Implements exact workflows for CAREER CHANGE and ASSESSMENT evaluation.
    Persists structured agent execution logs (input, output, status, error, duration).
    """

    def __init__(self, db: Session):
        self.db = db
        self.profile_agent = ProfileAgent()
        self.skill_agent = SkillAnalysisAgent()
        self.career_agent = CareerAgent()
        self.learning_agent = LearningAgent()
        self.progress_agent = ProgressAgent()
        self.mentor_agent = AIMentorAgent()

    def build_learner_context(self, user_id: int) -> LearnerContext:
        user = self.db.query(User).filter(User.id == user_id).first()
        profile = self.db.query(LearnerProfile).filter(LearnerProfile.user_id == user_id).first()
        learner_skills = self.db.query(LearnerSkill).filter(LearnerSkill.user_id == user_id).all()
        assessment_attempts = self.db.query(AssessmentAttempt).filter(AssessmentAttempt.user_id == user_id).all()

        target_career_title = "Unassigned"
        career_reqs = []
        if profile and profile.target_career_id:
            c_obj = self.db.query(CareerRole).filter(CareerRole.id == profile.target_career_id).first()
            if c_obj:
                target_career_title = c_obj.title
                for r in c_obj.requirements:
                    career_reqs.append({
                        "skill_name": r.skill.name if r.skill else "",
                        "required_proficiency": r.required_proficiency,
                        "importance": r.importance,
                        "prerequisites": r.prerequisite_skills or []
                    })

        formatted_skills = []
        for ls in learner_skills:
            formatted_skills.append({
                "skill_name": ls.skill.name if ls.skill else "Skill",
                "category": ls.skill.category if ls.skill else "General",
                "proficiency_level": ls.proficiency_level,
                "confidence_level": ls.confidence_level,
                "evidence_source": ls.evidence_source
            })

        formatted_attempts = []
        for at in assessment_attempts:
            formatted_attempts.append({
                "id": at.id,
                "skill_name": at.assessment.skill.name if at.assessment and at.assessment.skill else "Skill",
                "score": at.score,
                "passed": at.passed,
                "weak_concepts": at.weak_concepts or []
            })

        # Find active roadmap and current task
        active_roadmap = self.db.query(LearningRoadmap).filter(
            LearningRoadmap.user_id == user_id,
            LearningRoadmap.is_active == True
        ).first()

        active_items = []
        current_task = None
        if active_roadmap and active_roadmap.versions:
            latest_version = active_roadmap.versions[0]  # ordered by version_number desc
            for itm in latest_version.items:
                itm_dict = {
                    "id": itm.id,
                    "skill_name": itm.skill.name if itm.skill else "Skill",
                    "title": itm.title,
                    "learning_objective": itm.learning_objective,
                    "priority": itm.priority,
                    "difficulty": itm.difficulty,
                    "estimated_duration_days": itm.estimated_duration_days,
                    "status": itm.status,
                    "resource_url": itm.resource_url,
                    "practical_exercise": itm.practical_exercise,
                    "order_index": itm.order_index
                }
                active_items.append(itm_dict)
                if not current_task and itm.status in ["in_progress", "pending", "needs_revision"]:
                    current_task = itm_dict

        recent_attempt = formatted_attempts[-1] if formatted_attempts else None

        return LearnerContext(
            user_id=user_id,
            full_name=user.full_name if user else "Learner",
            email=user.email if user else "",
            education=profile.education if profile else "Undergraduate",
            institution=profile.institution if profile else "University",
            academic_year=profile.academic_year if profile else "3rd Year",
            experience_level=profile.experience_level if profile else "Beginner",
            preferred_learning_style=profile.preferred_learning_style if profile else "Hands-on",
            target_career_id=profile.target_career_id if profile else None,
            target_career_title=target_career_title,
            target_career_requirements=career_reqs,
            learner_skills=formatted_skills,
            assessment_attempts=formatted_attempts,
            active_roadmap_id=active_roadmap.id if active_roadmap else None,
            active_roadmap_items=active_items,
            current_task=current_task,
            recent_attempt=recent_attempt
        )

    def _persist_agent_log(self, context: LearnerContext, log_data: dict) -> AgentExecution:
        record = AgentExecution(
            user_id=context.user_id,
            workflow_id=context.workflow_id,
            agent_name=log_data.get("agent_name", "Agent"),
            responsibility=log_data.get("responsibility", ""),
            status=log_data.get("status", "success"),
            input_summary=log_data.get("input_summary", "Context processed"),
            output_summary=log_data.get("output_summary", "Completed"),
            full_payload=log_data,
            execution_time_ms=log_data.get("execution_time_ms", 0),
            timestamp=datetime.datetime.utcnow()
        )
        self.db.add(record)
        self.db.commit()
        self.db.refresh(record)
        return record

    def run_career_change_workflow(self, user_id: int, new_career_id: int) -> dict:
        """
        CAREER CHANGE WORKFLOW:
        Profile -> Skill Analysis -> Career -> Learning -> Save new roadmap version -> Mentor welcome.
        """
        workflow_id = f"wf-career-{uuid.uuid4().hex[:8]}"

        # Update profile target career in DB
        profile = self.db.query(LearnerProfile).filter(LearnerProfile.user_id == user_id).first()
        old_career_title = "None"
        if profile and profile.target_career_id:
            old_c = self.db.query(CareerRole).filter(CareerRole.id == profile.target_career_id).first()
            if old_c:
                old_career_title = old_c.title

        new_career = self.db.query(CareerRole).filter(CareerRole.id == new_career_id).first()
        new_career_title = new_career.title if new_career else "Target Career"

        if profile:
            profile.target_career_id = new_career_id
            self.db.commit()

        context = self.build_learner_context(user_id)
        context.workflow_id = workflow_id
        context.trigger = "CareerGoalChange"
        change_reason = f"Career goal transitioned from '{old_career_title}' to '{new_career_title}'. Recalibrated skill requirements and personalized learning roadmap."
        context.change_reason = change_reason

        logs = []

        # 1. Profile Agent
        l1 = self.profile_agent.run(context)
        logs.append(self._persist_agent_log(context, l1))

        # 2. Skill Analysis Agent
        l2 = self.skill_agent.run(context)
        logs.append(self._persist_agent_log(context, l2))

        # 3. Career Agent
        l3 = self.career_agent.run(context)
        logs.append(self._persist_agent_log(context, l3))

        # 4. Learning Agent
        l4 = self.learning_agent.run(context)
        logs.append(self._persist_agent_log(context, l4))

        # 5. Save new roadmap version (preserving previous versions!)
        new_version_num = self._save_new_roadmap_version(
            user_id=user_id,
            career_id=new_career_id,
            items=context.new_roadmap_items,
            trigger="CareerGoalChange",
            reason=change_reason
        )

        # Refresh active task for mentor
        context.current_task = context.new_roadmap_items[0] if context.new_roadmap_items else None

        # 6. Mentor Welcome
        l6 = self.mentor_agent.run(context)
        logs.append(self._persist_agent_log(context, l6))

        # Save mentor conversation in DB
        mentor_msg = MentorConversation(
            user_id=user_id,
            message=context.mentor_response or "Welcome to your new career roadmap!",
            sender="mentor",
            context_metadata={"trigger": "CareerGoalChange", "career": new_career_title, "version": new_version_num},
            timestamp=datetime.datetime.utcnow()
        )
        self.db.add(mentor_msg)
        self.db.commit()

        return {
            "workflow_id": workflow_id,
            "trigger": "CareerGoalChange",
            "status": "success",
            "from_career": old_career_title,
            "to_career": new_career_title,
            "new_readiness_score": context.career_readiness_score,
            "roadmap_version": new_version_num,
            "mentor_welcome": context.mentor_response,
            "agents_executed": [
                "Profile Agent", "Skill Analysis Agent", "Career Agent", "Learning Agent", "AI Mentor Agent"
            ],
            "executions": logs
        }

    def run_assessment_workflow(self, user_id: int, attempt_id: int) -> dict:
        """
        ASSESSMENT WORKFLOW:
        Progress -> Skill Analysis -> Career -> If reassessment is needed, Learning creates a new roadmap version -> Mentor feedback.
        """
        workflow_id = f"wf-assess-{uuid.uuid4().hex[:8]}"

        attempt = self.db.query(AssessmentAttempt).filter(AssessmentAttempt.id == attempt_id).first()
        if not attempt:
            return {"status": "error", "message": "Assessment attempt not found"}

        context = self.build_learner_context(user_id)
        context.workflow_id = workflow_id
        context.trigger = "AssessmentEvaluation"

        skill_obj = attempt.assessment.skill if attempt.assessment else None
        skill_name = skill_obj.name if skill_obj else "Skill"

        context.recent_attempt = {
            "id": attempt.id,
            "skill_name": skill_name,
            "score": attempt.score,
            "passed": attempt.passed,
            "weak_concepts": attempt.weak_concepts or []
        }

        logs = []

        # 1. Progress Agent
        l1 = self.progress_agent.run(context)
        logs.append(self._persist_agent_log(context, l1))

        # Update LearnerSkill in DB with empirical evidence
        self._update_learner_skill_evidence(user_id, skill_obj, attempt)

        # Refresh skills in context
        refreshed_skills = self.db.query(LearnerSkill).filter(LearnerSkill.user_id == user_id).all()
        context.learner_skills = [
            {
                "skill_name": ls.skill.name if ls.skill else "Skill",
                "category": ls.skill.category if ls.skill else "General",
                "proficiency_level": ls.proficiency_level,
                "confidence_level": ls.confidence_level,
                "evidence_source": ls.evidence_source
            }
            for ls in refreshed_skills
        ]

        # 2. Skill Analysis Agent
        l2 = self.skill_agent.run(context)
        logs.append(self._persist_agent_log(context, l2))

        # 3. Career Agent
        l3 = self.career_agent.run(context)
        logs.append(self._persist_agent_log(context, l3))

        # 4. If reassessment is needed, Learning creates a new roadmap version
        new_version_num = None
        if context.reassessment_needed:
            l4 = self.learning_agent.run(context)
            logs.append(self._persist_agent_log(context, l4))

            change_reason = (
                f"Assessment diagnostic in {skill_name} flagged score of {int(attempt.score)}%. "
                f"Reassessed and reprioritized curriculum with remedial modules focusing on: "
                f"{', '.join(attempt.weak_concepts or ['Fundamentals'])}."
            )
            new_version_num = self._save_new_roadmap_version(
                user_id=user_id,
                career_id=context.target_career_id or 1,
                items=context.new_roadmap_items,
                trigger="AssessmentAdaptation",
                reason=change_reason
            )
            context.current_task = context.new_roadmap_items[0] if context.new_roadmap_items else None

        # 5. Mentor Feedback
        l5 = self.mentor_agent.run(context)
        logs.append(self._persist_agent_log(context, l5))

        # Save mentor conversation in DB
        mentor_msg = MentorConversation(
            user_id=user_id,
            message=context.mentor_response or "Assessment feedback ready.",
            sender="mentor",
            context_metadata={
                "trigger": "AssessmentEvaluation",
                "skill": skill_name,
                "score": attempt.score,
                "reassessment_needed": context.reassessment_needed
            },
            timestamp=datetime.datetime.utcnow()
        )
        self.db.add(mentor_msg)
        self.db.commit()

        return {
            "workflow_id": workflow_id,
            "trigger": "AssessmentEvaluation",
            "status": "success",
            "skill_name": skill_name,
            "score": attempt.score,
            "reassessment_needed": context.reassessment_needed,
            "new_roadmap_version": new_version_num,
            "roadmap_version": new_version_num,
            "mentor_feedback": context.mentor_response,
            "agents_executed": [
                "Progress Agent", "Skill Analysis Agent", "Career Agent",
                *(["Learning Agent"] if context.reassessment_needed else []),
                "AI Mentor Agent"
            ],
            "executions": logs
        }

    def run_initial_onboarding_workflow(self, user_id: int) -> dict:
        """
        Initial Onboarding Workflow:
        Profile -> Skill Analysis -> Career -> Learning -> Save initial roadmap -> Mentor welcome.
        """
        workflow_id = f"wf-init-{uuid.uuid4().hex[:8]}"
        context = self.build_learner_context(user_id)
        context.workflow_id = workflow_id
        context.trigger = "InitialOnboarding"
        context.change_reason = "Initial personalized curriculum synthesis based on self-declared competencies."

        logs = []
        l1 = self.profile_agent.run(context)
        logs.append(self._persist_agent_log(context, l1))

        l2 = self.skill_agent.run(context)
        logs.append(self._persist_agent_log(context, l2))

        l3 = self.career_agent.run(context)
        logs.append(self._persist_agent_log(context, l3))

        l4 = self.learning_agent.run(context)
        logs.append(self._persist_agent_log(context, l4))

        new_version_num = self._save_new_roadmap_version(
            user_id=user_id,
            career_id=context.target_career_id or 1,
            items=context.new_roadmap_items,
            trigger="Initial",
            reason=context.change_reason
        )

        context.current_task = context.new_roadmap_items[0] if context.new_roadmap_items else None
        l5 = self.mentor_agent.run(context)
        logs.append(self._persist_agent_log(context, l5))

        mentor_msg = MentorConversation(
            user_id=user_id,
            message=context.mentor_response or "Welcome to SkillPath AI! Your roadmap is ready.",
            sender="mentor",
            context_metadata={"trigger": "InitialOnboarding", "version": new_version_num},
            timestamp=datetime.datetime.utcnow()
        )
        self.db.add(mentor_msg)
        self.db.commit()

        return {
            "workflow_id": workflow_id,
            "trigger": "InitialOnboarding",
            "status": "success",
            "readiness_score": context.career_readiness_score,
            "roadmap_version": new_version_num,
            "mentor_welcome": context.mentor_response,
            "agents_executed": [
                "Profile Agent", "Skill Analysis Agent", "Career Agent", "Learning Agent", "AI Mentor Agent"
            ],
            "executions": logs
        }

    def _update_learner_skill_evidence(self, user_id: int, skill_obj: Optional[Skill], attempt: AssessmentAttempt):
        if not skill_obj:
            return
        ls = self.db.query(LearnerSkill).filter(
            LearnerSkill.user_id == user_id,
            LearnerSkill.skill_id == skill_obj.id
        ).first()

        if not ls:
            ls = LearnerSkill(
                user_id=user_id,
                skill_id=skill_obj.id,
                proficiency_level="Beginner",
                evidence_source="Assessment",
                confidence_level=0.5
            )
            self.db.add(ls)

        if attempt.passed:
            ls.confidence_level = min(0.95, round(0.70 + (attempt.score / 100.0) * 0.25, 2))
            ls.evidence_source = f"Assessment Verified ({int(attempt.score)}%)"
            if attempt.score >= 85:
                ls.proficiency_level = "Advanced"
            else:
                ls.proficiency_level = "Intermediate"
        else:
            ls.confidence_level = min(0.60, round(0.30 + (attempt.score / 100.0) * 0.20, 2))
            ls.evidence_source = f"Assessment Deficit ({int(attempt.score)}%)"
            ls.proficiency_level = "Beginner"

        ls.last_assessed_date = datetime.datetime.utcnow()
        self.db.commit()

    def _save_new_roadmap_version(self, user_id: int, career_id: int, items: List[Dict[str, Any]], trigger: str, reason: str) -> int:
        roadmap = self.db.query(LearningRoadmap).filter(
            LearningRoadmap.user_id == user_id,
            LearningRoadmap.is_active == True
        ).first()

        if not roadmap:
            roadmap = LearningRoadmap(
                user_id=user_id,
                career_id=career_id,
                current_version=1,
                is_active=True
            )
            self.db.add(roadmap)
            self.db.flush()
            version_num = 1
        else:
            roadmap.career_id = career_id
            version_num = roadmap.current_version + 1
            roadmap.current_version = version_num

        version = RoadmapVersion(
            roadmap_id=roadmap.id,
            version_number=version_num,
            change_trigger=trigger,
            change_reason=reason,
            summary=f"Version {version_num} generated via {trigger} ({len(items)} learning modules)."
        )
        self.db.add(version)
        self.db.flush()

        skill_map = {s.name: s.id for s in self.db.query(Skill).all()}

        for idx, item in enumerate(items):
            s_name = item.get("skill_name")
            s_id = skill_map.get(s_name, 1)

            roadmap_item = RoadmapItem(
                roadmap_version_id=version.id,
                skill_id=s_id,
                title=item.get("title", f"Learn {s_name}"),
                learning_objective=item.get("learning_objective", ""),
                priority=item.get("priority", "High"),
                difficulty=item.get("difficulty", "Intermediate"),
                estimated_duration_days=item.get("estimated_duration_days", 7),
                status=item.get("status", "pending"),
                resource_url=item.get("resource_url"),
                practical_exercise=item.get("practical_exercise"),
                order_index=idx + 1
            )
            self.db.add(roadmap_item)

        self.db.commit()
        return version_num
