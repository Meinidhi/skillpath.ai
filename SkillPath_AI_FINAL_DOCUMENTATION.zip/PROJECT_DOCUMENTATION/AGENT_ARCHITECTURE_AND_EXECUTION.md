# SkillPath AI — Six-Agent Deep Dive & Orchestration Analysis

**Audit Date:** November 14, 2026  
**Auditor:** Technical Architecture & Agent Collaboration Reviewer  
**Evidence Source:** `PROJECT_DOCUMENTATION/evidence/agents/agent_execution_ledger.json` (58 verified execution logs)

---

## 1. Architectural Integrity of the Six Specialized Agents

SkillPath AI implements true multi-agent collaboration. Each agent is an independent Python class under `backend/agents/` that encapsulates specialized domain logic, consumes a shared Pydantic `LearnerContext`, mutates specific context attributes, and emits structured audit logs into SQLite.

| Agent Name | Class | Source File | Core Responsibility | Upstream Dependency | Downstream Consumer |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Profile Agent** | `ProfileAgent` | `profile_agent.py` | Ingests profile fields, evaluates completeness %, categorizes declared domains. | User Profile / DB | Skill Analysis Agent |
| **Skill Analysis Agent** | `SkillAnalysisAgent` | `skill_agent.py` | Calibrates empirical assessment evidence against self-declarations; sets confidence (0.0–1.0). | Profile Agent & Diagnostic Attempts | Career Agent |
| **Career Agent** | `CareerAgent` | `career_agent.py` | Computes transparent Readiness Score using `(Earned / Total Required) * 100`. | Skill Analysis Agent & Career Specs | Learning Agent |
| **Learning Agent** | `LearningAgent` | `learning_agent.py` | Sequences multi-week curriculum, assigns exercises, injects remedial modules on test deficit. | Career Agent Gaps & Progress Agent | CustomOrchestrator / DB |
| **Progress Agent** | `ProgressAgent` | `progress_agent.py` | Analyzes test scores, flags concept deficits (<65%), and triggers adaptive interventions. | Diagnostic Test Submissions | Learning Agent & Mentor |
| **AI Mentor Agent** | `AIMentorAgent` | `mentor_agent.py` | Generates contextual coaching, domain transition welcomes, and test feedback. | Learning Agent & Progress Agent | Frontend Chat / UI |

---

## 2. Agent Specifications Deep Dive

### 1. Profile Agent (`ProfileAgent` in `backend/agents/profile_agent.py`)
- **Responsibilities:** Validates mandatory academic and career fields, normalizes skill levels, flags missing profile attributes, and prepares structured `LearnerContext`.
- **Inputs:** `context.education`, `context.institution`, `context.target_career_id`, `context.learner_skills`.
- **Outputs:** Ingested profile summary, categorized skills by domain, and missing fields list.
- **Algorithm:** Iterates over declared skills, buckets by category (Frontend, Backend, AI/ML, etc.), evaluates presence of core academic credentials, and sets initial telemetry.

### 2. Skill Analysis Agent (`SkillAnalysisAgent` in `backend/agents/skill_agent.py`)
- **Responsibilities:** Calibrates skill confidence. Self-declared skills carry a baseline confidence of 0.35. Empirical assessment attempts calibrate confidence to 0.70–0.95 depending on score.
- **Inputs:** `context.learner_skills`, `context.assessment_attempts`.
- **Outputs:** `context.analyzed_skills`, `context.strengths` (proficiency $\ge$ Intermediate with confidence $\ge$ 0.6), `context.weaknesses` (proficiency $\le$ Beginner or test failure).
- **Algorithm:** Uses `RuleBasedProvider.evaluate_skills()`. Maps proficiency string to rank (Beginner=1, Intermediate=2, Advanced=3, Expert=4).

### 3. Career Agent (`CareerAgent` in `backend/agents/career_agent.py`)
- **Responsibilities:** Evaluates the learner's calibrated skills against target career requirements.
- **Inputs:** `context.target_career_requirements`, `context.analyzed_skills`.
- **Outputs:** `context.career_readiness_score`, `context.meeting_skills`, `context.underdeveloped_skills`, `context.missing_skills`, `context.critical_missing`.
- **Mathematical Formula:**
  $$\text{Readiness Score} = \left( \frac{\sum \text{Competency Earned for Skill } i}{\sum \text{Competency Required for Skill } i} \right) \times 100$$
  Where earned competency is weighted by empirical confidence: $\text{Earned} = \text{Rank} \times (0.5 + 0.5 \times \text{Confidence})$.

### 4. Learning Agent (`LearningAgent` in `backend/agents/learning_agent.py`)
- **Responsibilities:** Sequences a personalized multi-week learning roadmap. When triggered by a career change, generates full curriculum. When triggered by an assessment deficit (<65%), dynamically injects remedial modules ahead of existing items.
- **Inputs:** `context.critical_missing`, `context.missing_skills`, `context.underdeveloped_skills`, `context.reassessment_needed`, `context.recent_attempt`.
- **Outputs:** `context.new_roadmap_items` (ordered curriculum modules with titles, objectives, priority, duration, exercises, and resource links).
- **Algorithm:** Traverses prerequisite graphs using directed acyclic sequencing. Appends verified practical exercises (e.g. *"Build a JWT auth service"*, *"Write an asynchronous web scraper"*).

### 5. Progress Agent (`ProgressAgent` in `backend/agents/progress_agent.py`)
- **Responsibilities:** Evaluates test scores against the 65% mastery threshold. If score < 65%, flags `reassessment_needed=True`, extracts weak concepts (e.g. *Closures*, *Event Loop*), and instructs the Learning Agent to adapt.
- **Inputs:** `context.recent_attempt` (`score`, `passed`, `weak_concepts`).
- **Outputs:** `context.reassessment_needed` (boolean flag).
- **Boundary Verification:**
  - 40.0% $\rightarrow$ Deficit detected, `reassessment_needed=True` (PASS)
  - 60.0% $\rightarrow$ Deficit detected, `reassessment_needed=True` (PASS)
  - 64.0% $\rightarrow$ Deficit detected, `reassessment_needed=True` (PASS)
  - 65.0% $\rightarrow$ Mastery met, `reassessment_needed=False` (PASS)
  - 100.0% $\rightarrow$ Mastery met, `reassessment_needed=False` (PASS)

### 6. AI Mentor Agent (`AIMentorAgent` in `backend/agents/mentor_agent.py`)
- **Responsibilities:** Produces grounded, context-aware coaching responses.
- **Inputs:** `context.trigger`, `context.target_career_title`, `context.career_readiness_score`, `context.recent_attempt`, `context.current_task`.
- **Outputs:** `context.mentor_response` (rich markdown message citing real scores, specific concepts, and next steps).

---

## 3. Orchestrator Analysis (`CustomOrchestrator` in `backend/agents/orchestrator.py`)

1. **Context Initialization**: `build_learner_context(user_id)` hydrations real user records from SQLite.
2. **Structured Execution Order**:
   - **Career Change Workflow**: Profile Agent $\rightarrow$ Skill Analysis Agent $\rightarrow$ Career Agent $\rightarrow$ Learning Agent $\rightarrow$ Version Snapshot $\rightarrow$ AI Mentor Agent.
   - **Assessment Evaluation Workflow**: Progress Agent $\rightarrow$ Skill Evidence Calibration $\rightarrow$ Skill Analysis Agent $\rightarrow$ Career Agent $\rightarrow$ [If Reassessment Needed] Learning Agent $\rightarrow$ AI Mentor Agent.
3. **Execution Logging**: Every agent step logs execution time (ms), input summary, output summary, and status directly into `agent_executions` table in SQLite.
4. **No Direct Bypasses**: All agent invocations are managed exclusively by `CustomOrchestrator`.

---

## 4. Verified Agent Execution Evidence (Sample from SQLite Ledger)

The following records are extracted verbatim from `PROJECT_DOCUMENTATION/evidence/agents/agent_execution_ledger.json`:

| Log ID | Workflow ID | Agent Name | Execution Latency | Status | Input Summary | Output Summary |
| :---: | :--- | :--- | :---: | :---: | :--- | :--- |
| **58** | `wf-assess-35c822e1` | AI Mentor Agent | 1 ms | `success` | Context processed for Alex Chen (Career: Full Stack Developer) | Contextual guidance synthesized citing recent assessment score of 100%. |
| **57** | `wf-assess-35c822e1` | Career Agent | 2 ms | `success` | Matching 24 skills against requirements for Full Stack Developer | Evaluated career readiness for 'Full Stack Developer': 24.8% (Formula: Earned 8.5 / Required 34.0). |
| **56** | `wf-assess-35c822e1` | Skill Analysis Agent | 1 ms | `success` | Analyzing 4 skills for Alex Chen | Calibrated 4 skills across 3 domains. Strengths: 2, Weaknesses: 2. |
| **55** | `wf-assess-35c822e1` | Progress Agent | 1 ms | `success` | Evaluated assessment attempt for JavaScript (Score: 100.0%) | Assessment passed (100.0% >= 65%). No curriculum reassessment required. |
| **54** | `wf-assess-bc87e14d` | AI Mentor Agent | 1 ms | `success` | Context processed for Alex Chen (Career: Full Stack Developer) | Contextual guidance synthesized citing recent assessment score of 65%. |
| **53** | `wf-assess-bc87e14d` | Career Agent | 2 ms | `success` | Matching 24 skills against requirements for Full Stack Developer | Evaluated career readiness for 'Full Stack Developer': 24.8%. |
| **52** | `wf-assess-bc87e14d` | Skill Analysis Agent | 1 ms | `success` | Analyzing 4 skills for Alex Chen | Calibrated 4 skills across 3 domains. |
| **51** | `wf-assess-bc87e14d` | Progress Agent | 1 ms | `success` | Evaluated assessment attempt for JavaScript (Score: 65.0%) | Assessment passed (65.0% >= 65%). No curriculum reassessment required. |
| **50** | `wf-assess-9a3d4f12` | AI Mentor Agent | 1 ms | `success` | Context processed for Alex Chen (Career: Full Stack Developer) | Diagnostic assessment feedback synthesized. Weak concepts: Closures & Scope. |
| **49** | `wf-assess-9a3d4f12` | Learning Agent | 2 ms | `success` | Generating remedial curriculum adaptation for JavaScript failure | Injected 1 remedial module into roadmap focusing on: Closures & Scope. |
| **48** | `wf-assess-9a3d4f12` | Career Agent | 2 ms | `success` | Matching 24 skills against requirements for Full Stack Developer | Evaluated career readiness: 24.8%. |
| **47** | `wf-assess-9a3d4f12` | Skill Analysis Agent | 1 ms | `success` | Analyzing 4 skills for Alex Chen | Calibrated 4 skills across 3 domains. |
| **46** | `wf-assess-9a3d4f12` | Progress Agent | 1 ms | `success` | Evaluated assessment attempt for JavaScript (Score: 64.0%) | Flagged score deficit (64.0% < 65%). Reassessment required for weak concepts. |
| **45** | `wf-assess-e18d9f04` | AI Mentor Agent | 1 ms | `success` | Context processed for Alex Chen (Career: Full Stack Developer) | Diagnostic feedback synthesized for JavaScript (Score: 40.0%). |
| **44** | `wf-assess-e18d9f04` | Learning Agent | 2 ms | `success` | Generating remedial curriculum adaptation for JavaScript failure | Injected 1 remedial module into roadmap focusing on: Closures & Scope, Async/Await. |
| **43** | `wf-assess-e18d9f04` | Career Agent | 2 ms | `success` | Matching 24 skills against requirements for Full Stack Developer | Evaluated career readiness: 24.8%. |
| **42** | `wf-assess-e18d9f04` | Skill Analysis Agent | 1 ms | `success` | Analyzing 4 skills for Alex Chen | Calibrated 4 skills across 3 domains. |
| **41** | `wf-assess-e18d9f04` | Progress Agent | 1 ms | `success` | Evaluated assessment attempt for JavaScript (Score: 40.0%) | Flagged score deficit (40.0% < 65%). Reassessment required for weak concepts. |

*Full 58-entry ledger available in `PROJECT_DOCUMENTATION/evidence/agents/agent_execution_ledger.json`.*
