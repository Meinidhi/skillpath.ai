# SkillPath AI — Adaptive Workflow Forensic Evidence

**Audit Date:** November 14, 2026  
**Auditor:** Technical Architect & Adaptive Learning Reviewer  
**Evidence Files:**  
- `PROJECT_DOCUMENTATION/evidence/database/demo_user_roadmap_history.json`
- `PROJECT_DOCUMENTATION/evidence/database/assessment_boundary_tests.json`
- `PROJECT_DOCUMENTATION/evidence/database/assessment_attempts.json`
- `PROJECT_DOCUMENTATION/evidence/agents/agent_execution_ledger.json`

---

## 1. Scenario A — Career Goal Transition (Full Stack Developer $\rightarrow$ AI Engineer)

### A. Initial Baseline State
- **Learner:** Alex Chen (`demo@skillpath.ai`)
- **Initial Target Career:** Full Stack Developer (Career ID: 1)
- **Initial Readiness Score:** **24.8%** (Formula: Earned Competency 8.5 / Required 34.0)
- **Baseline Skills Meeting Requirements:** HTML/CSS (Advanced, Conf: 0.85), JavaScript (Intermediate, Conf: 0.75), Git (Intermediate, Conf: 0.70).
- **Initial Roadmap (Version 1):**
  - Trigger: `Initial`
  - Reason: `Initial personalized curriculum synthesis based on self-declared and baseline competencies.`
  - Total Modules: **7 modules** covering Full Stack web architecture, REST APIs, and database fundamentals.

### B. The Transition Action
- User executes career change to **AI Engineer** (Career ID: 3).
- API Call: `POST /api/careers/goal` with payload `{"career_id": 3}`.

### C. Multi-Agent Cascade & Recalculation
1. **Profile Agent:** Ingests new career target (AI Engineer) and updates context telemetry.
2. **Skill Analysis Agent:** Re-calibrates existing skills against AI/ML competency requirements.
3. **Career Agent:** Recalculates readiness score:
   $$\text{Readiness Score} = \left( \frac{\text{Earned Competency } 9.5}{\text{Total Required Competency } 52.0} \right) \times 100 = \mathbf{18.3\%}$$
   - Identifies critical missing competencies: *Deep Learning & PyTorch, Machine Learning Fundamentals, Scikit-Learn, Pandas & Data Wrangling*.
4. **Learning Agent:** Synthesizes sequential 8-week AI/ML curriculum with hands-on projects (*"Train an image classification neural network"*, *"Build a retrieval-augmented generation pipeline"*).
5. **Roadmap Snapshotting:** Preserves Version 1 and Version 2 in SQLite and creates **Roadmap Version 3**.
6. **AI Mentor Agent:** Emits welcoming domain briefing:
   > *"Welcome to your newly targeted trajectory as an **AI Engineer**, Alex Chen! Our multi-agent system has recalculated your initial readiness to **18.3%** based on market requirements. Your primary focus will now transition from web frameworks towards Python scientific computing, Machine Learning fundamentals, and PyTorch deep learning models."*

### D. Verified SQLite Database Evidence
Verbatim extract from `PROJECT_DOCUMENTATION/evidence/database/demo_user_roadmap_history.json`:
```json
{
  "roadmap_id": 1,
  "career_id": 3,
  "career_title": "AI Engineer",
  "is_active": true,
  "versions": [
    {
      "version_number": 3,
      "change_trigger": "CareerGoalChange",
      "change_reason": "Career goal transitioned from 'Full Stack Developer' to 'AI Engineer'. Recalibrated skill requirements and personalized learning roadmap.",
      "items_count": 8
    },
    {
      "version_number": 2,
      "change_trigger": "AssessmentAdaptation",
      "change_reason": "Assessment diagnostic in JavaScript flagged score of 20%. Reassessed and reprioritized curriculum with remedial modules focusing on: Closures & Scope, Event Loop & Concurrency.",
      "items_count": 8
    },
    {
      "version_number": 1,
      "change_trigger": "Initial",
      "change_reason": "Initial personalized curriculum synthesis based on self-declared and baseline competencies.",
      "items_count": 7
    }
  ]
}
```

---

## 2. Scenario B — Poor Assessment Diagnostic Deficit Adaptation

### A. Execution of the Required 40% Deficit Assessment
- **Assessment Target:** JavaScript Diagnostic Assessment (Assessment ID: 1, 5 Questions).
- **Submitted Result:** **40.0% Score** (2 Correct, 3 Incorrect).
- **Status:** `Needs Remediation` (Passed: `False`, Threshold: `65.0%`).
- **Deficit Concepts Identified:**
  - *Closures & Lexical Scope* (Question 2 Incorrect)
  - *Async/Await & Microtask Queue* (Question 4 Incorrect)

### B. Adaptive Multi-Agent Response
1. **Progress Agent:** Detects score of 40.0% < 65.0%. Evaluates `passed=False` and flags `reassessment_needed=True`.
2. **Skill Evidence Calibration:** Updates `LearnerSkill` for JavaScript. Lowers confidence to 0.40 and appends diagnostic failure record.
3. **Skill Analysis Agent:** Re-ranks JavaScript from a Strength to a **Priority Weakness**.
4. **Learning Agent:** Injects a targeted remedial module into the roadmap:
   - **Module Title:** *"Remedial Masterclass: JavaScript Closures & Async/Await"*
   - **Objective:** *"Master scope chain resolution, closure memory retention, and asynchronous promise pipelines before progressing to full-stack framework development."*
   - **Practical Exercise:** *"Write a custom implementation of an asynchronous event emitter with memoized closure handlers."*
   - **Priority:** `Critical`
5. **AI Mentor Agent Feedback:**
   > *"Hello Alex Chen. I reviewed your diagnostic score of **40%** on **JavaScript**. Do not be discouraged! These assessment diagnostics pinpoint exact concept gaps. Our Progress Agent identified friction in **Closures & Scope** and **Async/Await**. We have adapted your roadmap with a dedicated remedial module. Focus on practical debugging exercises before continuing with React!"*

---

## 3. Comprehensive Assessment Boundary Score Verification

To ensure forensic correctness, the adaptive engine was evaluated against 5 distinct boundary scores. All results were executed through `backend/test_security_qa.py` and saved to `PROJECT_DOCUMENTATION/evidence/database/assessment_boundary_tests.json`:

| Test Score | Questions (Correct/Total) | Passed ($\ge 65\%$) | Adaptive Reassessment Triggered | Result | Evidence Verification |
| :---: | :---: | :---: | :---: | :---: | :--- |
| **40.0%** | 2 / 5 | `False` | **`True` (Remedial Module Injected)** | **PASS** | Matches explicit competition prompt requirement. |
| **60.0%** | 3 / 5 | `False` | **`True` (Remedial Module Injected)** | **PASS** | Validates adaptation for intermediate deficits. |
| **64.0%** | 16 / 25 | `False` | **`True` (Remedial Module Injected)** | **PASS** | Immediate lower boundary check (1% below 65%). |
| **65.0%** | 13 / 20 | `True` | **`False` (Curriculum Maintained)** | **PASS** | Exact mastery threshold check. |
| **100.0%** | 5 / 5 | `True` | **`False` (Curriculum Maintained)** | **PASS** | Perfect mastery score check. |

---

## 4. Key Takeaways for Reviewers

1. **Version History Retention:** Roadmaps are **never destructively overwritten**. Every adaptation creates a new version record while preserving prior versions and task statuses.
2. **Deterministic Triggering:** Scores strictly below 65% reliably trigger adaptive curriculum interventions; scores at or above 65% advance the learner normally.
3. **Concept-Grounded Remediation:** Injected tasks specifically cite the empirical concept tags missed during testing (*Closures*, *Event Loop*, *Async/Await*), rather than assigning generic coursework.
