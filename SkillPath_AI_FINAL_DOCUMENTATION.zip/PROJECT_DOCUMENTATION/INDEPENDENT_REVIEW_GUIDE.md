# SkillPath AI — Independent Reviewer Handover Guide

**Target Audience:** Independent AI Auditors & Reviewers  
1. **GPT:** Overall independent technical and product auditor.  
2. **Claude Account 1:** Technical architecture and agent collaboration reviewer.  
3. **Claude Account 2:** QA, security and backend verification reviewer.  
4. **Gemini Pro:** Product strategy, UI/UX and competition readiness reviewer.  

---

## 1. Quick Start Instructions (Reproducing the Project from Scratch)

### Prerequisites
- Windows 11 (or macOS / Linux).
- Python 3.10+ (tested on Python 3.14.6).
- Node.js v18+ (tested on Node v24.15.0).
- SQLite3 (built into Python standard library).

### 1-Click Launch (Windows)
Double-click `start_all.bat` in the project root. This concurrently starts:
- FastAPI Backend: `http://127.0.0.1:8000`
- Vite Dev Server: `http://localhost:5173`

### Manual CLI Launch
**Backend:**
```bash
cd backend
python -m pip install -r requirements.txt
python -m uvicorn main:app --host 127.0.0.1 --port 8000
```

**Frontend:**
```bash
cd frontend
npm install
npm run dev
```

---

## 2. Reviewer Specialized Checklists

### Checklist for Claude Account 1 (Architecture & Multi-Agent Collaboration)
- [ ] Inspect `backend/agents/context.py` to verify the shared Pydantic `LearnerContext` definition.
- [ ] Inspect `backend/agents/orchestrator.py` to confirm that all 6 agents are invoked sequentially without direct UI bypasses.
- [ ] Verify that agent outputs mutate context fields and directly influence downstream agents (e.g. `SkillAnalysisAgent` confidence affects `CareerAgent` readiness; `CareerAgent` gaps determine `LearningAgent` modules).
- [ ] Inspect `backend/agents/rule_based_provider.py` to verify deterministic mathematical readiness scoring:
  $$\text{Readiness Score} = \left( \frac{\text{Earned Competency}}{\text{Total Required Competency}} \right) \times 100$$
- [ ] Confirm that 58 execution logs in `PROJECT_DOCUMENTATION/evidence/agents/agent_execution_ledger.json` show real timestamps, status, and input/output summaries.

### Checklist for Claude Account 2 (QA, Security & Backend Verification)
- [ ] Run `python backend/test_security_qa.py` to reproduce negative tests (salted PBKDF2 verification, tampered token rejection, expired token rejection).
- [ ] Verify assessment boundary conditions: scores < 65% (such as 40.0%, 60.0%, 64.0%) trigger adaptive interventions; scores $\ge$ 65% (65.0%, 100.0%) advance curriculum.
- [ ] Run `python backend/verify_full_system.py` to verify cross-tenant data isolation between Alice and Bob test accounts.
- [ ] Inspect `backend/app/models/models.py` and confirm that `RoadmapVersion` cascades from `LearningRoadmap` while preserving historical snapshots.

### Checklist for Gemini Pro (UI/UX, Product Strategy & Competition Presentation)
- [ ] Open `http://localhost:5173/` in your browser.
- [ ] Click **"Explore Demo as Alex Chen"** to test 1-click frictionless onboarding.
- [ ] Inspect the Dashboard command center, live Career Readiness gauge, and real-time Agent Activity ticker.
- [ ] Test **Scenario A (Switch to AI Engineer)** in Career Match: Observe instant readiness drop to 18.3% and Roadmap v3 generation.
- [ ] Test **Scenario B (20% Diagnostic Score)** in Assessments: Observe weak concept flags and remedial task injection in Roadmap v2.
- [ ] Inspect `DEMO_WALKTHROUGH.md` for the 30-second elevator pitch and 5-minute judge demonstration script.

### Checklist for GPT (Overall Technical & Product Audit)
- [ ] Inspect `PROJECT_DOCUMENTATION/REQUIREMENT_COMPLIANCE.md` to confirm all 11 core requirements are 100% compliant.
- [ ] Inspect `PROJECT_DOCUMENTATION/EVIDENCE_INDEX.md` and verify that all 24 evidence artifacts exist on disk.
- [ ] Verify that the application operates 100% locally with zero external LLM API dependencies or paid keys.
- [ ] Confirm production build succeeds: `cd frontend && npm run build` (644 modules transformed).

---

## 3. Automated Reproduction Commands

```bash
# Run workflow integration tests (Scenario A, Scenario B, Versioning):
python backend/test_workflows.py

# Run security, negative auth, and boundary score tests (40%, 60%, 64%, 65%, 100%):
python backend/test_security_qa.py

# Run multi-tenant data isolation and agent pipeline verification:
python backend/verify_full_system.py

# Export fresh database and agent evidence:
python backend/export_evidence.py

# Verify frontend production build:
cd frontend && npm run build
```
