import os
import subprocess
import re

md_path = r"D:\promptwars\PROJECT_DOCUMENTATION\PROGRESS_AUDIT.md"
html_path = r"D:\promptwars\PROJECT_DOCUMENTATION\reports\PROGRESS_AUDIT.html"
pdf_path = r"D:\promptwars\PROJECT_DOCUMENTATION\reports\PROGRESS_AUDIT.pdf"

with open(md_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

html_content = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>SkillPath AI - Comprehensive Project Progress & Technical Audit</title>
<style>
  body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    color: #1e293b;
    line-height: 1.6;
    margin: 40px auto;
    max-width: 900px;
    padding: 0 20px;
  }
  h1 { color: #0f172a; border-bottom: 2px solid #3b82f6; padding-bottom: 8px; margin-top: 24px; }
  h2 { color: #1e3a8a; border-bottom: 1px solid #e2e8f0; padding-bottom: 6px; margin-top: 28px; }
  h3 { color: #2563eb; margin-top: 20px; }
  h4 { color: #475569; margin-top: 16px; }
  table {
    border-collapse: collapse;
    width: 100%;
    margin: 20px 0;
    font-size: 14px;
  }
  th, td {
    border: 1px solid #cbd5e1;
    padding: 8px 12px;
    text-align: left;
  }
  th {
    background-color: #f1f5f9;
    font-weight: 600;
  }
  tr:nth-child(even) {
    background-color: #f8fafc;
  }
  code {
    background: #f1f5f9;
    padding: 2px 6px;
    border-radius: 4px;
    font-family: "Consolas", "Courier New", monospace;
    font-size: 13px;
    color: #0f172a;
  }
  pre {
    background: #0f172a;
    color: #f8fafc;
    padding: 12px;
    border-radius: 6px;
    overflow-x: auto;
    font-size: 13px;
  }
  pre code {
    background: transparent;
    color: #f8fafc;
    padding: 0;
  }
  blockquote {
    border-left: 4px solid #3b82f6;
    background: #eff6ff;
    margin: 16px 0;
    padding: 12px 16px;
    border-radius: 0 4px 4px 0;
  }
  hr {
    border: 0;
    border-top: 1px solid #e2e8f0;
    margin: 28px 0;
  }
  .badge-pass {
    background-color: #dcfce7;
    color: #166534;
    padding: 2px 8px;
    border-radius: 12px;
    font-weight: bold;
    font-size: 12px;
  }
  @media print {
    body { margin: 20px; }
    h1, h2 { page-break-after: avoid; }
    table { page-break-inside: avoid; }
  }
</style>
</head>
<body>
"""

in_table = False
in_code = False
code_buf = []

for line in lines:
    raw = line.rstrip()
    
    # Code blocks
    if raw.startswith("```"):
        if in_code:
            html_content += f"<pre><code>{''.join(code_buf)}</code></pre>\n"
            code_buf = []
            in_code = False
        else:
            in_code = True
        continue
    
    if in_code:
        code_buf.append(raw + "\n")
        continue

    # Tables
    if raw.startswith("|") and raw.endswith("|"):
        if "---" in raw:
            continue
        cells = [c.strip() for c in raw.split("|")[1:-1]]
        if not in_table:
            in_table = True
            html_content += "<table>\n<thead>\n<tr>\n"
            for c in cells:
                html_content += f"  <th>{c}</th>\n"
            html_content += "</tr>\n</thead>\n<tbody>\n"
        else:
            html_content += "<tr>\n"
            for c in cells:
                # bold
                c = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', c)
                c = re.sub(r'`(.*?)`', r'<code>\1</code>', c)
                html_content += f"  <td>{c}</td>\n"
            html_content += "</tr>\n"
        continue
    else:
        if in_table:
            html_content += "</tbody>\n</table>\n"
            in_table = False

    if not raw:
        continue

    # Headers
    if raw.startswith("# "):
        html_content += f"<h1>{raw[2:]}</h1>\n"
    elif raw.startswith("## "):
        html_content += f"<h2>{raw[3:]}</h2>\n"
    elif raw.startswith("### "):
        html_content += f"<h3>{raw[4:]}</h3>\n"
    elif raw.startswith("#### "):
        html_content += f"<h4>{raw[5:]}</h4>\n"
    elif raw.startswith("---"):
        html_content += "<hr/>\n"
    elif raw.startswith("> "):
        html_content += f"<blockquote>{raw[2:]}</blockquote>\n"
    elif raw.startswith("- ") or raw.startswith("* "):
        item = raw[2:]
        item = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', item)
        item = re.sub(r'`(.*?)`', r'<code>\1</code>', item)
        html_content += f"<li>{item}</li>\n"
    else:
        p = raw
        p = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', p)
        p = re.sub(r'`(.*?)`', r'<code>\1</code>', p)
        html_content += f"<p>{p}</p>\n"

if in_table:
    html_content += "</tbody>\n</table>\n"

html_content += """
</body>
</html>
"""

with open(html_path, "w", encoding="utf-8") as f:
    f.write(html_content)

print(f"Generated HTML: {html_path}")

edge_path = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
if os.path.exists(edge_path):
    cmd = [
        edge_path,
        "--headless",
        "--disable-gpu",
        "--no-pdf-header-footer",
        f"--print-to-pdf={pdf_path}",
        html_path
    ]
    res = subprocess.run(cmd, capture_output=True, text=True)
    if os.path.exists(pdf_path):
        print(f"Successfully generated PDF: {pdf_path} (Size: {os.path.getsize(pdf_path)} bytes)")
    else:
        print(f"Edge execution finished but PDF not found: {res.stderr}")
else:
    print("Edge not found at specified path.")
