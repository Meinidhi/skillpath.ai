import os
import shutil

src_dir = r"C:\Users\user\.gemini\antigravity\brain\ea1c562a-6e70-409b-af0e-3e12505acc60\.system_generated\logs\media"
dst_dir = r"D:\promptwars\PROJECT_DOCUMENTATION\evidence\screenshots"

os.makedirs(dst_dir, exist_ok=True)

mapping = {
    "step_2_media_0.png": "01_landing_page.png",
    "step_10_media_0.png": "02_auth_demo_modal.png",
    "step_22_media_0.png": "03_dashboard_view.png",
    "step_30_media_0.png": "04_career_match_fullstack.png",
    "step_49_media_0.png": "05_scenario_a_career_change_ai_engineer.png",
    "step_67_media_0.png": "06_assessment_catalogue.png",
    "step_69_media_0.png": "07_scenario_b_javascript_deficit_20pct.png",
    "step_80_media_0.png": "08_roadmap_versioning_and_remedial_task.png",
    "step_84_media_0.png": "09_roadmap_task_toggle_interaction.png",
    "step_86_media_0.png": "10_skill_analysis_view.png",
    "step_98_media_0.png": "11_learner_profile_view.png",
    "step_108_media_0.png": "12_agent_monitor_activity_ledger.png",
    "step_110_media_0.png": "13_ai_mentor_chat.png",
    "step_115_media_0.png": "14_resource_library.png",
    "step_117_media_0.png": "15_progress_analytics.png",
    "step_119_media_0.png": "16_settings_and_specs.png"
}

for src_name, dst_name in mapping.items():
    src_file = os.path.join(src_dir, src_name)
    dst_file = os.path.join(dst_dir, dst_name)
    if os.path.exists(src_file):
        shutil.copy2(src_file, dst_file)
        print(f"Copied {src_name} -> {dst_name} ({os.path.getsize(dst_file)} bytes)")
    else:
        print(f"Warning: {src_name} not found")

print("Screenshot curation completed successfully.")
