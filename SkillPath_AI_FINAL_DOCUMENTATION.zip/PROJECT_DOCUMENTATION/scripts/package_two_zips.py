import os
import zipfile

root_dir = r"D:\promptwars"
src_zip_path = os.path.join(root_dir, "SkillPath_AI_SOURCE_CODE.zip")
doc_zip_path = os.path.join(root_dir, "SkillPath_AI_FINAL_DOCUMENTATION.zip")

# Clean existing
for z in [src_zip_path, doc_zip_path]:
    if os.path.exists(z):
        os.remove(z)

exclude_dirs = {"node_modules", "dist", "__pycache__", ".git", ".pytest_cache", ".vite"}
exclude_exts = {".pyc", ".pyo", ".tmp"}

# -----------------------------------------------------------------------------
# 1. Package SkillPath_AI_SOURCE_CODE.zip
# -----------------------------------------------------------------------------
print("Packaging SkillPath_AI_SOURCE_CODE.zip...")
src_count = 0
src_bytes = 0

with zipfile.ZipFile(src_zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
    for dirpath, dirnames, filenames in os.walk(root_dir):
        dirnames[:] = [d for d in dirnames if d not in exclude_dirs]
        rel_dir = os.path.relpath(dirpath, root_dir)
        
        # Exclude PROJECT_DOCUMENTATION from source zip
        if rel_dir == "PROJECT_DOCUMENTATION" or rel_dir.startswith("PROJECT_DOCUMENTATION" + os.sep):
            continue
            
        for f in filenames:
            ext = os.path.splitext(f)[1].lower()
            if ext in exclude_exts or f.endswith(".zip"):
                continue
            if f in ["out.log", "err.log", "package_two_zips.py"]:
                continue
                
            abs_path = os.path.join(dirpath, f)
            arcname = os.path.relpath(abs_path, root_dir)
            zipf.write(abs_path, arcname)
            src_count += 1
            src_bytes += os.path.getsize(abs_path)

print(f"Source Code ZIP created: {src_count} files, {os.path.getsize(src_zip_path):,} bytes compressed.")

# -----------------------------------------------------------------------------
# 2. Package SkillPath_AI_FINAL_DOCUMENTATION.zip
# -----------------------------------------------------------------------------
print("Packaging SkillPath_AI_FINAL_DOCUMENTATION.zip...")
doc_count = 0
doc_bytes = 0

with zipfile.ZipFile(doc_zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
    doc_dir = os.path.join(root_dir, "PROJECT_DOCUMENTATION")
    for dirpath, dirnames, filenames in os.walk(doc_dir):
        dirnames[:] = [d for d in dirnames if d not in exclude_dirs]
        for f in filenames:
            ext = os.path.splitext(f)[1].lower()
            if ext in exclude_exts or f.endswith(".zip"):
                continue
            abs_path = os.path.join(dirpath, f)
            arcname = os.path.relpath(abs_path, root_dir)
            zipf.write(abs_path, arcname)
            doc_count += 1
            doc_bytes += os.path.getsize(abs_path)
            
    # Also add root PDF and presentation guides to doc zip
    root_extra_docs = [
        "SkillPath_AI_Final_Project_Audit.pdf",
        "DEMO_WALKTHROUGH.md",
        "PROJECT_STATUS.md",
        "README.md"
    ]
    for doc_f in root_extra_docs:
        p = os.path.join(root_dir, doc_f)
        if os.path.exists(p):
            zipf.write(p, doc_f)
            doc_count += 1

print(f"Documentation ZIP created: {doc_count} files, {os.path.getsize(doc_zip_path):,} bytes compressed.")

# Verify integrity
for z_name, z_path in [("Source Code", src_zip_path), ("Documentation", doc_zip_path)]:
    with zipfile.ZipFile(z_path, "r") as zf:
        bad = zf.testzip()
        if bad:
            print(f"ERROR: {z_name} zip has bad entry: {bad}")
        else:
            print(f"✓ {z_name} ZIP integrity: 100% OK (CRC-32 valid)")
