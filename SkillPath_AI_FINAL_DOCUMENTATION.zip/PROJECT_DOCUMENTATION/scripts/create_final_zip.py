import os
import zipfile

root_dir = r"D:\promptwars"
zip_path = os.path.join(root_dir, "SkillPath_AI_FINAL_HANDOVER.zip")

# Remove existing if any
if os.path.exists(zip_path):
    os.remove(zip_path)

exclude_dirs = {
    "node_modules",
    "dist",
    "__pycache__",
    ".git",
    ".pytest_cache",
    ".vite"
}

exclude_extensions = {
    ".pyc",
    ".pyo",
    ".log", # Exclude temporary root logs; evidence/logs are included
    ".tmp"
}

# Root files to exclude from root directory
root_exclude_files = {
    "SkillPath_AI_FINAL_HANDOVER.zip",
    "out.log",
    "err.log",
    "create_final_zip.py"
}

print(f"Packaging {zip_path}...")

file_count = 0
total_bytes = 0

with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
    for dirpath, dirnames, filenames in os.walk(root_dir):
        # Prune excluded directories in-place
        dirnames[:] = [d for d in dirnames if d not in exclude_dirs]
        
        for filename in filenames:
            file_ext = os.path.splitext(filename)[1].lower()
            rel_dir = os.path.relpath(dirpath, root_dir)
            
            # Check exclusions
            if filename in root_exclude_files:
                continue
            if file_ext in exclude_extensions and not ("evidence" in rel_dir):
                continue
            if "node_modules" in dirpath or "dist" in dirpath or "__pycache__" in dirpath:
                continue
                
            abs_path = os.path.join(dirpath, filename)
            arcname = os.path.relpath(abs_path, root_dir)
            
            zipf.write(abs_path, arcname)
            file_count += 1
            total_bytes += os.path.getsize(abs_path)

print(f"Successfully packaged {zip_path}:")
print(f"  - Total files included: {file_count}")
print(f"  - Uncompressed size: {total_bytes:,} bytes")
print(f"  - Compressed ZIP size: {os.path.getsize(zip_path):,} bytes")

# Verify ZIP can be read
with zipfile.ZipFile(zip_path, "r") as test_zip:
    bad_file = test_zip.testzip()
    if bad_file:
        print(f"Error in ZIP: {bad_file}")
    else:
        print("ZIP integrity check: 100% OK (Valid CRC-32 for all entries)")
