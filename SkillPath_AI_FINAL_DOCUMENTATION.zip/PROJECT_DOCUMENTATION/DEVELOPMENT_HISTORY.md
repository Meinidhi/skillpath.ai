# SkillPath AI — Development History & Technical Decisions

**Audit Date:** November 14, 2026  
**Auditor:** Lead Full-Stack Developer & Technical Implementation Owner  
**Platform:** SkillPath AI (PromptWars X RTC)

---

## 1. Chronological Engineering Phases

### Phase 1: Problem Analysis & Technical Architecture Baseline
- **Requirements Ingestion:** Analyzed the PromptWars X RTC requirements: personal profile collection, skill analysis, career matching, personalized roadmaps, curated resources, progress tracking, contextual AI Mentor, and adaptive learning workflows under strict Windows 11 / 8GB RAM / zero-cost constraints.
- **Blueprint Alignment:** Adopted Claude's technical specification: React 18 + TypeScript + Vite frontend; FastAPI + SQLAlchemy 2.0 (synchronous) + SQLite backend; 6 specialized Python agent classes (`ProfileAgent`, `SkillAnalysisAgent`, `CareerAgent`, `LearningAgent`, `ProgressAgent`, `AIMentorAgent`) orchestrated by `CustomOrchestrator` using a shared Pydantic `LearnerContext` and deterministic `RuleBasedProvider`.

### Phase 2: Database Schema Design & Seeding Engine
- **Models Created:** Developed 15 relational SQLAlchemy models establishing referential integrity, cascading version deletion, and audit logging.
- **Production Seeding:** Authored `backend/app/data/seed_data.py` populating 10 careers (Full Stack, Frontend, Backend, AI Engineer, Data Scientist, Data Analyst, Cybersecurity Analyst, Cloud Engineer, DevOps Engineer, UI/UX Designer), 24 skills, 60 requirements, 17 curated learning resources, and 4 diagnostic assessment banks with tagged MCQs.

### Phase 3: Six-Agent Intelligence Engine & Orchestration
- **Mathematical Modeling:** Implemented transparent Readiness Score formula `(Earned / Total Required) * 100` with confidence calibration (0.35 baseline self-declared vs. 0.70–0.95 empirical assessment scores).
- **Adaptive Triggers:** Engineered `run_career_change_workflow()` (Scenario A) and `run_assessment_workflow()` (Scenario B) with multi-version roadmap snapshotting (`RoadmapVersion`) preserving complete history across modifications.

### Phase 4: Frontend Development & UI Engineering
- **Component Architecture:** Built 14 modular, responsive views in React 18 / TypeScript, including Dashboard command center, interactive Roadmap with version selector, Career Match benchmark, diagnostic testing engine, and live Agent Activity Monitor.

### Phase 5: Dependency Diagnostics & Defect Resolutions
- **Issue 1: Rollup `parseAst` Missing Module Error:**
  - *Symptom:* `Error [ERR_MODULE_NOT_FOUND]: Cannot find module '.../rollup/parseAst'` during Vite build.
  - *Root Cause:* Network interruption during initial install corrupted `@rollup/rollup-win32-x64-msvc` on Node v24.15.0.
  - *Resolution:* Clean installation of `rollup@4.68.3` with matching native MSVC binaries.
- **Issue 2: Pydantic `email-validator` Missing C-Extension:**
  - *Symptom:* `ImportError: email-validator is not installed` on Python 3.14 on Windows.
  - *Resolution:* Replaced `EmailStr` with standard `str` regex validation in Pydantic schemas.
- **Issue 3: Vite Dev Server Babel Transform (`browserslist`):**
  - *Symptom:* Babel transformation error in `@babel/helper-compilation-targets` during Vite HMR.
  - *Resolution:* Installed `browserslist` as devDependency; Vite compiles in <700ms.

### Phase 6: Comprehensive Verification & Evidence Collection
- **Automated Workflows:** 7/7 checks passed in `backend/test_workflows.py`.
- **Security & Multi-Tenant Isolation:** 5/5 test suites passed in `backend/verify_full_system.py`.
- **Assessment Boundaries:** Executed explicit 40%, 60%, 64%, 65%, and 100% boundary evaluations in `backend/test_security_qa.py`.
- **Live Browser Walkthrough:** 119 sequential steps executed in headless browser verifying all 14 screens.
