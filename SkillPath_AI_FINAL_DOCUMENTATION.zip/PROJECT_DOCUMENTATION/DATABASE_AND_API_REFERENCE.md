# SkillPath AI — Database Schema & REST API Reference

**Audit Date:** November 14, 2026  
**Auditor:** Backend & Database Implementation Owner  
**Database:** SQLite (`skillpath.db`) via SQLAlchemy 2.0 ORM  
**API Engine:** FastAPI 0.162.7 with Pydantic v2 validation

---

## 1. Database Entity-Relationship Diagram

```mermaid
erDiagram
    USERS ||--|| LEARNER_PROFILES : has
    USERS ||--o{ LEARNER_SKILLS : tracks
    USERS ||--o{ LEARNING_ROADMAPS : owns
    USERS ||--o{ ASSESSMENT_ATTEMPTS : submits
    USERS ||--o{ MENTOR_CONVERSATIONS : chats
    USERS ||--o{ AGENT_EXECUTIONS : logs

    SKILLS ||--o{ LEARNER_SKILLS : relates
    SKILLS ||--o{ CAREER_REQUIREMENTS : defines
    SKILLS ||--o{ LEARNING_RESOURCES : contains
    SKILLS ||--o{ ASSESSMENTS : evaluates
    SKILLS ||--o{ ROADMAP_ITEMS : maps

    CAREER_ROLES ||--o{ CAREER_REQUIREMENTS : requires
    CAREER_ROLES ||--o{ LEARNING_ROADMAPS : targets
    CAREER_ROLES ||--o{ LEARNER_PROFILES : targets

    LEARNING_ROADMAPS ||--o{ ROADMAP_VERSIONS : versioned_as
    ROADMAP_VERSIONS ||--o{ ROADMAP_ITEMS : contains

    ASSESSMENTS ||--o{ ASSESSMENT_QUESTIONS : comprises
    ASSESSMENTS ||--o{ ASSESSMENT_ATTEMPTS : attempted_in

    USERS {
        int id PK
        string email UK
        string hashed_password
        string full_name
        boolean is_active
        datetime created_at
    }

    LEARNER_PROFILES {
        int id PK
        int user_id FK,UK
        string education
        string institution
        string academic_year
        string experience_level
        int target_career_id FK
        string preferred_learning_style
        json soft_skills
        json certifications
        json projects
    }

    SKILLS {
        int id PK
        string name UK
        string category
        text description
    }

    LEARNER_SKILLS {
        int id PK
        int user_id FK
        int skill_id FK
        string proficiency_level
        string evidence_source
        float confidence_level
        datetime last_assessed_date
    }

    CAREER_ROLES {
        int id PK
        string title UK
        text description
        string category
        string salary_range
        string growth_outlook
    }

    CAREER_REQUIREMENTS {
        int id PK
        int career_id FK
        int skill_id FK
        string required_proficiency
        string importance
        json prerequisite_skills
    }

    LEARNING_ROADMAPS {
        int id PK
        int user_id FK
        int career_id FK
        int current_version
        boolean is_active
    }

    ROADMAP_VERSIONS {
        int id PK
        int roadmap_id FK
        int version_number
        string change_trigger
        text change_reason
        text summary
    }

    ROADMAP_ITEMS {
        int id PK
        int roadmap_version_id FK
        int skill_id FK
        string title
        text learning_objective
        string priority
        string difficulty
        int estimated_duration_days
        string status
        string resource_url
        text practical_exercise
        int order_index
    }

    AGENT_EXECUTIONS {
        int id PK
        int user_id FK
        string workflow_id
        string agent_name
        string responsibility
        string status
        text input_summary
        text output_summary
        int execution_time_ms
        datetime timestamp
    }
```

---

## 2. Table Specifications Summary

1. **`users`**: Core credentials and multi-tenant user records. (Seeded demo: `demo@skillpath.ai`).
2. **`learner_profiles`**: One-to-one profile record holding education, academic tier, style, and portfolio.
3. **`skills`**: 24 production technical skills categorized by Frontend, Backend, AI/ML, Cloud, Data, and Core CS.
4. **`learner_skills`**: User competency evidence linking self-declarations and empirical assessment confidence scores.
5. **`career_roles`**: 10 production roles (Full Stack, AI Engineer, DevOps, Cybersecurity, Data Scientist, etc.).
6. **`career_requirements`**: 60 granular skill requirements mapping importance tiers (Critical, High, Medium) and target levels.
7. **`learning_resources`**: 17 verified external documentation links (MDN, freeCodeCamp, W3Schools, Python Docs, React Docs).
8. **`learning_roadmaps`**: Top-level user roadmap container with active flag and version tracking.
9. **`roadmap_versions`**: Multi-version snapshot history (v1, v2, v3...) with `change_trigger` and `change_reason`.
10. **`roadmap_items`**: Sequential actionable tasks, duration estimates, priority, status toggles, and practical exercises.
11. **`assessments`**: Diagnostic question suites mapped to specific skills.
12. **`assessment_questions`**: Multiple-choice diagnostic questions with concept tags and explanations.
13. **`assessment_attempts`**: Audit records of diagnostic test submissions with granular question scores and identified weak concepts.
14. **`mentor_conversations`**: Stored user-mentor dialogues grounded in learner state.
15. **`agent_executions`**: Comprehensive audit ledger of all 6 agents' runs with millisecond latency tracking.

---

## 3. Complete REST API Reference

| Endpoint | Method | Purpose | Request Schema | Response Schema | Auth Required | DB Operations |
| :--- | :---: | :--- | :--- | :--- | :---: | :--- |
| `/api/auth/register` | `POST` | Register a new user account | `UserRegisterRequest` | `TokenResponse` | No | Creates `User` and empty `LearnerProfile`. |
| `/api/auth/login` | `POST` | Authenticate with credentials | `OAuth2PasswordRequestForm` | `TokenResponse` | No | Verifies PBKDF2 hash, issues JWT. |
| `/api/auth/demo` | `POST` | 1-Click Competition Demo Login | None | `TokenResponse` | No | Fetches `demo@skillpath.ai`, issues JWT. |
| `/api/auth/me` | `GET` | Get current user identity | None | `UserResponse` | Yes | Reads `User` table. |
| `/api/profile` | `GET` | Get learner profile | None | `LearnerProfileResponse` | Yes | Joins `LearnerProfile` and `User`. |
| `/api/profile` | `PUT` | Update profile information | `ProfileUpdateRequest` | `LearnerProfileResponse` | Yes | Updates profile fields in SQLite. |
| `/api/skills` | `GET` | Get master skill taxonomy | None | `List[SkillResponse]` | No | Reads `skills` table. |
| `/api/skills/my` | `GET` | Get user's calibrated skills | None | `List[LearnerSkillResponse]`| Yes | Filters `learner_skills` by `user_id`. |
| `/api/skills/batch-update` | `POST` | Update learner skill levels | `List[SkillInput]` | `List[LearnerSkillResponse]`| Yes | Inserts/updates `learner_skills`. |
| `/api/skills/analysis` | `GET` | Calibrate skills & confidence | None | `SkillAnalysisResponse` | Yes | Runs `SkillAnalysisAgent` evaluation. |
| `/api/careers` | `GET` | Get catalogue of 10 career roles | None | `List[CareerRoleResponse]`| No | Reads `career_roles` table. |
| `/api/careers/{id}` | `GET` | Get role requirements | None | `CareerDetailResponse` | No | Reads role and its requirements. |
| `/api/careers/match/{id}` | `GET` | Calculate Readiness Score | None | `CareerMatchResponse` | Yes | Executes `CareerAgent` scoring. |
| `/api/careers/goal` | `POST` | **Scenario A: Career Goal Change**| `CareerGoalRequest` | `CareerGoalChangeResponse` | Yes | **Triggers Scenario A orchestrator cascade; synthesizes new roadmap version.** |
| `/api/roadmaps/current` | `GET` | Get active roadmap & tasks | None | `RoadmapResponse` | Yes | Reads active `RoadmapVersion` & items. |
| `/api/roadmaps/versions` | `GET` | Get roadmap version history | None | `List[RoadmapVersionResponse]`| Yes | Returns all preserved versions (v1, v2, v3). |
| `/api/roadmaps/items/{id}` | `PATCH` | Update task status | `StatusUpdateRequest` | `RoadmapItemResponse` | Yes | Updates task to completed/in_progress. |
| `/api/roadmaps/generate` | `POST` | Initial roadmap synthesis | None | `RoadmapResponse` | Yes | Runs initial onboarding workflow. |
| `/api/assessments` | `GET` | List available skill tests | None | `List[AssessmentResponse]` | No | Reads `assessments` catalogue. |
| `/api/assessments/{id}` | `GET` | Get test questions (sanitized) | None | `AssessmentDetailResponse` | Yes | Omits correct answers for integrity. |
| `/api/assessments/submit` | `POST` | **Scenario B: Submit Assessment** | `AssessmentSubmitRequest` | `AssessmentResultResponse` | Yes | **Backend grades answers, updates skill evidence, triggers adaptive remediation if <65%.** |
| `/api/assessments/history/my` | `GET` | Get learner test attempts | None | `List[AttemptResponse]` | Yes | Filters `assessment_attempts` by user. |
| `/api/resources` | `GET` | Search learning resources | `Optional[category, skill]` | `List[ResourceResponse]` | No | Reads `learning_resources` table. |
| `/api/mentor/chat` | `POST` | Contextual AI Mentor Chat | `MentorChatRequest` | `MentorChatResponse` | Yes | Executes `AIMentorAgent` over context. |
| `/api/mentor/history` | `GET` | Get conversation history | None | `List[MentorMessageResponse]`| Yes | Reads `mentor_conversations`. |
| `/api/agents/status` | `GET` | Real-time status of 6 agents | None | `List[AgentStatusResponse]` | No | Returns live agent health telemetry. |
| `/api/agents/executions` | `GET` | Audit ledger of executions | `Optional[limit]` | `List[AgentExecutionResponse]`| Yes | Reads `agent_executions` audit ledger. |
| `/api/progress/overview` | `GET` | Command Center telemetry | None | `ProgressOverviewResponse` | Yes | Aggregates readiness, tasks, and agents. |
| `/health` | `GET` | System health check | None | `{"status": "healthy"}` | No | Verifies DB engine connectivity. |
