# SkillPath AI — Complete Project File Inventory

**Audit Date:** November 14, 2026  
**Auditor:** Lead Full-Stack Developer & Technical Implementation Owner  
**Platform:** SkillPath AI (PromptWars X RTC)  
**Architecture:** 100% Local Multi-Agent Architecture (FastAPI + SQLAlchemy + SQLite + React 18 + TypeScript + Vite)

---

## 1. Project Directory Tree (Excluding `node_modules`, `dist`, `__pycache__`)

```text
D:\PROMPTWARS
│   .env.example
│   DEMO_WALKTHROUGH.md
│   PROJECT_STATUS.md
│   README.md
│   SkillPath_AI_Project_Progress_Audit.pdf
│   skillpath.db
│   start_all.bat
│   start_backend.bat
│   start_frontend.bat
│
├───backend
│   │   main.py
│   │   requirements.txt
│   │   test_security_qa.py
│   │   test_workflows.py
│   │   verify_full_system.py
│   │   export_evidence.py
│   │
│   ├───agents
│   │       career_agent.py
│   │       context.py
│   │       learning_agent.py
│   │       mentor_agent.py
│   │       orchestrator.py
│   │       profile_agent.py
│   │       progress_agent.py
│   │       rule_based_provider.py
│   │       skill_agent.py
│   │
│   └───app
│       ├───api
│       │       agents.py
│       │       assessments.py
│       │       auth.py
│       │       careers.py
│       │       deps.py
│       │       mentor.py
│       │       profile.py
│       │       progress.py
│       │       resources.py
│       │       roadmaps.py
│       │       skills.py
│       │
│       ├───core
│       │       config.py
│       │       database.py
│       │       init_db.py
│       │       security.py
│       │
│       ├───data
│       │       seed_data.py
│       │
│       ├───models
│       │       models.py
│       │
│       └───schemas
│               schemas.py
│
├───frontend
│   │   index.html
│   │   package.json
│   │   package-lock.json
│   │   tailwind.config.js
│   │   tsconfig.json
│   │   tsconfig.node.json
│   │   vite.config.ts
│   │
│   └───src
│       │   App.tsx
│       │   index.css
│       │   main.tsx
│       │
│       ├───components
│       │       Navbar.tsx
│       │
│       ├───context
│       │       AuthContext.tsx
│       │
│       ├───pages
│       │       AgentMonitorView.tsx
│       │       AIMentorView.tsx
│       │       AssessmentView.tsx
│       │       AuthModal.tsx
│       │       CareerExploreView.tsx
│       │       CareerMatchView.tsx
│       │       DashboardView.tsx
│       │       LandingPage.tsx
│       │       ProfileView.tsx
│       │       ProgressAnalyticsView.tsx
│       │       ResourceLibraryView.tsx
│       │       RoadmapView.tsx
│       │       SettingsView.tsx
│       │       SkillAnalysisView.tsx
│       │
│       ├───services
│       │       api.ts
│       │
│       └───types
│               index.ts
│
└───PROJECT_DOCUMENTATION
    │   ADAPTIVE_WORKFLOW_EVIDENCE.md
    │   AGENT_ARCHITECTURE_AND_EXECUTION.md
    │   BROWSER_VERIFICATION.md
    │   COMPLETE_FILE_INVENTORY.md
    │   DATABASE_AND_API_REFERENCE.md
    │   DEVELOPMENT_HISTORY.md
    │   EVIDENCE_INDEX.md
    │   FINAL_ARCHITECTURE.md
    │   FINAL_PROJECT_AUDIT.md
    │   INDEPENDENT_REVIEW_GUIDE.md
    │   PROGRESS_AUDIT.md
    │   REQUIREMENT_COMPLIANCE.md
    │   SECURITY_AND_QA_REPORT.md
    │   ZIP_CONTENTS_MANIFEST.md
    │
    ├───evidence
    │   ├───agents
    │   │       agent_execution_ledger.json
    │   │
    │   ├───database
    │   │       agent_executions.csv
    │   │       agent_executions.json
    │   │       assessment_attempts.csv
    │   │       assessment_attempts.json
    │   │       assessment_boundary_tests.json
    │   │       assessment_questions.csv
    │   │       assessment_questions.json
    │   │       assessments.csv
    │   │       assessments.json
    │   │       career_requirements.csv
    │   │       career_requirements.json
    │   │       career_roles.csv
    │   │       career_roles.json
    │   │       demo_user_roadmap_history.json
    │   │       learner_profiles.csv
    │   │       learner_profiles.json
    │   │       learner_skills.csv
    │   │       learner_skills.json
    │   │       learning_resources.csv
    │   │       learning_resources.json
    │   │       learning_roadmaps.csv
    │   │       learning_roadmaps.json
    │   │       mentor_conversations.csv
    │   │       mentor_conversations.json
    │   │       roadmap_items.csv
    │   │       roadmap_items.json
    │   │       roadmap_versions.csv
    │   │       roadmap_versions.json
    │   │       skills.csv
    │   │       skills.json
    │   │       users.csv
    │   │       users.json
    │   │
    │   ├───logs
    │   │       npm_build.log
    │   │       npm_ls.log
    │   │       security_and_qa_tests.log
    │   │       system_verification.log
    │   │       workflow_tests.log
    │   │
    │   ├───recordings
    │   │
    │   └───screenshots
    │           01_landing_page.png
    │           02_auth_demo_modal.png
    │           03_dashboard_view.png
    │           04_career_match_fullstack.png
    │           05_scenario_a_career_change_ai_engineer.png
    │           06_assessment_catalogue.png
    │           07_scenario_b_javascript_deficit_20pct.png
    │           08_roadmap_versioning_and_remedial_task.png
    │           09_roadmap_task_toggle_interaction.png
    │           10_skill_analysis_view.png
    │           11_learner_profile_view.png
    │           12_agent_monitor_activity_ledger.png
    │           13_ai_mentor_chat.png
    │           14_resource_library.png
    │           15_progress_analytics.png
    │           16_settings_and_specs.png
    │
    └───reports
            FINAL_PROJECT_AUDIT.pdf
            PROGRESS_AUDIT.pdf
            PROGRESS_AUDIT.html
            SkillPath_AI_Project_Progress_Audit.html
            SkillPath_AI_Project_Progress_Audit.pdf
```

---

## 2. File Metadata and Verification Inventory

| File Path | Purpose & Functionality | Dependencies | Origin / Status | Testing Status |
| :--- | :--- | :--- | :---: | :---: |
| `backend/main.py` | FastAPI application entrypoint with lifespan startup handlers (automatic SQLite seeding), CORS middleware, and router mounts. | `fastapi`, `uvicorn`, `app.core`, `app.api` | Created | Tested Live (`HTTP 200`) |
| `backend/app/core/config.py` | Configuration settings loader (JWT secret, algorithm HS256, SQLite path). | `pydantic_settings` / `pydantic` | Created | Tested |
| `backend/app/core/database.py` | SQLAlchemy 2.0 synchronous engine, sessionmaker, Base. | `sqlalchemy` | Created | Tested |
| `backend/app/core/security.py` | Cryptographic salted PBKDF2-HMAC-SHA256 password hashing and JWT token creation/decoding. | `hashlib`, `hmac`, `secrets`, `jwt` | Created | Tested (Negative & Positive) |
| `backend/app/core/init_db.py` | Idempotent database seeder loading 10 careers, 24 skills, 16 resources, 4 assessment suites, and demo account Alex Chen. | `sqlalchemy.orm`, `app.models`, `app.data` | Created | Tested |
| `backend/app/models/models.py` | 15 SQLAlchemy ORM models establishing relational constraints and cascading version preservation. | `sqlalchemy`, `sqlalchemy.orm` | Created | Tested |
| `backend/app/schemas/schemas.py` | Strict Pydantic v2 schemas validating request/response payloads across all endpoints. | `pydantic` | Created | Tested |
| `backend/app/data/seed_data.py` | Production software engineering skill taxonomies, career requirements, and tagged MCQ banks. | Python standard library | Created | Tested |
| `backend/agents/context.py` | Pydantic `LearnerContext` model shared across all six agents and CustomOrchestrator. | `pydantic`, `typing` | Created | Tested |
| `backend/agents/orchestrator.py` | `CustomOrchestrator` sequencing structured context across agents, saving roadmap versions, and logging executions. | `app.models`, `agents.*` | Created | Tested (100% Pass) |
| `backend/agents/profile_agent.py` | Normalizes profile attributes, calculates completeness score, and flags missing fields. | `agents.context` | Created | Tested |
| `backend/agents/skill_agent.py` | Synthesizes verified skills against empirical diagnostic test evidence, setting confidence levels. | `agents.context`, `agents.rule_based_provider` | Created | Tested |
| `backend/agents/career_agent.py` | Evaluates learner against career requirements using transparent mathematical formula `Earned / Total Required`. | `agents.context`, `agents.rule_based_provider` | Created | Tested |
| `backend/agents/learning_agent.py` | Sequences personalized multi-week learning roadmaps, links resources, and injects remedial modules. | `agents.context`, `agents.rule_based_provider` | Created | Tested |
| `backend/agents/progress_agent.py` | Analyzes test scores, detects concept deficits (<65%), and triggers adaptive interventions. | `agents.context` | Created | Tested (Boundary Scores) |
| `backend/agents/mentor_agent.py` | Generates contextual guidance grounded in stored telemetry, career transitions, and test diagnostic feedback. | `agents.context` | Created | Tested |
| `backend/agents/rule_based_provider.py` | Mathematical intelligence engine calculating weighted readiness, proficiency ranks, and coaching templates. | Python standard library | Created | Tested |
| `backend/app/api/*.py` (10 routers) | 10 REST routers: `auth.py`, `profile.py`, `skills.py`, `careers.py`, `roadmaps.py`, `assessments.py`, `resources.py`, `mentor.py`, `agents.py`, `progress.py`. | `fastapi`, `sqlalchemy.orm` | Created | Tested Live (`/api/*`) |
| `frontend/src/App.tsx` | Main application shell with tab-based state navigation across 14 views, header, footer, and auth gating. | `react`, `lucide-react`, `context` | Created | Tested in Browser |
| `frontend/src/pages/*.tsx` (14 views) | 14 complete interactive views: `LandingPage`, `DashboardView`, `ProfileView`, `SkillAnalysisView`, `CareerExploreView`, `CareerMatchView`, `RoadmapView`, `AssessmentView`, `ResourceLibraryView`, `ProgressAnalyticsView`, `AIMentorView`, `AgentMonitorView`, `SettingsView`, `AuthModal`. | `react`, `lucide-react`, `recharts` | Created | Tested (119-step run) |
| `frontend/src/services/api.ts` | Typed fetch API client connecting to backend with JWT bearer token management. | TypeScript | Created | Tested Live Proxy |
| `frontend/src/context/AuthContext.tsx` | React Context managing user authentication state, token storage, and 1-click demo login. | `react` | Created | Tested |
| `backend/test_workflows.py` | Automated integration test executing database seeding, demo onboarding, Scenario B, Scenario A, and versioning. | Python standard library | Created | Verified (7/7 Pass) |
| `backend/verify_full_system.py` | Automated multi-tenant isolation, cryptographic password security, and 6-agent data influence chain test. | Python standard library | Created | Verified (5/5 Pass) |
| `backend/test_security_qa.py` | Negative security tests, tampered JWT rejection, expired token check, and assessment boundary tests (40%, 60%, 64%, 65%, 100%). | Python standard library | Created | Verified (100% Pass) |
| `start_all.bat` | 1-click Windows launcher executing backend on port 8000 and frontend on port 5173. | Windows Batch | Created | Verified Operational |
| `DEMO_WALKTHROUGH.md` | Competition presentation script, 30-sec pitch, 5-minute judge demonstration script, and FAQ. | Markdown | Created | Verified |
