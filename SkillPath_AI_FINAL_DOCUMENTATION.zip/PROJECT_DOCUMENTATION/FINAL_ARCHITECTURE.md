# SkillPath AI — Technical Architecture Specification

**Project:** SkillPath AI (PromptWars X RTC)  
**Baseline:** FastAPI (Synchronous) + SQLAlchemy 2.0 + SQLite + React 18 + TypeScript + Vite + Six Specialized Python Agents  
**Execution Environment:** Windows 11, Python 3.14.6, Node v24.15.0  
**Zero Paid Dependencies:** 100% Local Intelligence, No External LLM APIs, No Cloud Subscriptions

---

## 1. High-Level Architecture Overview

SkillPath AI is constructed as a decoupled, multi-tier, multi-agent web application designed for rapid local deployment, zero configuration, and deterministic performance.

```mermaid
graph TD
    subgraph Frontend["Frontend Tier (React 18 + TypeScript + Vite)"]
        UI["14 Navigable Views (Dashboard, Roadmap, Career Match, Assessments, Mentor...)"]
        API_Client["Typed API Service Client (api.ts)"]
        Auth_Ctx["Auth Context Provider (JWT Bearer Token)"]
        UI --> API_Client
        UI --> Auth_Ctx
    end

    subgraph Gateway["Vite Reverse Proxy Gateway (Port 5173)"]
        Proxy["/api/* -> http://127.0.0.1:8000"]
    end

    subgraph Backend["Backend Tier (FastAPI + Pydantic v2)"]
        Routers["10 REST Routers (auth, profile, skills, careers, roadmaps...)"]
        Security["PBKDF2-HMAC-SHA256 & PyJWT Security"]
        Routers --> Security
    end

    subgraph AgentSystem["Multi-Agent Autonomous Intelligence Engine"]
        Orchestrator["CustomOrchestrator"]
        Context["Shared Pydantic LearnerContext"]
        RuleProvider["RuleBasedProvider (Mathematical Scoring & Sequencing)"]
        
        Agent1["Profile Agent"]
        Agent2["Skill Analysis Agent"]
        Agent3["Career Agent"]
        Agent4["Learning Agent"]
        Agent5["Progress Agent"]
        Agent6["AI Mentor Agent"]

        Orchestrator --> Context
        Orchestrator --> Agent1
        Orchestrator --> Agent2
        Orchestrator --> Agent3
        Orchestrator --> Agent4
        Orchestrator --> Agent5
        Orchestrator --> Agent6
        Agent1 & Agent2 & Agent3 & Agent4 & Agent5 & Agent6 --> RuleProvider
    end

    subgraph Persistence["Persistence Tier (SQLite + SQLAlchemy 2.0)"]
        DB[(skillpath.db - 15 Relational Models)]
        Logs[(agent_executions Table)]
        Roadmaps[(learning_roadmaps & roadmap_versions)]
    end

    API_Client --> Proxy --> Routers
    Routers --> Orchestrator
    Routers --> DB
    Orchestrator --> Logs
    Orchestrator --> Roadmaps
    Orchestrator --> DB
```

---

## 2. Learner Data Flow & Lifecycle

```mermaid
sequenceDiagram
    autonumber
    actor Learner as User / Learner
    participant UI as React 18 Frontend
    participant API as FastAPI Router
    participant Orch as CustomOrchestrator
    participant Agents as Six Specialized Agents
    participant DB as SQLite Persistence

    Learner->>UI: Logs in (Demo or Credentials)
    UI->>API: POST /api/auth/demo
    API-->>UI: JWT Access Token
    
    Learner->>UI: Updates Career Goal or Submits Diagnostic Test
    UI->>API: POST /api/careers/goal OR POST /api/assessments/submit
    API->>Orch: Trigger Adaptive Workflow(user_id)
    Orch->>DB: Build LearnerContext from stored state
    DB-->>Orch: Hydrated Context
    
    rect rgb(240, 248, 255)
        note right of Orch: Sequential Agent Pipeline Execution
        Orch->>Agents: 1. ProfileAgent.run(Context)
        Orch->>Agents: 2. SkillAnalysisAgent.run(Context)
        Orch->>Agents: 3. CareerAgent.run(Context)
        Orch->>Agents: 4. LearningAgent.run(Context)
        Orch->>Agents: 5. ProgressAgent.run(Context)
        Orch->>Agents: 6. AIMentorAgent.run(Context)
    end
    
    Orch->>DB: Persist New Roadmap Version (v2, v3...)
    Orch->>DB: Record Execution Log in agent_executions
    Orch-->>API: Workflow Outcome + Context Metadata
    API-->>UI: Reactive Response (New Readiness %, Roadmap Version, Mentor Feedback)
    UI-->>Learner: Instant Interactive UI Update
```

---

## 3. Workflow Diagrams

### A. Career Goal Change Workflow (Scenario A)
```mermaid
flowchart TD
    Start["User Selects New Career Goal (e.g. AI Engineer)"] --> UpdateProfile["Update target_career_id in Database"]
    UpdateProfile --> BuildCtx["CustomOrchestrator Builds LearnerContext"]
    BuildCtx --> ProfileAgent["Profile Agent: Ingests profile & normalizes data"]
    ProfileAgent --> SkillAgent["Skill Analysis Agent: Calibrates empirical skills"]
    SkillAgent --> CareerAgent["Career Agent: Recalculates Readiness Score (Earned / Required)"]
    CareerAgent --> LearningAgent["Learning Agent: Sequences AI/ML Curriculum Modules"]
    LearningAgent --> SaveVersion["Save New Roadmap Version (v3) in SQLite preserving v1 & v2"]
    SaveVersion --> MentorAgent["AI Mentor Agent: Employs Domain Transition Welcome"]
    MentorAgent --> PersistLog["Persist Agent Execution Logs to SQLite"]
    PersistLog --> Response["Return New Roadmap & Mentor Briefing to Frontend"]
```

### B. Diagnostic Assessment Deficit Adaptation (Scenario B)
```mermaid
flowchart TD
    SubmitTest["Learner Submits Assessment (Score e.g. 40% < 65%)"] --> GradeTest["Backend Grades MCQ Answers & Stores Attempt"]
    GradeTest --> ProgressAgent["Progress Agent: Evaluates Score & Flags Deficit Concepts"]
    ProgressAgent --> Calibrate["Update LearnerSkill with Empirical Evidence (Confidence 0.70-0.95)"]
    Calibrate --> SkillAgent["Skill Analysis Agent: Re-evaluates Strengths & Weaknesses"]
    SkillAgent --> CareerAgent["Career Agent: Recalculates Target Role Readiness"]
    CareerAgent --> CheckReassess{"Reassessment Needed? (Score < 65%)"}
    CheckReassess -- YES --> LearningAgent["Learning Agent: Injects Remedial Practice Modules into Roadmap Version 2"]
    CheckReassess -- NO --> KeepRoadmap["Maintain Active Curriculum"]
    LearningAgent --> MentorFeedback["AI Mentor Agent: Generates Deficit-Specific Coaching on Weak Concepts"]
    KeepRoadmap --> MentorFeedback
    MentorFeedback --> LogAudit["Log All Multi-Agent Handoffs in SQLite Audit Ledger"]
    LogAudit --> ReturnUI["Frontend Renders Adapted Roadmap v2 & AI Mentor Advice"]
```

---

## 4. Architectural Decisions & Intentional Deviations

1. **Synchronous SQLAlchemy 2.0 over Asynchronous Engine**:
   - *Rationale:* SQLite is an in-process, single-file database engine. Under Windows with Python 3.14, async SQLite drivers (`aiosqlite`) frequently trigger event-loop thread deadlocks and concurrency locks during fast consecutive test executions. Synchronous SQLAlchemy operations with `check_same_thread=False` provide instant, thread-safe, 100% reliable local persistence with zero lock contention.
2. **Tailwind CSS via High-Performance CDN**:
   - *Rationale:* Node v24.15.0 on Windows encounters compilation anomalies with native PostCSS C++ binaries. Loading Tailwind CSS via CDN script in `index.html` eliminates post-install native binary compilation delays while guaranteeing 100% of Tailwind styling and utility classes render in the browser.
3. **Deterministic `RuleBasedProvider` over External LLM APIs**:
   - *Rationale:* Eliminates cloud subscription costs, rate limits, network latency, and API key management during competition judging. Guarantees reproducible, mathematically sound scoring and dynamic roadmap adaptation.
4. **Multi-Version Roadmap Snapshotting**:
   - *Rationale:* Rather than overwriting existing roadmaps, `RoadmapVersion` records snapshot previous roadmaps (v1, v2, v3) along with the `change_trigger` and `change_reason`, enabling learners to review their historical progression.
