import datetime
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.models import (
    User, LearningRoadmap, RoadmapVersion, RoadmapItem, CareerRole
)
from app.schemas.schemas import (
    LearningRoadmapResponse, RoadmapVersionResponse, RoadmapItemResponse,
    RoadmapItemStatusUpdate
)
from app.api.deps import get_current_user
from backend.agents.orchestrator import CustomOrchestrator

router = APIRouter(prefix="/roadmaps", tags=["Roadmaps"])

def _format_item(item: RoadmapItem) -> dict:
    return {
        "id": item.id,
        "skill_id": item.skill_id,
        "skill_name": item.skill.name if item.skill else "Skill",
        "title": item.title,
        "learning_objective": item.learning_objective,
        "priority": item.priority,
        "difficulty": item.difficulty,
        "estimated_duration_days": item.estimated_duration_days,
        "status": item.status,
        "resource_url": item.resource_url,
        "practical_exercise": item.practical_exercise,
        "order_index": item.order_index,
        "completed_at": item.completed_at
    }

def _format_version(version: RoadmapVersion) -> dict:
    items = sorted(version.items, key=lambda x: x.order_index)
    return {
        "id": version.id,
        "version_number": version.version_number,
        "change_trigger": version.change_trigger,
        "change_reason": version.change_reason,
        "summary": version.summary,
        "created_at": version.created_at,
        "items": [_format_item(i) for i in items]
    }

@router.get("/current", response_model=LearningRoadmapResponse)
def get_current_roadmap(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    roadmap = db.query(LearningRoadmap).filter(
        LearningRoadmap.user_id == current_user.id,
        LearningRoadmap.is_active == True
    ).first()

    if not roadmap or not roadmap.versions:
        # Initialize roadmap if none exists
        orchestrator = CustomOrchestrator(db)
        orchestrator.run_initial_onboarding_workflow(current_user.id)
        roadmap = db.query(LearningRoadmap).filter(
            LearningRoadmap.user_id == current_user.id,
            LearningRoadmap.is_active == True
        ).first()

    latest_version = roadmap.versions[0] if roadmap.versions else None
    current_items = [_format_item(i) for i in latest_version.items] if latest_version else []
    all_versions = [_format_version(v) for v in roadmap.versions]

    career_title = roadmap.career.title if roadmap.career else "Career Role"

    return {
        "id": roadmap.id,
        "career_id": roadmap.career_id,
        "career_title": career_title,
        "current_version": roadmap.current_version,
        "is_active": roadmap.is_active,
        "current_items": current_items,
        "versions": all_versions
    }

@router.get("/versions", response_model=List[RoadmapVersionResponse])
def get_roadmap_versions(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    roadmap = db.query(LearningRoadmap).filter(
        LearningRoadmap.user_id == current_user.id,
        LearningRoadmap.is_active == True
    ).first()

    if not roadmap:
        return []

    return [_format_version(v) for v in roadmap.versions]

@router.patch("/items/{item_id}", response_model=RoadmapItemResponse)
def update_item_status(
    item_id: int,
    status_in: RoadmapItemStatusUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    item = db.query(RoadmapItem).filter(RoadmapItem.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Roadmap item not found")

    item.status = status_in.status
    if status_in.status == "completed":
        item.completed_at = datetime.datetime.utcnow()
    else:
        item.completed_at = None

    db.commit()
    db.refresh(item)
    return _format_item(item)

@router.post("/generate")
def regenerate_roadmap(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    orchestrator = CustomOrchestrator(db)
    result = orchestrator.run_initial_onboarding_workflow(current_user.id)
    return result
