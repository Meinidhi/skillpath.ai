from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.models import User, CareerRole, CareerRequirement
from app.schemas.schemas import (
    CareerRoleResponse, CareerMatchResult, CareerGoalChangeRequest
)
from app.api.deps import get_current_user
from backend.agents.orchestrator import CustomOrchestrator
from backend.agents.rule_based_provider import RuleBasedProvider

router = APIRouter(prefix="/careers", tags=["Careers"])

@router.get("", response_model=List[CareerRoleResponse])
def get_all_careers(db: Session = Depends(get_db)):
    careers = db.query(CareerRole).all()
    results = []
    for c in careers:
        reqs = []
        for r in c.requirements:
            reqs.append({
                "id": r.id,
                "skill_id": r.skill_id,
                "skill_name": r.skill.name if r.skill else "",
                "required_proficiency": r.required_proficiency,
                "importance": r.importance,
                "prerequisite_skills": r.prerequisite_skills or []
            })
        results.append({
            "id": c.id,
            "title": c.title,
            "description": c.description,
            "category": c.category,
            "average_salary": c.average_salary,
            "growth_rate": c.growth_rate,
            "requirements": reqs
        })
    return results

@router.get("/{career_id}", response_model=CareerRoleResponse)
def get_career(career_id: int, db: Session = Depends(get_db)):
    c = db.query(CareerRole).filter(CareerRole.id == career_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Career not found")
    reqs = []
    for r in c.requirements:
        reqs.append({
            "id": r.id,
            "skill_id": r.skill_id,
            "skill_name": r.skill.name if r.skill else "",
            "required_proficiency": r.required_proficiency,
            "importance": r.importance,
            "prerequisite_skills": r.prerequisite_skills or []
        })
    return {
        "id": c.id,
        "title": c.title,
        "description": c.description,
        "category": c.category,
        "average_salary": c.average_salary,
        "growth_rate": c.growth_rate,
        "requirements": reqs
    }

@router.get("/match/{career_id}", response_model=CareerMatchResult)
def match_career(
    career_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    career = db.query(CareerRole).filter(CareerRole.id == career_id).first()
    if not career:
        raise HTTPException(status_code=404, detail="Career not found")

    orchestrator = CustomOrchestrator(db)
    context = orchestrator.build_learner_context(current_user.id)
    # Calibrate skills
    orchestrator.skill_agent.run(context)

    reqs = [
        {
            "skill_name": r.skill.name if r.skill else "",
            "required_proficiency": r.required_proficiency,
            "importance": r.importance,
            "prerequisites": r.prerequisite_skills or []
        }
        for r in career.requirements
    ]

    match = RuleBasedProvider.calculate_career_match(reqs, context.analyzed_skills)

    return {
        "career_id": career.id,
        "career_title": career.title,
        "career_readiness_score": match["career_readiness_score"],
        "formula_breakdown": match["formula_breakdown"],
        "meeting_skills": match["meeting_skills"],
        "underdeveloped_skills": match["underdeveloped_skills"],
        "missing_skills": match["missing_skills"],
        "total_required": match["total_required"],
        "critical_missing": match["critical_missing"]
    }

@router.post("/goal")
def change_career_goal(
    goal_in: CareerGoalChangeRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    SCENARIO A: Change Career Goal
    Triggers the exact required CAREER CHANGE workflow:
    Profile -> Skill Analysis -> Career -> Learning -> Save new roadmap version -> Mentor welcome.
    """
    career = db.query(CareerRole).filter(CareerRole.id == goal_in.new_career_id).first()
    if not career:
        raise HTTPException(status_code=404, detail="Target career role not found.")

    orchestrator = CustomOrchestrator(db)
    result = orchestrator.run_career_change_workflow(current_user.id, goal_in.new_career_id)

    return result
