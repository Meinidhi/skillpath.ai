import datetime
from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.models import User, MentorConversation
from app.schemas.schemas import (
    MentorMessageRequest, MentorMessageResponse
)
from app.api.deps import get_current_user
from backend.agents.orchestrator import CustomOrchestrator

router = APIRouter(prefix="/mentor", tags=["AI Mentor"])

@router.post("/chat", response_model=MentorMessageResponse)
def send_mentor_message(
    chat_in: MentorMessageRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Save user message
    user_msg = MentorConversation(
        user_id=current_user.id,
        message=chat_in.message,
        sender="user",
        context_metadata={},
        timestamp=datetime.datetime.utcnow()
    )
    db.add(user_msg)
    db.commit()

    # Build context and run AI Mentor Agent
    orchestrator = CustomOrchestrator(db)
    context = orchestrator.build_learner_context(current_user.id)
    # Calibrate and match
    orchestrator.skill_agent.run(context)
    orchestrator.career_agent.run(context)
    context.user_message = chat_in.message
    context.trigger = "UserQuery"

    mentor_result = orchestrator.mentor_agent.run(context)
    reply_text = mentor_result.get("mentor_response", "I am here to guide your learning path.")

    # Save mentor response
    mentor_msg = MentorConversation(
        user_id=current_user.id,
        message=reply_text,
        sender="mentor",
        context_metadata={
            "career": context.target_career_title,
            "readiness_score": context.career_readiness_score
        },
        timestamp=datetime.datetime.utcnow()
    )
    db.add(mentor_msg)
    db.commit()
    db.refresh(mentor_msg)

    return {
        "id": mentor_msg.id,
        "message": mentor_msg.message,
        "sender": mentor_msg.sender,
        "context_metadata": mentor_msg.context_metadata or {},
        "timestamp": mentor_msg.timestamp
    }

@router.get("/history", response_model=List[MentorMessageResponse])
def get_chat_history(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    messages = db.query(MentorConversation).filter(
        MentorConversation.user_id == current_user.id
    ).order_by(MentorConversation.timestamp.asc()).all()

    return [
        {
            "id": m.id,
            "message": m.message,
            "sender": m.sender,
            "context_metadata": m.context_metadata or {},
            "timestamp": m.timestamp
        }
        for m in messages
    ]
