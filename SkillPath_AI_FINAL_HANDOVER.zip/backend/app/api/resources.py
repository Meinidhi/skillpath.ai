from typing import List, Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.models import LearningResource
from app.schemas.schemas import LearningResourceResponse

router = APIRouter(prefix="/resources", tags=["Learning Resources"])

@router.get("", response_model=List[LearningResourceResponse])
def list_resources(
    skill_name: Optional[str] = Query(None),
    difficulty: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    query = db.query(LearningResource)
    if difficulty:
        query = query.filter(LearningResource.difficulty == difficulty)
    
    resources = query.all()
    results = []
    for r in resources:
        s_name = r.skill.name if r.skill else "General"
        if skill_name and skill_name.lower() not in s_name.lower():
            continue
        results.append({
            "id": r.id,
            "skill_id": r.skill_id,
            "skill_name": s_name,
            "title": r.title,
            "url": r.url,
            "provider": r.provider,
            "resource_type": r.resource_type,
            "difficulty": r.difficulty,
            "estimated_hours": r.estimated_hours,
            "rating": r.rating
        })
    return results
