from typing import List
import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.models import User, Skill, LearnerSkill
from app.schemas.schemas import (
    SkillBase, LearnerSkillResponse, LearnerSkillBatchUpdate, SkillAnalysisResult
)
from app.api.deps import get_current_user
from backend.agents.orchestrator import CustomOrchestrator

router = APIRouter(prefix="/skills", tags=["Skills"])

@router.get("", response_model=List[SkillBase])
def get_all_skills(db: Session = Depends(get_db)):
    return db.query(Skill).all()

@router.get("/my", response_model=List[LearnerSkillResponse])
def get_my_skills(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    learner_skills = db.query(LearnerSkill).filter(LearnerSkill.user_id == current_user.id).all()
    results = []
    for ls in learner_skills:
        results.append({
            "id": ls.id,
            "skill_id": ls.skill_id,
            "skill_name": ls.skill.name if ls.skill else "Unknown",
            "category": ls.skill.category if ls.skill else "General",
            "proficiency_level": ls.proficiency_level,
            "evidence_source": ls.evidence_source,
            "confidence_level": ls.confidence_level,
            "last_assessed_date": ls.last_assessed_date
        })
    return results

@router.post("/batch-update")
def batch_update_skills(
    batch_in: LearnerSkillBatchUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    skills_map = {s.name: s.id for s in db.query(Skill).all()}
    
    for s_item in batch_in.skills:
        s_id = skills_map.get(s_item.skill_name)
        if not s_id:
            continue
        
        existing = db.query(LearnerSkill).filter(
            LearnerSkill.user_id == current_user.id,
            LearnerSkill.skill_id == s_id
        ).first()

        conf = 0.35 if s_item.evidence_source == "Self-Declared" else 0.65

        if existing:
            existing.proficiency_level = s_item.proficiency_level
            existing.evidence_source = s_item.evidence_source or "Self-Declared"
            existing.confidence_level = conf
            existing.last_assessed_date = datetime.datetime.utcnow()
        else:
            new_ls = LearnerSkill(
                user_id=current_user.id,
                skill_id=s_id,
                proficiency_level=s_item.proficiency_level,
                evidence_source=s_item.evidence_source or "Self-Declared",
                confidence_level=conf
            )
            db.add(new_ls)
    
    db.commit()
    return {"message": "Skills updated successfully", "count": len(batch_in.skills)}

@router.get("/analysis", response_model=SkillAnalysisResult)
def get_skill_analysis(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    orchestrator = CustomOrchestrator(db)
    context = orchestrator.build_learner_context(current_user.id)
    result = orchestrator.skill_agent.run(context)
    
    # Calculate category coverage
    cat_counts = {}
    cat_points = {}
    for s in context.analyzed_skills:
        cat = s.get("category", "General")
        cat_counts[cat] = cat_counts.get(cat, 0) + 1
        cat_points[cat] = cat_points.get(cat, 0) + s.get("numeric_rank", 1)

    cat_coverage = {}
    for cat, count in cat_counts.items():
        cat_coverage[cat] = round((cat_points[cat] / (count * 4.0)) * 100.0, 1)

    avg_conf = round(
        sum(s.get("confidence_level", 0.35) for s in context.analyzed_skills) / max(1, len(context.analyzed_skills)),
        2
    )

    return {
        "overall_proficiency": "Intermediate" if any(s.get("numeric_rank", 1) >= 2 for s in context.analyzed_skills) else "Beginner",
        "strengths": context.strengths,
        "weaknesses": context.weaknesses,
        "skill_distribution": result.get("distribution", {"Beginner": 0, "Intermediate": 0, "Advanced": 0, "Expert": 0}),
        "category_coverage": cat_coverage,
        "total_skills_recorded": len(context.analyzed_skills),
        "average_confidence": avg_conf
    }
