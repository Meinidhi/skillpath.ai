from typing import List, Dict, Any
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.models import User, AgentExecution
from app.schemas.schemas import AgentExecutionResponse, WorkflowResultResponse
from app.api.deps import get_current_user
from backend.agents.orchestrator import CustomOrchestrator

router = APIRouter(prefix="/agents", tags=["Agents"])

@router.get("/status")
def get_agents_status():
    """Lists the six specialized agent modules and their real-time state."""
    return [
        {
            "id": "profile-agent",
            "name": "Profile Agent",
            "role": "Profile Completeness & Normalization",
            "responsibility": "Processes learner profile, normalizes skill levels, identifies missing profile info, and prepares structured learner context.",
            "status": "ready",
            "engine": "RuleBasedProvider (Local Deterministic)"
        },
        {
            "id": "skill-agent",
            "name": "Skill Analysis Agent",
            "role": "Evidence Calibration & Gap Analysis",
            "responsibility": "Analyzes current skills, evaluates assessment evidence, weights confidence, and maps strengths/weaknesses.",
            "status": "ready",
            "engine": "RuleBasedProvider (Local Deterministic)"
        },
        {
            "id": "career-agent",
            "name": "Career Agent",
            "role": "Competency Matching & Readiness Scoring",
            "responsibility": "Compares learner skills with career requirements, calculates career readiness, and prioritizes missing competencies.",
            "status": "ready",
            "engine": "RuleBasedProvider (Local Deterministic)"
        },
        {
            "id": "learning-agent",
            "name": "Learning Agent",
            "role": "Roadmap Synthesis & Sequencing",
            "responsibility": "Generates personalized roadmaps, arranges learning prerequisites, recommends curated resources, and sequences exercises.",
            "status": "ready",
            "engine": "RuleBasedProvider (Local Deterministic)"
        },
        {
            "id": "progress-agent",
            "name": "Progress Agent",
            "role": "Diagnostic Evaluation & Adaptive Intervention",
            "responsibility": "Evaluates assessment outcomes, detects weak concepts, tracks milestone attainment, and determines whether adaptive reassessment is required.",
            "status": "ready",
            "engine": "RuleBasedProvider (Local Deterministic)"
        },
        {
            "id": "mentor-agent",
            "name": "AI Mentor Agent",
            "role": "Contextual Mentorship & Coaching",
            "responsibility": "Provides hyper-personalized, context-aware mentoring, career transition coaching, and grounded assessment feedback.",
            "status": "ready",
            "engine": "RuleBasedProvider (Local Deterministic)"
        }
    ]

@router.get("/executions", response_model=List[AgentExecutionResponse])
def get_agent_executions(
    limit: int = Query(50, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    executions = db.query(AgentExecution).filter(
        AgentExecution.user_id == current_user.id
    ).order_by(AgentExecution.timestamp.desc()).limit(limit).all()

    return executions

@router.post("/workflow")
def trigger_analysis_workflow(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    orchestrator = CustomOrchestrator(db)
    result = orchestrator.run_initial_onboarding_workflow(current_user.id)
    return result
