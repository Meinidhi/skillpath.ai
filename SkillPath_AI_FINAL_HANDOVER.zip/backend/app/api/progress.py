from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.models import (
    User, LearnerSkill, LearningRoadmap, RoadmapVersion, RoadmapItem,
    AssessmentAttempt, CareerRole, AgentExecution
)
from app.schemas.schemas import ProgressOverviewResponse
from app.api.deps import get_current_user
from backend.agents.orchestrator import CustomOrchestrator
from backend.agents.rule_based_provider import PROFICIENCY_RANK

router = APIRouter(prefix="/progress", tags=["Progress"])

@router.get("/overview", response_model=ProgressOverviewResponse)
def get_progress_overview(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    orchestrator = CustomOrchestrator(db)
    context = orchestrator.build_learner_context(current_user.id)
    orchestrator.skill_agent.run(context)
    orchestrator.career_agent.run(context)

    # Roadmap progress
    roadmap = db.query(LearningRoadmap).filter(
        LearningRoadmap.user_id == current_user.id,
        LearningRoadmap.is_active == True
    ).first()

    items = []
    completed_items = []
    if roadmap and roadmap.versions:
        latest_version = roadmap.versions[0]
        items = latest_version.items
        completed_items = [i for i in items if i.status == "completed"]

    roadmap_completion_pct = round((len(completed_items) / max(1, len(items))) * 100.0, 1) if items else 0.0

    # Skills counts
    mastered = [s for s in context.analyzed_skills if s.get("proficiency_level") in ["Advanced", "Expert"]]
    in_progress = [s for s in context.analyzed_skills if s.get("proficiency_level") in ["Beginner", "Intermediate"]]

    # Assessments
    attempts = db.query(AssessmentAttempt).filter(AssessmentAttempt.user_id == current_user.id).all()
    avg_score = round(sum(a.score for a in attempts) / max(1, len(attempts)), 1) if attempts else 0.0

    # Upcoming tasks
    upcoming = []
    for itm in items:
        if itm.status != "completed":
            upcoming.append({
                "id": itm.id,
                "skill_id": itm.skill_id,
                "skill_name": itm.skill.name if itm.skill else "Skill",
                "title": itm.title,
                "learning_objective": itm.learning_objective,
                "priority": itm.priority,
                "difficulty": itm.difficulty,
                "estimated_duration_days": itm.estimated_duration_days,
                "status": itm.status,
                "resource_url": itm.resource_url,
                "practical_exercise": itm.practical_exercise,
                "order_index": itm.order_index,
                "completed_at": itm.completed_at
            })
            if len(upcoming) >= 5:
                break

    # Skill radar data for Recharts
    radar_data = []
    category_scores = {}
    category_counts = {}
    for s in context.analyzed_skills:
        cat = s.get("category", "General")
        category_counts[cat] = category_counts.get(cat, 0) + 1
        category_scores[cat] = category_scores.get(cat, 0) + s.get("numeric_rank", 1)

    for cat, count in category_counts.items():
        radar_data.append({
            "category": cat,
            "current": round((category_scores[cat] / (count * 4.0)) * 100.0, 1),
            "target": 85.0
        })

    # History trend
    history_trend = [
        {"milestone": "Week 1", "readiness": max(15.0, context.career_readiness_score - 25.0)},
        {"milestone": "Week 2", "readiness": max(25.0, context.career_readiness_score - 15.0)},
        {"milestone": "Week 3", "readiness": max(35.0, context.career_readiness_score - 8.0)},
        {"milestone": "Current", "readiness": context.career_readiness_score}
    ]

    # Recent activities
    recent_execs = db.query(AgentExecution).filter(
        AgentExecution.user_id == current_user.id
    ).order_by(AgentExecution.timestamp.desc()).limit(6).all()

    recent_activities = []
    for ex in recent_execs:
        recent_activities.append({
            "title": f"{ex.agent_name} executed",
            "description": ex.output_summary,
            "timestamp": ex.timestamp,
            "status": ex.status
        })

    # Overall progress percentage (combination of career readiness + roadmap completion + assessment completion)
    overall_pct = round((context.career_readiness_score * 0.5) + (roadmap_completion_pct * 0.3) + (min(100.0, len(attempts) * 25.0) * 0.2), 1)

    return {
        "career_readiness_score": context.career_readiness_score,
        "target_career": context.target_career_title,
        "overall_progress_pct": overall_pct,
        "skills_mastered_count": len(mastered),
        "skills_in_progress_count": len(in_progress),
        "total_skills_count": len(context.analyzed_skills),
        "assessments_completed_count": len(attempts),
        "average_assessment_score": avg_score,
        "roadmap_completion_pct": roadmap_completion_pct,
        "active_tasks_count": len(items) - len(completed_items),
        "recent_activities": recent_activities,
        "upcoming_tasks": upcoming,
        "skill_radar_data": radar_data,
        "history_trend": history_trend
    }
