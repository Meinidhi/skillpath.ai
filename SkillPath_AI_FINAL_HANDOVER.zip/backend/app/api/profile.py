from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.models import User, LearnerProfile, CareerRole
from app.schemas.schemas import LearnerProfileResponse, LearnerProfileUpdate
from app.api.deps import get_current_user
from backend.agents.orchestrator import CustomOrchestrator

router = APIRouter(prefix="/profile", tags=["Learner Profile"])

@router.get("", response_model=LearnerProfileResponse)
def get_profile(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    profile = db.query(LearnerProfile).filter(LearnerProfile.user_id == current_user.id).first()
    if not profile:
        profile = LearnerProfile(
            user_id=current_user.id,
            education="Undergraduate",
            institution="University / College",
            academic_year="3rd Year",
            experience_level="Beginner",
            preferred_learning_style="Hands-on",
            soft_skills=[],
            certifications=[],
            projects=[]
        )
        db.add(profile)
        db.commit()
        db.refresh(profile)

    career_title = profile.target_career.title if profile.target_career else "Unassigned"

    return {
        "id": profile.id,
        "user_id": profile.user_id,
        "education": profile.education,
        "institution": profile.institution,
        "academic_year": profile.academic_year,
        "experience_level": profile.experience_level,
        "target_career_id": profile.target_career_id,
        "target_career_title": career_title,
        "preferred_learning_style": profile.preferred_learning_style,
        "soft_skills": profile.soft_skills or [],
        "certifications": profile.certifications or [],
        "projects": profile.projects or [],
        "created_at": profile.created_at,
        "updated_at": profile.updated_at
    }

@router.put("", response_model=LearnerProfileResponse)
def update_profile(
    profile_in: LearnerProfileUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    profile = db.query(LearnerProfile).filter(LearnerProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    old_career_id = profile.target_career_id

    if profile_in.education is not None:
        profile.education = profile_in.education
    if profile_in.institution is not None:
        profile.institution = profile_in.institution
    if profile_in.academic_year is not None:
        profile.academic_year = profile_in.academic_year
    if profile_in.experience_level is not None:
        profile.experience_level = profile_in.experience_level
    if profile_in.preferred_learning_style is not None:
        profile.preferred_learning_style = profile_in.preferred_learning_style
    if profile_in.soft_skills is not None:
        profile.soft_skills = profile_in.soft_skills
    if profile_in.certifications is not None:
        profile.certifications = profile_in.certifications
    if profile_in.projects is not None:
        profile.projects = profile_in.projects

    # If career changed through profile update, trigger career change workflow!
    career_changed = (profile_in.target_career_id is not None and profile_in.target_career_id != old_career_id)
    if profile_in.target_career_id is not None:
        profile.target_career_id = profile_in.target_career_id

    db.commit()
    db.refresh(profile)

    if career_changed and profile.target_career_id:
        orchestrator = CustomOrchestrator(db)
        orchestrator.run_career_change_workflow(current_user.id, profile.target_career_id)

    career_title = profile.target_career.title if profile.target_career else "Unassigned"

    return {
        "id": profile.id,
        "user_id": profile.user_id,
        "education": profile.education,
        "institution": profile.institution,
        "academic_year": profile.academic_year,
        "experience_level": profile.experience_level,
        "target_career_id": profile.target_career_id,
        "target_career_title": career_title,
        "preferred_learning_style": profile.preferred_learning_style,
        "soft_skills": profile.soft_skills or [],
        "certifications": profile.certifications or [],
        "projects": profile.projects or [],
        "created_at": profile.created_at,
        "updated_at": profile.updated_at
    }
