import jwt
import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.core.config import settings
from app.core.security import get_password_hash, verify_password
from app.core.database import get_db
from app.models.models import User, LearnerProfile, CareerRole
from app.schemas.schemas import UserCreate, UserLogin, Token, UserResponse
from app.api.deps import get_current_user
from backend.agents.orchestrator import CustomOrchestrator

router = APIRouter(prefix="/auth", tags=["Authentication"])

def _create_token(user: User) -> str:
    payload = {
        "sub": user.id,
        "email": user.email,
        "is_demo": user.is_demo,
        "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    }
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.ALGORITHM)

@router.post("/register", response_model=Token)
def register(user_in: UserCreate, db: Session = Depends(get_db)):
    existing = db.query(User).filter(User.email == user_in.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="An account with this email already exists.")

    new_user = User(
        email=user_in.email,
        hashed_password=get_password_hash(user_in.password),
        full_name=user_in.full_name,
        is_active=True,
        is_demo=False
    )
    db.add(new_user)
    db.flush()

    # Create profile
    profile = LearnerProfile(
        user_id=new_user.id,
        education=user_in.education or "Undergraduate",
        institution=user_in.institution or "University / College",
        academic_year=user_in.academic_year or "3rd Year",
        experience_level=user_in.experience_level or "Beginner",
        target_career_id=user_in.target_career_id,
        preferred_learning_style=user_in.preferred_learning_style or "Hands-on",
        soft_skills=["Problem Solving", "Communication"],
        certifications=[],
        projects=[]
    )
    db.add(profile)
    db.commit()

    # Trigger initial onboarding workflow with custom orchestrator
    orchestrator = CustomOrchestrator(db)
    orchestrator.run_initial_onboarding_workflow(new_user.id)

    token = _create_token(new_user)
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": new_user.id,
            "email": new_user.email,
            "full_name": new_user.full_name,
            "is_demo": False
        }
    }

@router.post("/login", response_model=Token)
def login(login_in: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == login_in.email).first()
    if not user or not verify_password(login_in.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password"
        )

    token = _create_token(user)
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "email": user.email,
            "full_name": user.full_name,
            "is_demo": user.is_demo
        }
    }

@router.post("/demo", response_model=Token)
def demo_login(db: Session = Depends(get_db)):
    demo = db.query(User).filter(User.email == "demo@skillpath.ai").first()
    if not demo:
        raise HTTPException(status_code=404, detail="Demo user account not found.")

    token = _create_token(demo)
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": demo.id,
            "email": demo.email,
            "full_name": demo.full_name,
            "is_demo": True
        }
    }

@router.get("/me", response_model=UserResponse)
def get_me(current_user: User = Depends(get_current_user)):
    return current_user
