import datetime
from typing import List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.models import (
    User, Assessment, AssessmentQuestion, AssessmentAttempt, Skill
)
from app.schemas.schemas import (
    AssessmentDetailResponse, AssessmentSubmitRequest, AssessmentAttemptResponse
)
from app.api.deps import get_current_user
from backend.agents.orchestrator import CustomOrchestrator

router = APIRouter(prefix="/assessments", tags=["Assessments"])

@router.get("")
def list_assessments(db: Session = Depends(get_db)):
    assessments = db.query(Assessment).all()
    results = []
    for a in assessments:
        results.append({
            "id": a.id,
            "skill_id": a.skill_id,
            "skill_name": a.skill.name if a.skill else "Skill",
            "title": a.title,
            "category": a.category,
            "difficulty": a.difficulty,
            "pass_score": a.pass_score,
            "questions_count": len(a.questions)
        })
    return results

@router.get("/{assessment_id}", response_model=AssessmentDetailResponse)
def get_assessment(assessment_id: int, db: Session = Depends(get_db)):
    a = db.query(Assessment).filter(Assessment.id == assessment_id).first()
    if not a:
        raise HTTPException(status_code=404, detail="Assessment not found")

    questions = []
    for q in a.questions:
        questions.append({
            "id": q.id,
            "question_text": q.question_text,
            "options": q.options,
            "concept_tag": q.concept_tag
        })

    return {
        "id": a.id,
        "skill_id": a.skill_id,
        "skill_name": a.skill.name if a.skill else "Skill",
        "title": a.title,
        "category": a.category,
        "difficulty": a.difficulty,
        "pass_score": a.pass_score,
        "questions": questions
    }

@router.post("/submit", response_model=AssessmentAttemptResponse)
def submit_assessment(
    submit_in: AssessmentSubmitRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    SCENARIO B: Submit Assessment & Adaptive Learning Path Adjustment
    Calculates score, detects weak concept tags, stores attempt,
    and runs the exact ASSESSMENT workflow:
    Progress -> Skill Analysis -> Career -> If reassessment is needed, Learning creates a new roadmap version -> Mentor feedback.
    """
    assessment = db.query(Assessment).filter(Assessment.id == submit_in.assessment_id).first()
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")

    total_q = len(assessment.questions)
    if total_q == 0:
        raise HTTPException(status_code=400, detail="Assessment has no questions")

    correct_count = 0
    weak_concepts = []
    explanations = []

    for q in assessment.questions:
        user_choice = submit_in.answers.get(q.id)
        is_correct = (user_choice == q.correct_answer_index)
        if is_correct:
            correct_count += 1
        else:
            weak_concepts.append(q.concept_tag)

        explanations.append({
            "question_id": q.id,
            "question_text": q.question_text,
            "user_choice": user_choice,
            "correct_choice": q.correct_answer_index,
            "is_correct": is_correct,
            "explanation": q.explanation,
            "concept_tag": q.concept_tag
        })

    score = round((correct_count / total_q) * 100.0, 1)
    passed = (score >= assessment.pass_score)

    # Persist attempt in DB
    attempt = AssessmentAttempt(
        user_id=current_user.id,
        assessment_id=assessment.id,
        score=score,
        total_questions=total_q,
        correct_count=correct_count,
        passed=passed,
        weak_concepts=weak_concepts,
        answers_summary=explanations,
        attempted_at=datetime.datetime.utcnow()
    )
    db.add(attempt)
    db.commit()
    db.refresh(attempt)

    # Trigger required ASSESSMENT workflow with CustomOrchestrator
    orchestrator = CustomOrchestrator(db)
    workflow_result = orchestrator.run_assessment_workflow(current_user.id, attempt.id)

    adaptation_triggered = workflow_result.get("reassessment_needed", False)
    adaptation_summary = workflow_result.get("mentor_feedback")

    return {
        "id": attempt.id,
        "assessment_id": assessment.id,
        "skill_name": assessment.skill.name if assessment.skill else "Skill",
        "score": score,
        "total_questions": total_q,
        "correct_count": correct_count,
        "passed": passed,
        "weak_concepts": weak_concepts,
        "explanations": explanations,
        "attempted_at": attempt.attempted_at,
        "adaptation_triggered": adaptation_triggered,
        "adaptation_summary": adaptation_summary
    }

@router.get("/history/my")
def get_my_attempts(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    attempts = db.query(AssessmentAttempt).filter(
        AssessmentAttempt.user_id == current_user.id
    ).order_by(AssessmentAttempt.attempted_at.desc()).all()

    results = []
    for at in attempts:
        results.append({
            "id": at.id,
            "assessment_id": at.assessment_id,
            "skill_name": at.assessment.skill.name if at.assessment and at.assessment.skill else "Skill",
            "score": at.score,
            "total_questions": at.total_questions,
            "correct_count": at.correct_count,
            "passed": at.passed,
            "weak_concepts": at.weak_concepts or [],
            "attempted_at": at.attempted_at
        })
    return results
