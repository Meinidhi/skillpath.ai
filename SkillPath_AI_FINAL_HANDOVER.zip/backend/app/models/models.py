import datetime
from sqlalchemy import (
    Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text, JSON
)
from sqlalchemy.orm import relationship
from app.core.database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    is_demo = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    # Relationships
    profile = relationship("LearnerProfile", back_populates="user", uselist=False, cascade="all, delete-orphan")
    skills = relationship("LearnerSkill", back_populates="user", cascade="all, delete-orphan")
    roadmaps = relationship("LearningRoadmap", back_populates="user", cascade="all, delete-orphan")
    assessment_attempts = relationship("AssessmentAttempt", back_populates="user", cascade="all, delete-orphan")
    mentor_messages = relationship("MentorConversation", back_populates="user", cascade="all, delete-orphan")
    agent_executions = relationship("AgentExecution", back_populates="user", cascade="all, delete-orphan")


class LearnerProfile(Base):
    __tablename__ = "learner_profiles"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    education = Column(String(100), default="Undergraduate")
    institution = Column(String(255), default="University / College")
    academic_year = Column(String(50), default="3rd Year")
    experience_level = Column(String(50), default="Beginner")  # Beginner, Intermediate, Advanced
    target_career_id = Column(Integer, ForeignKey("career_roles.id"), nullable=True)
    preferred_learning_style = Column(String(50), default="Hands-on")  # Hands-on, Visual, Reading/Writing, Video-first
    soft_skills = Column(JSON, default=list)  # ["Problem Solving", "Communication", "Teamwork"]
    certifications = Column(JSON, default=list)  # [{"title": "...", "issuer": "...", "year": 2024}]
    projects = Column(JSON, default=list)  # [{"title": "...", "description": "...", "technologies": []}]
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    user = relationship("User", back_populates="profile")
    target_career = relationship("CareerRole")


class Skill(Base):
    __tablename__ = "skills"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, index=True, nullable=False)
    category = Column(String(100), index=True, nullable=False)  # Frontend, Backend, Database, AI/ML, DevOps, Cloud, Core CS
    description = Column(Text, nullable=True)

    learner_skills = relationship("LearnerSkill", back_populates="skill")
    career_requirements = relationship("CareerRequirement", back_populates="skill")
    resources = relationship("LearningResource", back_populates="skill")
    assessments = relationship("Assessment", back_populates="skill")


class LearnerSkill(Base):
    __tablename__ = "learner_skills"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    skill_id = Column(Integer, ForeignKey("skills.id"), nullable=False)
    proficiency_level = Column(String(50), default="Beginner")  # Beginner, Intermediate, Advanced, Expert
    evidence_source = Column(String(50), default="Self-Declared")  # Self-Declared, Assessment, Project, Course
    confidence_level = Column(Float, default=0.35)  # 0.0 - 1.0 scale
    last_assessed_date = Column(DateTime, default=datetime.datetime.utcnow)

    user = relationship("User", back_populates="skills")
    skill = relationship("Skill", back_populates="learner_skills")


class CareerRole(Base):
    __tablename__ = "career_roles"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(100), unique=True, index=True, nullable=False)
    description = Column(Text, nullable=False)
    category = Column(String(100), nullable=False)
    average_salary = Column(String(50), default="$95,000 - $140,000")
    growth_rate = Column(String(50), default="+22% (Faster than average)")

    requirements = relationship("CareerRequirement", back_populates="career", cascade="all, delete-orphan")


class CareerRequirement(Base):
    __tablename__ = "career_requirements"

    id = Column(Integer, primary_key=True, index=True)
    career_id = Column(Integer, ForeignKey("career_roles.id"), nullable=False)
    skill_id = Column(Integer, ForeignKey("skills.id"), nullable=False)
    required_proficiency = Column(String(50), default="Intermediate")  # Beginner, Intermediate, Advanced, Expert
    importance = Column(String(50), default="Critical")  # Critical, High, Medium, Nice-to-have
    prerequisite_skills = Column(JSON, default=list)  # list of skill names

    career = relationship("CareerRole", back_populates="requirements")
    skill = relationship("Skill", back_populates="career_requirements")


class LearningResource(Base):
    __tablename__ = "learning_resources"

    id = Column(Integer, primary_key=True, index=True)
    skill_id = Column(Integer, ForeignKey("skills.id"), nullable=False)
    title = Column(String(255), nullable=False)
    url = Column(String(500), nullable=False)
    provider = Column(String(100), nullable=False)  # MDN, freeCodeCamp, W3Schools, Python Docs, React Docs, etc.
    resource_type = Column(String(50), default="Interactive")  # Documentation, Interactive, Video, Project, Guide
    difficulty = Column(String(50), default="Beginner")  # Beginner, Intermediate, Advanced
    estimated_hours = Column(Float, default=4.0)
    rating = Column(Float, default=4.8)

    skill = relationship("Skill", back_populates="resources")


class LearningRoadmap(Base):
    __tablename__ = "learning_roadmaps"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    career_id = Column(Integer, ForeignKey("career_roles.id"), nullable=False)
    current_version = Column(Integer, default=1)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    user = relationship("User", back_populates="roadmaps")
    career = relationship("CareerRole")
    versions = relationship("RoadmapVersion", back_populates="roadmap", cascade="all, delete-orphan", order_by="RoadmapVersion.version_number.desc()")


class RoadmapVersion(Base):
    __tablename__ = "roadmap_versions"

    id = Column(Integer, primary_key=True, index=True)
    roadmap_id = Column(Integer, ForeignKey("learning_roadmaps.id"), nullable=False)
    version_number = Column(Integer, nullable=False)
    change_trigger = Column(String(100), default="Initial")  # Initial, CareerGoalChange, AssessmentAdaptation, ManualUpdate
    change_reason = Column(Text, nullable=True)
    summary = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    roadmap = relationship("LearningRoadmap", back_populates="versions")
    items = relationship("RoadmapItem", back_populates="version", cascade="all, delete-orphan", order_by="RoadmapItem.order_index.asc()")


class RoadmapItem(Base):
    __tablename__ = "roadmap_items"

    id = Column(Integer, primary_key=True, index=True)
    roadmap_version_id = Column(Integer, ForeignKey("roadmap_versions.id"), nullable=False)
    skill_id = Column(Integer, ForeignKey("skills.id"), nullable=False)
    title = Column(String(255), nullable=False)
    learning_objective = Column(Text, nullable=False)
    priority = Column(String(50), default="High")  # Critical, High, Medium, Low
    difficulty = Column(String(50), default="Beginner")  # Beginner, Intermediate, Advanced
    estimated_duration_days = Column(Integer, default=7)
    status = Column(String(50), default="pending")  # pending, in_progress, completed, needs_revision
    resource_url = Column(String(500), nullable=True)
    practical_exercise = Column(Text, nullable=True)
    order_index = Column(Integer, default=0)
    completed_at = Column(DateTime, nullable=True)

    version = relationship("RoadmapVersion", back_populates="items")
    skill = relationship("Skill")


class Assessment(Base):
    __tablename__ = "assessments"

    id = Column(Integer, primary_key=True, index=True)
    skill_id = Column(Integer, ForeignKey("skills.id"), nullable=False)
    title = Column(String(255), nullable=False)
    category = Column(String(100), nullable=False)
    difficulty = Column(String(50), default="Intermediate")
    pass_score = Column(Float, default=70.0)

    skill = relationship("Skill", back_populates="assessments")
    questions = relationship("AssessmentQuestion", back_populates="assessment", cascade="all, delete-orphan")
    attempts = relationship("AssessmentAttempt", back_populates="assessment", cascade="all, delete-orphan")


class AssessmentQuestion(Base):
    __tablename__ = "assessment_questions"

    id = Column(Integer, primary_key=True, index=True)
    assessment_id = Column(Integer, ForeignKey("assessments.id"), nullable=False)
    question_text = Column(Text, nullable=False)
    options = Column(JSON, nullable=False)  # ["Option A", "Option B", "Option C", "Option D"]
    correct_answer_index = Column(Integer, nullable=False)  # 0, 1, 2, or 3
    explanation = Column(Text, nullable=False)
    concept_tag = Column(String(100), nullable=False)  # e.g., "Async/Await", "Closures", "Event Loop"

    assessment = relationship("Assessment", back_populates="questions")


class AssessmentAttempt(Base):
    __tablename__ = "assessment_attempts"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    assessment_id = Column(Integer, ForeignKey("assessments.id"), nullable=False)
    score = Column(Float, nullable=False)
    total_questions = Column(Integer, nullable=False)
    correct_count = Column(Integer, nullable=False)
    passed = Column(Boolean, default=False)
    weak_concepts = Column(JSON, default=list)  # list of concept_tags learner got wrong
    answers_summary = Column(JSON, default=list)  # user answers and breakdown
    attempted_at = Column(DateTime, default=datetime.datetime.utcnow)

    user = relationship("User", back_populates="assessment_attempts")
    assessment = relationship("Assessment", back_populates="attempts")


class MentorConversation(Base):
    __tablename__ = "mentor_conversations"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    message = Column(Text, nullable=False)
    sender = Column(String(50), default="user")  # "user" or "mentor"
    context_metadata = Column(JSON, default=dict)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)

    user = relationship("User", back_populates="mentor_messages")


class AgentExecution(Base):
    __tablename__ = "agent_executions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    workflow_id = Column(String(100), index=True, nullable=False)
    agent_name = Column(String(100), index=True, nullable=False)
    responsibility = Column(String(255), nullable=False)
    status = Column(String(50), default="success")  # started, success, failed
    input_summary = Column(Text, nullable=True)
    output_summary = Column(Text, nullable=True)
    full_payload = Column(JSON, default=dict)
    execution_time_ms = Column(Integer, default=0)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)

    user = relationship("User", back_populates="agent_executions")
