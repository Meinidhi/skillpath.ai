from typing import Dict, Any, List, Optional
from app.agents.base import BaseAgent
from app.core.config import settings

class LLMProviderInterface:
    """Extensible clean interface for optional external/local LLM providers."""
    def generate_response(self, system_prompt: str, user_prompt: str, context: Dict[str, Any]) -> Optional[str]:
        # Returns None to default to deterministic intelligent engine
        return None

class AIMentorAgent(BaseAgent):
    name = "AI Mentor Agent"
    responsibility = "Provides hyper-personalized, context-aware mentoring, career coaching, and skill advice grounded in real progress data."

    def __init__(self, llm_provider: Optional[LLMProviderInterface] = None):
        self.llm_provider = llm_provider or LLMProviderInterface()

    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        user_message = context.get("user_message", "").strip()
        learner = context.get("learner_context", {})
        career_title = learner.get("target_career_title", "your selected career")
        career_score = context.get("career_readiness_score", 0.0)
        strengths = context.get("strengths", [])
        weaknesses = context.get("weaknesses", [])
        missing_skills = context.get("missing_skills", [])
        current_task = context.get("current_task")
        recent_attempt = context.get("recent_attempt")
        learner_name = learner.get("full_name", "Learner")

        lower_msg = user_message.lower()

        # Check if external LLM configured and returns response
        if settings.LLM_PROVIDER != "deterministic":
            llm_result = self.llm_provider.generate_response(
                system_prompt="You are SkillPath AI's personal career mentor.",
                user_prompt=user_message,
                context=context
            )
            if llm_result:
                return {
                    "summary": f"Mentor response generated via {settings.LLM_PROVIDER}.",
                    "response": llm_result,
                    "provider": settings.LLM_PROVIDER
                }

        # Deterministic intelligent contextual engine
        # 1. Career Readiness / "How ready am I?"
        if any(w in lower_msg for w in ["ready", "readiness", "score", "chance", "how close", "am i ready"]):
            strength_names = [s.get("skill_name") for s in strengths[:3]]
            missing_names = [s.get("skill_name") for s in missing_skills[:3]]
            
            response = (
                f"Hello {learner_name}! Based on your verified learning telemetry, your current **Career Readiness Score is {career_score}%** for the **{career_title}** role.\n\n"
                f"**Key Strengths Already Established:**\n"
                f"{chr(10).join(['• ' + s for s in strength_names]) if strength_names else '• Foundational computer science concepts.'}\n\n"
                f"**Immediate High-Priority Competencies to Acquire:**\n"
                f"{chr(10).join(['• ' + s for s in missing_names]) if missing_names else '• Advance into capstone project execution.'}\n\n"
                f"You have a strong trajectory! Focus on completing your active roadmap tasks to steadily bridge these competencies."
            )

        # 2. Roadmap / "What should I do next?" / "Next step"
        elif any(w in lower_msg for w in ["next", "step", "roadmap", "what should i do", "what to do", "start"]):
            if current_task:
                task_title = current_task.get("title", "Active Task")
                task_obj = current_task.get("learning_objective", "")
                task_ex = current_task.get("practical_exercise", "")
                task_res = current_task.get("resource_url", "")
                
                response = (
                    f"Your recommended immediate priority is to work on: **{task_title}**.\n\n"
                    f"**Core Objective:** {task_obj}\n\n"
                    f"**Hands-on Project:** {task_ex}\n\n"
                    f"**Recommended Study Resource:** [{task_title} Reference]({task_res})\n\n"
                    f"Completing this milestone directly improves your readiness by proving hands-on proficiency."
                )
            else:
                response = (
                    f"Your roadmap is currently looking great! You can choose an upcoming module from your Learning Roadmap page "
                    f"or take a quick skill assessment to verify your current level in Python, JavaScript, or React."
                )

        # 3. Assessment / "How did I do?" / "Test failure"
        elif any(w in lower_msg for w in ["assessment", "test", "quiz", "failed", "score", "passed", "exam"]):
            if recent_attempt:
                s_name = recent_attempt.get("skill_name", "Skill")
                score = recent_attempt.get("score", 0.0)
                passed = recent_attempt.get("passed", False)
                weak = recent_attempt.get("weak_concepts", [])

                if passed:
                    response = (
                        f"Great job on your recent **{s_name}** assessment! You scored **{int(score)}%**, successfully verifying your proficiency.\n\n"
                        f"This score has been incorporated by our Skill Analysis Agent to elevate your confidence rating. "
                        f"You are ready to advance to more complex architectural challenges or complementary stack tools!"
                    )
                else:
                    response = (
                        f"I noticed your recent **{s_name}** assessment score was **{int(score)}%**. Don't be discouraged at all—this diagnostic is designed to catch blind spots early!\n\n"
                        f"**Concepts needing review:** {', '.join(weak) if weak else 'Core asynchronous mechanics and state handling'}.\n\n"
                        f"Our Progress Agent has automatically adapted your roadmap to introduce targeted practice for these specific topics. "
                        f"Review the suggested documentation and re-test when you feel ready!"
                    )
            else:
                response = (
                    f"Taking skill assessments is the best way to convert 'Self-Declared' skills into empirically verified proficiencies with high confidence! "
                    f"Head over to the Assessment tab to test your JavaScript, React, Python, or SQL skills."
                )

        # 4. Career Goal Change / "AI Engineer" / "Full Stack" / "Career advice"
        elif any(w in lower_msg for w in ["ai engineer", "data scientist", "switch", "change career", "full stack", "career"]):
            response = (
                f"Exploring different trajectories is one of the superpower features of SkillPath AI! "
                f"You are currently targeting **{career_title}**.\n\n"
                f"If you decide to switch (for example, moving from Full Stack to AI Engineer), "
                f"our multi-agent orchestrator will instantly re-evaluate your existing transferable skills (like Python, Git, and problem solving), "
                f"highlight the new requirements (such as PyTorch and Machine Learning), and synthesize a fresh versioned roadmap while preserving all your past achievements.\n\n"
                f"You can try this anytime right from the **Career Matching** or **Learner Profile** page!"
            )

        # 5. Encouragement / Motivation
        elif any(w in lower_msg for w in ["hard", "stuck", "frustrated", "tired", "encourage", "help me"]):
            response = (
                f"Learning modern engineering can feel overwhelming at times, {learner_name}, but remember that every senior engineer was once where you are today!\n\n"
                f"Focus on **one concept at a time**. The best way to break through a plateau is to build a tiny micro-project that tests just that single concept. "
                f"Check your active roadmap module, write 10-20 lines of code to experiment with it, and celebrate that win.\n\n"
                f"I'm here with you every step of the way!"
            )

        # 6. Default Fallback
        else:
            response = (
                f"Hello {learner_name}! I am your AI Mentor on SkillPath AI, tuned to your real-time learning context.\n\n"
                f"• Target Career: **{career_title}** ({career_score}% Readiness)\n"
                f"• Preferred Learning Style: **{learner.get('preferred_learning_style', 'Hands-on')}**\n"
                f"• Active Task: **{current_task.get('title') if current_task else 'Select from Roadmap'}**\n\n"
                f"You can ask me questions like:\n"
                f"- *'How close am I to becoming a {career_title}?'*\n"
                f"- *'What should I learn next?'*\n"
                f"- *'How can I improve my JavaScript assessment score?'*\n"
                f"- *'What happens if I switch my career to AI Engineer?'*"
            )

        return {
            "summary": f"Contextual response provided for query: '{user_message[:50]}...'",
            "response": response,
            "provider": "deterministic_contextual_engine"
        }
