from typing import Dict, Any, List
from app.agents.base import BaseAgent

class ProfileAgent(BaseAgent):
    name = "Profile Agent"
    responsibility = "Processes profile completeness, normalizes skill levels, and constructs structured learner context."

    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        profile = context.get("profile", {})
        user = context.get("user", {})
        skills = context.get("learner_skills", [])

        missing_fields = []
        if not profile.get("education") or profile.get("education") == "Not Specified":
            missing_fields.append("Education Degree")
        if not profile.get("institution") or profile.get("institution") == "Not Specified":
            missing_fields.append("Institution / College")
        if not profile.get("projects") or len(profile.get("projects", [])) == 0:
            missing_fields.append("Completed Projects (helps calibrate practical evidence)")
        if not profile.get("soft_skills") or len(profile.get("soft_skills", [])) == 0:
            missing_fields.append("Soft Skills")
        if not profile.get("target_career_id"):
            missing_fields.append("Target Career Goal")

        # Organize skills by category
        categorized_skills: Dict[str, List[Dict[str, Any]]] = {}
        for s in skills:
            cat = s.get("category", "General")
            if cat not in categorized_skills:
                categorized_skills[cat] = []
            categorized_skills[cat].append({
                "skill_name": s.get("skill_name"),
                "proficiency_level": s.get("proficiency_level"),
                "confidence_level": s.get("confidence_level", 0.35),
                "evidence_source": s.get("evidence_source", "Self-Declared")
            })

        total_profile_attributes = 7
        filled_attributes = total_profile_attributes - len([f for f in missing_fields if "Target" not in f])
        completeness_pct = round(max(20.0, (filled_attributes / total_profile_attributes) * 100), 1)

        structured_context = {
            "user_id": user.get("id"),
            "full_name": user.get("full_name"),
            "email": user.get("email"),
            "education": profile.get("education", "Undergraduate"),
            "institution": profile.get("institution", "University / College"),
            "academic_year": profile.get("academic_year", "3rd Year"),
            "experience_level": profile.get("experience_level", "Beginner"),
            "preferred_learning_style": profile.get("preferred_learning_style", "Hands-on"),
            "target_career_id": profile.get("target_career_id"),
            "target_career_title": context.get("target_career_title", "Unassigned"),
            "categorized_skills": categorized_skills,
            "total_skills_count": len(skills),
            "profile_completeness_pct": completeness_pct,
            "missing_profile_fields": missing_fields,
            "has_practical_portfolio": len(profile.get("projects", [])) > 0,
            "certifications_count": len(profile.get("certifications", []))
        }

        return {
            "summary": f"Structured profile assembled for {user.get('full_name')} ({completeness_pct}% complete). {len(skills)} skills categorized across {len(categorized_skills)} domains.",
            "learner_context": structured_context,
            "completeness_score": completeness_pct,
            "missing_recommendations": missing_fields
        }
