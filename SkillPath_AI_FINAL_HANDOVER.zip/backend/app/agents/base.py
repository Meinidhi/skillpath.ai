from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
import time

class BaseAgent(ABC):
    """Base class for all SkillPath AI specialized agents."""
    name: str = "BaseAgent"
    responsibility: str = "Base agent responsibility"

    @abstractmethod
    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the agent's logic on the provided context."""
        pass

    def execute_with_logging(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Wrap execution with performance timing and structured payload."""
        start_time = time.time()
        try:
            result = self.run(context)
            elapsed_ms = int((time.time() - start_time) * 1000)
            return {
                "agent_name": self.name,
                "responsibility": self.responsibility,
                "status": "success",
                "execution_time_ms": elapsed_ms,
                "result": result
            }
        except Exception as e:
            elapsed_ms = int((time.time() - start_time) * 1000)
            return {
                "agent_name": self.name,
                "responsibility": self.responsibility,
                "status": "failed",
                "execution_time_ms": elapsed_ms,
                "error": str(e),
                "result": {}
            }
