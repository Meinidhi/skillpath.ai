from typing import Dict, Any, List
from app.agents.base import BaseAgent

PROFICIENCY_NUMERIC = {
    "Beginner": 1,
    "Intermediate": 2,
    "Advanced": 3,
    "Expert": 4
}

NUMERIC_TO_PROFICIENCY = {
    1: "Beginner",
    2: "Intermediate",
    3: "Advanced",
    4: "Expert"
}

class SkillAnalysisAgent(BaseAgent):
    name = "Skill Analysis Agent"
    responsibility = "Evaluates proficiency against empirical assessment evidence, weights confidence, and maps strengths/weaknesses."

    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        learner_skills = context.get("learner_skills", [])
        assessment_attempts = context.get("assessment_attempts", [])

        # Build attempt history index by skill_name
        skill_attempts: Dict[str, List[Dict[str, Any]]] = {}
        for a in assessment_attempts:
            s_name = a.get("skill_name")
            if s_name:
                if s_name not in skill_attempts:
                    skill_attempts[s_name] = []
                skill_attempts[s_name].append(a)

        analyzed_skills = []
        strengths = []
        weaknesses = []
        distribution = {"Beginner": 0, "Intermediate": 0, "Advanced": 0, "Expert": 0}
        category_counts: Dict[str, int] = {}
        category_scores: Dict[str, float] = {}

        total_confidence = 0.0

        for ls in learner_skills:
            name = ls.get("skill_name")
            category = ls.get("category", "General")
            prof_level = ls.get("proficiency_level", "Beginner")
            declared_evidence = ls.get("evidence_source", "Self-Declared")
            base_confidence = float(ls.get("confidence_level", 0.35))

            # Calibrate confidence and level based on empirical assessments
            recent_attempts = skill_attempts.get(name, [])
            if recent_attempts:
                latest_attempt = recent_attempts[-1]
                score = latest_attempt.get("score", 0.0)
                passed = latest_attempt.get("passed", False)
                
                # Empirical assessment overrides raw self-declaration
                if passed:
                    calibrated_conf = min(0.95, round(0.70 + (score / 100.0) * 0.25, 2))
                    evidence_label = f"Assessment Verified ({int(score)}%)"
                    # Upgrade proficiency if high score
                    numeric_curr = PROFICIENCY_NUMERIC.get(prof_level, 1)
                    if score >= 85 and numeric_curr < 3:
                        prof_level = "Advanced"
                    elif score >= 70 and numeric_curr < 2:
                        prof_level = "Intermediate"
                else:
                    calibrated_conf = min(0.60, round(0.30 + (score / 100.0) * 0.20, 2))
                    evidence_label = f"Assessment Deficit ({int(score)}%)"
                    # If failed with low score, flag under-proficiency
                    if score < 60:
                        prof_level = "Beginner"
            else:
                calibrated_conf = base_confidence
                evidence_label = declared_evidence

            distribution[prof_level] = distribution.get(prof_level, 0) + 1
            total_confidence += calibrated_conf

            skill_item = {
                "skill_name": name,
                "category": category,
                "proficiency_level": prof_level,
                "evidence_source": evidence_label,
                "confidence_level": calibrated_conf,
                "numeric_rank": PROFICIENCY_NUMERIC.get(prof_level, 1)
            }
            analyzed_skills.append(skill_item)

            # Categorize into Strengths vs Weaknesses
            if PROFICIENCY_NUMERIC.get(prof_level, 1) >= 2 and calibrated_conf >= 0.50:
                strengths.append(skill_item)
            elif calibrated_conf < 0.50 or prof_level == "Beginner":
                weaknesses.append(skill_item)

            # Category scores
            category_counts[category] = category_counts.get(category, 0) + 1
            category_scores[category] = category_scores.get(category, 0.0) + PROFICIENCY_NUMERIC.get(prof_level, 1)

        avg_confidence = round(total_confidence / max(1, len(learner_skills)), 2)
        category_coverage = {}
        for cat, count in category_counts.items():
            category_coverage[cat] = round((category_scores[cat] / (count * 4.0)) * 100.0, 1)

        # Determine overall proficiency tier
        avg_rank = sum(s["numeric_rank"] for s in analyzed_skills) / max(1, len(analyzed_skills))
        if avg_rank >= 3.2:
            overall_tier = "Advanced"
        elif avg_rank >= 2.0:
            overall_tier = "Intermediate"
        else:
            overall_tier = "Beginner"

        return {
            "summary": f"Analyzed {len(analyzed_skills)} skills: {len(strengths)} confirmed strengths, {len(weaknesses)} growth areas. Average evidence confidence: {int(avg_confidence * 100)}%.",
            "overall_proficiency": overall_tier,
            "analyzed_skills": analyzed_skills,
            "strengths": strengths,
            "weaknesses": weaknesses,
            "distribution": distribution,
            "category_coverage": category_coverage,
            "average_confidence": avg_confidence
        }
