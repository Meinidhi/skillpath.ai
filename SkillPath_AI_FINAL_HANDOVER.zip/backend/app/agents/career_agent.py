from typing import Dict, Any, List
from app.agents.base import BaseAgent
from app.agents.skill_agent import PROFICIENCY_NUMERIC

class CareerAgent(BaseAgent):
    name = "Career Agent"
    responsibility = "Benchmarks learner profile against career specifications, computes readiness scores, and prioritizes gaps."

    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        target_career = context.get("target_career", {})
        requirements = target_career.get("requirements", [])
        analyzed_skills = context.get("analyzed_skills", [])

        # Map learner skills by name (lowercased for robust matching)
        user_skill_map = {
            s["skill_name"].lower().strip(): s for s in analyzed_skills
        }

        meeting_skills = []
        underdeveloped_skills = []
        missing_skills = []
        critical_missing = []

        total_weight = 0.0
        earned_weight = 0.0

        importance_multipliers = {
            "Critical": 1.5,
            "High": 1.2,
            "Medium": 1.0,
            "Nice-to-have": 0.8
        }

        for req in requirements:
            skill_name = req.get("skill_name", "")
            req_prof = req.get("required_proficiency", "Intermediate")
            importance = req.get("importance", "High")
            multiplier = importance_multipliers.get(importance, 1.0)
            total_weight += (1.0 * multiplier)

            key = skill_name.lower().strip()
            user_skill = user_skill_map.get(key)

            req_rank = PROFICIENCY_NUMERIC.get(req_prof, 2)

            if user_skill:
                user_prof = user_skill.get("proficiency_level", "Beginner")
                user_rank = PROFICIENCY_NUMERIC.get(user_prof, 1)
                confidence = user_skill.get("confidence_level", 0.35)

                if user_rank >= req_rank:
                    meeting_skills.append({
                        "skill_name": skill_name,
                        "status": "meets",
                        "required_proficiency": req_prof,
                        "current_proficiency": user_prof,
                        "importance": importance,
                        "confidence": confidence
                    })
                    earned_weight += (1.0 * multiplier)
                else:
                    underdeveloped_skills.append({
                        "skill_name": skill_name,
                        "status": "underdeveloped",
                        "required_proficiency": req_prof,
                        "current_proficiency": user_prof,
                        "importance": importance,
                        "confidence": confidence
                    })
                    # Partial credit proportional to user_rank / req_rank
                    partial_ratio = min(0.75, user_rank / max(1, req_rank))
                    earned_weight += (partial_ratio * multiplier)
            else:
                missing_skills.append({
                    "skill_name": skill_name,
                    "status": "missing",
                    "required_proficiency": req_prof,
                    "current_proficiency": None,
                    "importance": importance,
                    "confidence": 0.0
                })
                if importance == "Critical":
                    critical_missing.append(skill_name)

        if total_weight > 0:
            readiness_score = round(min(100.0, (earned_weight / total_weight) * 100.0), 1)
        else:
            readiness_score = 0.0

        career_title = target_career.get("title", "Selected Role")
        breakdown_text = (
            f"Readiness Score: {readiness_score}% for {career_title}. "
            f"Formula: Sum(Earned Competency Weights: {round(earned_weight, 2)}) / "
            f"Sum(Total Required Weights: {round(total_weight, 2)}). "
            f"Meeting: {len(meeting_skills)}, Underdeveloped: {len(underdeveloped_skills)}, Missing: {len(missing_skills)}."
        )

        return {
            "summary": breakdown_text,
            "career_id": target_career.get("id"),
            "career_title": career_title,
            "career_readiness_score": readiness_score,
            "formula_breakdown": breakdown_text,
            "meeting_skills": meeting_skills,
            "underdeveloped_skills": underdeveloped_skills,
            "missing_skills": missing_skills,
            "critical_missing": critical_missing,
            "total_required": len(requirements)
        }
