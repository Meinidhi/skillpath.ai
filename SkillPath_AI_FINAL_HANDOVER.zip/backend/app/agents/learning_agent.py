from typing import Dict, Any, List
from app.agents.base import BaseAgent

# Practical exercises and mini-projects per skill
SKILL_PRACTICAL_EXERCISES = {
    "JavaScript": {
        "objective": "Master asynchronous JavaScript, DOM manipulation, and closure patterns.",
        "exercise": "Build an asynchronous Weather & Currency Converter dashboard utilizing Fetch API, error boundaries, and debounce utilities.",
        "duration_days": 7
    },
    "React": {
        "objective": "Design reusable component hierarchies with custom hooks, memoization, and Context.",
        "exercise": "Develop an interactive Kanban Task Board with drag-and-drop state, persistent local storage, and filter tags.",
        "duration_days": 10
    },
    "Node.js": {
        "objective": "Build event-driven RESTful backends using Express or native HTTP, streams, and middleware.",
        "exercise": "Create an authenticated File Upload and Processing Microservice with rate limiting and JWT auth middleware.",
        "duration_days": 8
    },
    "Python": {
        "objective": "Master idiomatic Python, generator pipelines, OOP encapsulation, and package architecture.",
        "exercise": "Construct an automated Log Parser & Performance Profiler that streams GB-sized logs using generators and dataclasses.",
        "duration_days": 7
    },
    "FastAPI": {
        "objective": "Implement high-throughput asynchronous REST APIs with Pydantic validation and dependency injection.",
        "exercise": "Build a multi-tenant Inventory Management REST API complete with SQLite persistence and Swagger documentation.",
        "duration_days": 6
    },
    "SQL & Databases": {
        "objective": "Master complex relational queries, multi-table joins, subqueries, and transaction management.",
        "exercise": "Design an E-Commerce relational schema, write complex window functions for monthly revenue trends, and optimize indexes with EXPLAIN QUERY PLAN.",
        "duration_days": 7
    },
    "PostgreSQL": {
        "objective": "Leverage advanced SQL, JSONB indexing, triggers, and full-text search.",
        "exercise": "Implement a real-time event analytics schema using JSONB containment operators and GIN indexes.",
        "duration_days": 6
    },
    "HTML/CSS": {
        "objective": "Create semantic, accessible (WCAG AA), and fully responsive multi-screen layouts.",
        "exercise": "Code a responsive SaaS pricing and features comparison grid using CSS Grid and Flexbox without CSS frameworks.",
        "duration_days": 5
    },
    "Machine Learning": {
        "objective": "Train and evaluate supervised classification and regression pipelines using Scikit-Learn.",
        "exercise": "Build an end-to-end Customer Churn Prediction pipeline with cross-validation, feature scaling, ROC-AUC evaluation, and model serialization.",
        "duration_days": 12
    },
    "Deep Learning & PyTorch": {
        "objective": "Implement feedforward and convolutional neural networks from scratch in PyTorch.",
        "exercise": "Train a custom ResNet-style image classifier on Fashion-MNIST with learning rate scheduling and early stopping.",
        "duration_days": 14
    },
    "Pandas & Data Analysis": {
        "objective": "Wrangle, clean, and aggregate multi-source tabular data with NumPy and Pandas.",
        "exercise": "Perform Exploratory Data Analysis on a 500k-row Kaggle dataset, handling missing values and exporting pivot summaries.",
        "duration_days": 6
    },
    "Docker & Containers": {
        "objective": "Containerize full-stack services using multi-stage Dockerfiles and Docker Compose.",
        "exercise": "Write a production multi-stage Dockerfile for a React frontend and Python FastAPI backend orchestrated with Docker Compose.",
        "duration_days": 5
    },
    "Git & Version Control": {
        "objective": "Master git branching strategies, interactive rebasing, merge conflicts, and PR reviews.",
        "exercise": "Simulate an open-source contribution workflow with feature branches, squashed commits, and conflict resolution in a local repo.",
        "duration_days": 4
    },
    "Cybersecurity Fundamentals": {
        "objective": "Understand OWASP Top 10 vulnerabilities, authentication vulnerabilities, and security hardening.",
        "exercise": "Audit a vulnerable demo web app for SQL Injection and XSS, and implement parameterized queries and CSP headers to fix them.",
        "duration_days": 8
    },
    "Cloud Computing (AWS)": {
        "objective": "Deploy scalable applications on cloud infrastructure using IAM, EC2, S3, and API Gateway.",
        "exercise": "Deploy a serverless static website on S3 with CloudFront CDN distribution and an API Gateway backend.",
        "duration_days": 9
    }
}

class LearningAgent(BaseAgent):
    name = "Learning Agent"
    responsibility = "Synthesizes competency gaps and career requirements into a sequentially sequenced, personalized learning roadmap."

    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        missing_skills = context.get("missing_skills", [])
        underdeveloped_skills = context.get("underdeveloped_skills", [])
        resources = context.get("resources", [])
        preferred_style = context.get("preferred_learning_style", "Hands-on")
        trigger = context.get("trigger", "Initial")
        reason = context.get("change_reason", "Initial tailored curriculum generation.")

        # Build resource lookup map: skill_name -> list of resources
        resource_map: Dict[str, List[Dict[str, Any]]] = {}
        for r in resources:
            s_name = r.get("skill_name")
            if s_name:
                if s_name not in resource_map:
                    resource_map[s_name] = []
                resource_map[s_name].append(r)

        # Prioritize items:
        # 1. Critical Missing Skills
        # 2. High Missing Skills
        # 3. Underdeveloped Skills (needing elevation)
        # 4. Medium / Nice-to-have
        def sort_key(item):
            importance_rank = {"Critical": 0, "High": 1, "Medium": 2, "Nice-to-have": 3}
            status_rank = {"missing": 0, "underdeveloped": 1}
            return (
                status_rank.get(item.get("status"), 2),
                importance_rank.get(item.get("importance"), 2)
            )

        combined_candidates = missing_skills + underdeveloped_skills
        combined_candidates.sort(key=sort_key)

        roadmap_items = []
        for index, cand in enumerate(combined_candidates):
            skill_name = cand.get("skill_name")
            importance = cand.get("importance", "High")
            status_type = cand.get("status", "missing")
            req_prof = cand.get("required_proficiency", "Intermediate")

            # Match practical exercise template or generate dynamic
            exercise_data = SKILL_PRACTICAL_EXERCISES.get(skill_name, {
                "objective": f"Acquire professional {req_prof} competence in {skill_name}.",
                "exercise": f"Implement a standalone mini-project demonstrating key concepts and industry standards in {skill_name}.",
                "duration_days": 7
            })

            # Select most suitable resource matching learner's style
            skill_res_list = resource_map.get(skill_name, [])
            selected_url = "https://freecodecamp.org"
            if skill_res_list:
                # If hands-on preferred, try to find Interactive first
                interactive_matches = [res for res in skill_res_list if res.get("resource_type") == preferred_style or res.get("resource_type") == "Interactive"]
                if interactive_matches:
                    selected_url = interactive_matches[0].get("url")
                else:
                    selected_url = skill_res_list[0].get("url")

            roadmap_items.append({
                "skill_name": skill_name,
                "title": f"Master {skill_name} ({req_prof} Level)",
                "learning_objective": exercise_data["objective"],
                "priority": importance,
                "difficulty": req_prof,
                "estimated_duration_days": exercise_data["duration_days"],
                "status": "pending",
                "resource_url": selected_url,
                "practical_exercise": exercise_data["exercise"],
                "order_index": index + 1
            })

        summary_text = (
            f"Synthesized personalized roadmap with {len(roadmap_items)} sequential modules. "
            f"Prioritizes {len([i for i in roadmap_items if i['priority'] == 'Critical'])} critical career competencies "
            f"adapted for a '{preferred_style}' learning methodology."
        )

        return {
            "summary": summary_text,
            "roadmap_items": roadmap_items,
            "total_items": len(roadmap_items),
            "estimated_total_weeks": sum(item["estimated_duration_days"] for item in roadmap_items) // 7,
            "trigger": trigger,
            "change_reason": reason
        }
