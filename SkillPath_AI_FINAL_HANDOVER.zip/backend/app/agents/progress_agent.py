from typing import Dict, Any, List
from app.agents.base import BaseAgent

class ProgressAgent(BaseAgent):
    name = "Progress Agent"
    responsibility = "Monitors milestone attainment, evaluates assessment outcomes, detects concept deficits, and triggers adaptive interventions."

    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        action_type = context.get("action_type", "EVALUATE_ASSESSMENT")
        
        if action_type == "EVALUATE_ASSESSMENT":
            attempt = context.get("assessment_attempt", {})
            skill_name = attempt.get("skill_name", "Skill")
            score = attempt.get("score", 0.0)
            passed = attempt.get("passed", False)
            weak_concepts = attempt.get("weak_concepts", [])

            is_poor_performance = score < 65.0

            if is_poor_performance:
                adaptation_summary = (
                    f"Performance Deficit Detected in {skill_name} ({int(score)}%). "
                    f"Identified foundational gaps in: {', '.join(weak_concepts) if weak_concepts else 'Core concepts'}. "
                    f"Triggered Adaptive Intervention: Roadmap reprioritized to include targeted remedial exercises "
                    f"and prerequisite reinforcement before advancing."
                )
                recommendation = {
                    "action": "ADAPT_ROADMAP_REVISION",
                    "skill_name": skill_name,
                    "target_concepts": weak_concepts,
                    "remedial_task": {
                        "title": f"Reinforce {skill_name} Fundamentals: {', '.join(weak_concepts[:2]) if weak_concepts else 'Core Concepts'}",
                        "learning_objective": f"Review targeted concepts ({', '.join(weak_concepts)}) and solve targeted debugging exercises.",
                        "practical_exercise": f"Complete 5 targeted coding drills focusing specifically on {', '.join(weak_concepts)} with unit tests.",
                        "priority": "Critical",
                        "difficulty": "Beginner",
                        "estimated_duration_days": 4,
                        "status": "needs_revision"
                    },
                    "explanation": adaptation_summary
                }
            else:
                adaptation_summary = (
                    f"Proficiency Verified in {skill_name} ({int(score)}%). "
                    f"Assessment passed successfully. Skill confidence elevated to empirical verification status."
                )
                recommendation = {
                    "action": "UPGRADE_PROFICIENCY",
                    "skill_name": skill_name,
                    "explanation": adaptation_summary
                }

            return {
                "summary": adaptation_summary,
                "is_poor_performance": is_poor_performance,
                "score": score,
                "passed": passed,
                "weak_concepts": weak_concepts,
                "recommendation": recommendation
            }

        elif action_type == "CALCULATE_OVERVIEW":
            # Progress overview computation
            roadmap_items = context.get("roadmap_items", [])
            completed_items = [i for i in roadmap_items if i.get("status") == "completed"]
            total_items = max(1, len(roadmap_items))
            roadmap_pct = round((len(completed_items) / total_items) * 100.0, 1)

            attempts = context.get("assessment_attempts", [])
            avg_score = round(sum(a.get("score", 0.0) for a in attempts) / max(1, len(attempts)), 1) if attempts else 0.0

            return {
                "summary": f"Progress: {len(completed_items)}/{total_items} roadmap modules completed ({roadmap_pct}%). {len(attempts)} assessments attempted with average score of {avg_score}%.",
                "roadmap_completion_pct": roadmap_pct,
                "completed_tasks_count": len(completed_items),
                "total_tasks_count": total_items,
                "assessments_count": len(attempts),
                "average_assessment_score": avg_score
            }

        return {
            "summary": "Progress evaluation completed.",
            "status": "success"
        }
