import uuid
import datetime
from typing import Dict, Any, List, Optional
from sqlalchemy.orm import Session

from app.models.models import (
    User, LearnerProfile, LearnerSkill, CareerRole, CareerRequirement,
    LearningResource, LearningRoadmap, RoadmapVersion, RoadmapItem,
    AssessmentAttempt, AgentExecution
)
from app.agents.profile_agent import ProfileAgent
from app.agents.skill_agent import SkillAnalysisAgent
from app.agents.career_agent import CareerAgent
from app.agents.learning_agent import LearningAgent
from app.agents.progress_agent import ProgressAgent
from app.agents.mentor_agent import AIMentorAgent

class AgentOrchestrator:
    """
    Central Orchestrator for SkillPath AI Multi-Agent Architecture.
    Dispatches tasks to the 6 specialized agents in sequence,
    manages context flow, logs execution records to the database,
    and returns validated consolidated workflows.
    """

    def __init__(self, db: Session):
        self.db = db
        self.profile_agent = ProfileAgent()
        self.skill_agent = SkillAnalysisAgent()
        self.career_agent = CareerAgent()
        self.learning_agent = LearningAgent()
        self.progress_agent = ProgressAgent()
        self.mentor_agent = AIMentorAgent()

    def _log_execution(self, user_id: int, workflow_id: str, agent_exec_data: Dict[str, Any]) -> AgentExecution:
        """Persist execution log entry for the Agent Activity Monitor."""
        record = AgentExecution(
            user_id=user_id,
            workflow_id=workflow_id,
            agent_name=agent_exec_data.get("agent_name", "Unknown Agent"),
            responsibility=agent_exec_data.get("responsibility", ""),
            status=agent_exec_data.get("status", "success"),
            input_summary=agent_exec_data.get("input_summary", "Structured Context Ingested"),
            output_summary=agent_exec_data.get("result", {}).get("summary", "Step executed successfully"),
            full_payload=agent_exec_data.get("result", {}),
            execution_time_ms=agent_exec_data.get("execution_time_ms", 0),
            timestamp=datetime.datetime.utcnow()
        )
        self.db.add(record)
        self.db.commit()
        self.db.refresh(record)
        return record

    def _build_base_context(self, user_id: int) -> Dict[str, Any]:
        """Fetch real user state from database to seed agent context."""
        user = self.db.query(User).filter(User.id == user_id).first()
        profile = self.db.query(LearnerProfile).filter(LearnerProfile.user_id == user_id).first()
        learner_skills = self.db.query(LearnerSkill).filter(LearnerSkill.user_id == user_id).all()
        assessment_attempts = self.db.query(AssessmentAttempt).filter(AssessmentAttempt.user_id == user_id).all()

        target_career = None
        target_career_title = "Unassigned"
        if profile and profile.target_career_id:
            career_obj = self.db.query(CareerRole).filter(CareerRole.id == profile.target_career_id).first()
            if career_obj:
                target_career_title = career_obj.title
                reqs = []
                for r in career_obj.requirements:
                    reqs.append({
                        "skill_name": r.skill.name if r.skill else "",
                        "required_proficiency": r.required_proficiency,
                        "importance": r.importance,
                        "prerequisites": r.prerequisite_skills or []
                    })
                target_career = {
                    "id": career_obj.id,
                    "title": career_obj.title,
                    "category": career_obj.category,
                    "requirements": reqs
                }

        # Format learner skills
        formatted_skills = []
        for ls in learner_skills:
            formatted_skills.append({
                "skill_name": ls.skill.name if ls.skill else "Unknown",
                "category": ls.skill.category if ls.skill else "General",
                "proficiency_level": ls.proficiency_level,
                "confidence_level": ls.confidence_level,
                "evidence_source": ls.evidence_source
            })

        # Format assessment attempts
        formatted_attempts = []
        for at in assessment_attempts:
            formatted_attempts.append({
                "id": at.id,
                "skill_name": at.assessment.skill.name if at.assessment and at.assessment.skill else "Skill",
                "score": at.score,
                "passed": at.passed,
                "weak_concepts": at.weak_concepts or []
            })

        # Format resources
        all_resources = self.db.query(LearningResource).all()
        formatted_resources = []
        for res in all_resources:
            formatted_resources.append({
                "skill_name": res.skill.name if res.skill else "",
                "title": res.title,
                "url": res.url,
                "provider": res.provider,
                "resource_type": res.resource_type,
                "difficulty": res.difficulty
            })

        return {
            "user": {
                "id": user.id if user else user_id,
                "full_name": user.full_name if user else "Learner",
                "email": user.email if user else ""
            },
            "profile": {
                "education": profile.education if profile else "Undergraduate",
                "institution": profile.institution if profile else "University",
                "academic_year": profile.academic_year if profile else "3rd Year",
                "experience_level": profile.experience_level if profile else "Beginner",
                "preferred_learning_style": profile.preferred_learning_style if profile else "Hands-on",
                "target_career_id": profile.target_career_id if profile else None,
                "soft_skills": profile.soft_skills if profile else [],
                "certifications": profile.certifications if profile else [],
                "projects": profile.projects if profile else []
            },
            "target_career_title": target_career_title,
            "target_career": target_career,
            "learner_skills": formatted_skills,
            "assessment_attempts": formatted_attempts,
            "resources": formatted_resources
        }

    def run_full_analysis_workflow(self, user_id: int, trigger: str = "Initial") -> Dict[str, Any]:
        """
        Executes complete pipeline:
        ProfileAgent -> SkillAnalysisAgent -> CareerAgent -> LearningAgent
        """
        workflow_id = f"wf-{uuid.uuid4().hex[:8]}"
        context = self._build_base_context(user_id)
        context["trigger"] = trigger

        executions_logged = []

        # 1. Profile Agent
        prof_res = self.profile_agent.execute_with_logging(context)
        prof_res["input_summary"] = f"Ingested profile data for User #{user_id}"
        rec1 = self._log_execution(user_id, workflow_id, prof_res)
        executions_logged.append(rec1)

        context["learner_context"] = prof_res["result"].get("learner_context", {})

        # 2. Skill Analysis Agent
        skill_res = self.skill_agent.execute_with_logging(context)
        skill_res["input_summary"] = f"Evaluating {len(context['learner_skills'])} skills against {len(context['assessment_attempts'])} assessments"
        rec2 = self._log_execution(user_id, workflow_id, skill_res)
        executions_logged.append(rec2)

        context["analyzed_skills"] = skill_res["result"].get("analyzed_skills", [])
        context["strengths"] = skill_res["result"].get("strengths", [])
        context["weaknesses"] = skill_res["result"].get("weaknesses", [])

        # 3. Career Agent
        career_res = self.career_agent.execute_with_logging(context)
        career_title = context.get("target_career_title", "Selected Role")
        career_res["input_summary"] = f"Matching skills against {career_title} specifications"
        rec3 = self._log_execution(user_id, workflow_id, career_res)
        executions_logged.append(rec3)

        context["career_readiness_score"] = career_res["result"].get("career_readiness_score", 0.0)
        context["missing_skills"] = career_res["result"].get("missing_skills", [])
        context["underdeveloped_skills"] = career_res["result"].get("underdeveloped_skills", [])
        context["meeting_skills"] = career_res["result"].get("meeting_skills", [])

        # 4. Learning Agent (Generate Roadmap)
        learn_res = self.learning_agent.execute_with_logging(context)
        learn_res["input_summary"] = f"Generating personalized roadmap for {len(context['missing_skills'])} missing competencies"
        rec4 = self._log_execution(user_id, workflow_id, learn_res)
        executions_logged.append(rec4)

        # Persist new roadmap and version in SQLite
        roadmap_items_data = learn_res["result"].get("roadmap_items", [])
        self._persist_roadmap(user_id, context, roadmap_items_data, trigger=trigger, reason=learn_res["result"].get("summary"))

        return {
            "workflow_id": workflow_id,
            "trigger": trigger,
            "status": "success",
            "agents_executed": ["Profile Agent", "Skill Analysis Agent", "Career Agent", "Learning Agent"],
            "summary": f"Full learning pipeline completed successfully. Career readiness: {context['career_readiness_score']}%.",
            "executions": executions_logged,
            "details": {
                "profile": prof_res["result"],
                "skill_analysis": skill_res["result"],
                "career_match": career_res["result"],
                "learning_roadmap": learn_res["result"]
            }
        }

    def run_career_goal_change_workflow(self, user_id: int, new_career_id: int) -> Dict[str, Any]:
        """
        SCENARIO A: Career Goal Change
        Updates career goal, recalculates requirements, reassesses current skills,
        synthesizes a fresh roadmap version, preserves previous history, and explains what changed.
        """
        workflow_id = f"wf-career-change-{uuid.uuid4().hex[:8]}"

        # 1. Update Profile in DB
        profile = self.db.query(LearnerProfile).filter(LearnerProfile.user_id == user_id).first()
        old_career_id = profile.target_career_id if profile else None
        old_career = self.db.query(CareerRole).filter(CareerRole.id == old_career_id).first() if old_career_id else None
        new_career = self.db.query(CareerRole).filter(CareerRole.id == new_career_id).first()

        old_title = old_career.title if old_career else "None"
        new_title = new_career.title if new_career else "New Career"

        if profile:
            profile.target_career_id = new_career_id
            self.db.commit()

        context = self._build_base_context(user_id)
        context["trigger"] = "CareerGoalChange"
        change_reason = f"Career objective transitioned from '{old_title}' to '{new_title}'. Recalibrated skill priorities and synthesized a tailored curriculum."
        context["change_reason"] = change_reason

        executions_logged = []

        # 1. Profile Agent
        prof_res = self.profile_agent.execute_with_logging(context)
        prof_res["input_summary"] = f"Learner changed career ambition to {new_title}"
        rec1 = self._log_execution(user_id, workflow_id, prof_res)
        executions_logged.append(rec1)

        # 2. Skill Analysis Agent
        skill_res = self.skill_agent.execute_with_logging(context)
        rec2 = self._log_execution(user_id, workflow_id, skill_res)
        executions_logged.append(rec2)

        context["analyzed_skills"] = skill_res["result"].get("analyzed_skills", [])
        context["strengths"] = skill_res["result"].get("strengths", [])
        context["weaknesses"] = skill_res["result"].get("weaknesses", [])

        # 3. Career Agent (Recalculate against new career)
        career_res = self.career_agent.execute_with_logging(context)
        career_res["input_summary"] = f"Recalculating competency match for {new_title}"
        rec3 = self._log_execution(user_id, workflow_id, career_res)
        executions_logged.append(rec3)

        context["career_readiness_score"] = career_res["result"].get("career_readiness_score", 0.0)
        context["missing_skills"] = career_res["result"].get("missing_skills", [])
        context["underdeveloped_skills"] = career_res["result"].get("underdeveloped_skills", [])

        # 4. Learning Agent (Generate new roadmap version)
        learn_res = self.learning_agent.execute_with_logging(context)
        rec4 = self._log_execution(user_id, workflow_id, learn_res)
        executions_logged.append(rec4)

        # Persist new roadmap version while preserving prior versions
        roadmap_items_data = learn_res["result"].get("roadmap_items", [])
        self._persist_roadmap(
            user_id, context, roadmap_items_data,
            trigger="CareerGoalChange",
            reason=change_reason
        )

        return {
            "workflow_id": workflow_id,
            "trigger": "CareerGoalChange",
            "status": "success",
            "agents_executed": ["Profile Agent", "Skill Analysis Agent", "Career Agent", "Learning Agent"],
            "summary": f"Career goal successfully transitioned to {new_title}. Career readiness score recalculated to {context['career_readiness_score']}%. New roadmap version created.",
            "executions": executions_logged,
            "change_explanation": {
                "from_career": old_title,
                "to_career": new_title,
                "new_readiness_score": context["career_readiness_score"],
                "newly_required_skills": [s["skill_name"] for s in context["missing_skills"]],
                "transferable_strengths": [s["skill_name"] for s in context["strengths"]],
                "explanation": change_reason
            }
        }

    def run_assessment_adaptation_workflow(self, user_id: int, attempt_id: int) -> Dict[str, Any]:
        """
        SCENARIO B: Poor Assessment Performance Adaptation
        Evaluates assessment outcome, detects weak concept tags,
        updates verified skill evidence in DB, recommends revision resources,
        injects targeted practice into the active roadmap, creates a new roadmap version,
        and explains why the learning path changed.
        """
        workflow_id = f"wf-assessment-adapt-{uuid.uuid4().hex[:8]}"

        attempt = self.db.query(AssessmentAttempt).filter(AssessmentAttempt.id == attempt_id).first()
        if not attempt:
            return {"status": "error", "message": "Assessment attempt not found"}

        skill_obj = attempt.assessment.skill if attempt.assessment else None
        skill_name = skill_obj.name if skill_obj else "Skill"

        context = self._build_base_context(user_id)
        context["action_type"] = "EVALUATE_ASSESSMENT"
        context["assessment_attempt"] = {
            "id": attempt.id,
            "skill_name": skill_name,
            "score": attempt.score,
            "passed": attempt.passed,
            "weak_concepts": attempt.weak_concepts or []
        }

        executions_logged = []

        # 1. Progress Agent evaluates outcome
        prog_res = self.progress_agent.execute_with_logging(context)
        prog_res["input_summary"] = f"Evaluated attempt on {skill_name} (Score: {int(attempt.score)}%)"
        rec1 = self._log_execution(user_id, workflow_id, prog_res)
        executions_logged.append(rec1)

        is_poor = prog_res["result"].get("is_poor_performance", False)

        # 2. Update LearnerSkill record in DB with empirical evidence
        learner_skill = self.db.query(LearnerSkill).filter(
            LearnerSkill.user_id == user_id,
            LearnerSkill.skill_id == skill_obj.id if skill_obj else 0
        ).first()

        if not learner_skill and skill_obj:
            learner_skill = LearnerSkill(
                user_id=user_id,
                skill_id=skill_obj.id,
                proficiency_level="Beginner",
                evidence_source="Assessment",
                confidence_level=0.5
            )
            self.db.add(learner_skill)

        if learner_skill:
            if attempt.passed:
                learner_skill.confidence_level = min(0.95, round(0.70 + (attempt.score / 100.0) * 0.25, 2))
                learner_skill.evidence_source = f"Assessment Verified ({int(attempt.score)}%)"
                if attempt.score >= 85:
                    learner_skill.proficiency_level = "Advanced"
                else:
                    learner_skill.proficiency_level = "Intermediate"
            else:
                learner_skill.confidence_level = min(0.60, round(0.30 + (attempt.score / 100.0) * 0.20, 2))
                learner_skill.evidence_source = f"Assessment Deficit ({int(attempt.score)}%)"
                learner_skill.proficiency_level = "Beginner"
            learner_skill.last_assessed_date = datetime.datetime.utcnow()
            self.db.commit()

        # If poor performance, trigger Adaptive Learning Path Adjustment
        adaptation_details = None
        if is_poor:
            # Inject remedial task and adapt roadmap
            weak_tags = attempt.weak_concepts or ["Core concepts"]
            remedial_title = f"Remedial Practice: {skill_name} ({', '.join(weak_tags[:2])})"
            change_reason = (
                f"Assessment diagnostic in {skill_name} flagged performance deficit ({int(attempt.score)}%). "
                f"Prioritized remedial modules on {', '.join(weak_tags)} to solidify comprehension before advancement."
            )

            # Re-run Skill Agent and Career Agent to refresh overall picture
            context = self._build_base_context(user_id)
            skill_res = self.skill_agent.execute_with_logging(context)
            rec2 = self._log_execution(user_id, workflow_id, skill_res)
            executions_logged.append(rec2)

            context["analyzed_skills"] = skill_res["result"].get("analyzed_skills", [])
            career_res = self.career_agent.execute_with_logging(context)
            rec3 = self._log_execution(user_id, workflow_id, career_res)
            executions_logged.append(rec3)

            # Adapt roadmap
            roadmap = self.db.query(LearningRoadmap).filter(
                LearningRoadmap.user_id == user_id,
                LearningRoadmap.is_active == True
            ).first()

            if roadmap:
                new_version_num = roadmap.current_version + 1
                roadmap.current_version = new_version_num

                new_version = RoadmapVersion(
                    roadmap_id=roadmap.id,
                    version_number=new_version_num,
                    change_trigger="AssessmentAdaptation",
                    change_reason=change_reason,
                    summary=f"Adapted for remedial {skill_name} practice after diagnostic score of {int(attempt.score)}%."
                )
                self.db.add(new_version)
                self.db.flush()

                # Add remedial item at index 0 (top priority)
                remedial_item = RoadmapItem(
                    roadmap_version_id=new_version.id,
                    skill_id=skill_obj.id if skill_obj else 1,
                    title=remedial_title,
                    learning_objective=f"Review and reinforce weak concepts: {', '.join(weak_tags)}.",
                    priority="Critical",
                    difficulty="Beginner",
                    estimated_duration_days=3,
                    status="needs_revision",
                    resource_url="https://developer.mozilla.org" if "JavaScript" in skill_name else "https://docs.python.org",
                    practical_exercise=f"Complete targeted debugging exercises focusing specifically on {', '.join(weak_tags)}.",
                    order_index=0
                )
                self.db.add(remedial_item)

                # Clone active pending tasks with shifted order
                latest_old_version = self.db.query(RoadmapVersion).filter(
                    RoadmapVersion.roadmap_id == roadmap.id,
                    RoadmapVersion.version_number == new_version_num - 1
                ).first()

                if latest_old_version:
                    for idx, old_item in enumerate(latest_old_version.items):
                        cloned_item = RoadmapItem(
                            roadmap_version_id=new_version.id,
                            skill_id=old_item.skill_id,
                            title=old_item.title,
                            learning_objective=old_item.learning_objective,
                            priority=old_item.priority,
                            difficulty=old_item.difficulty,
                            estimated_duration_days=old_item.estimated_duration_days,
                            status=old_item.status,
                            resource_url=old_item.resource_url,
                            practical_exercise=old_item.practical_exercise,
                            order_index=idx + 1
                        )
                        self.db.add(cloned_item)

                self.db.commit()

            adaptation_details = {
                "triggered": True,
                "skill_name": skill_name,
                "score": attempt.score,
                "weak_concepts": weak_tags,
                "remedial_action_taken": remedial_title,
                "explanation": change_reason
            }

        return {
            "workflow_id": workflow_id,
            "trigger": "AssessmentAdaptation",
            "status": "success",
            "agents_executed": [e.agent_name for e in executions_logged],
            "summary": prog_res["result"].get("summary"),
            "executions": executions_logged,
            "adaptation": adaptation_details
        }

    def _persist_roadmap(self, user_id: int, context: Dict[str, Any], items_data: List[Dict[str, Any]], trigger: str, reason: str):
        """Helper to create or update versioned roadmap in database."""
        target_career_id = context.get("target_career", {}).get("id")
        if not target_career_id:
            first_career = self.db.query(CareerRole).first()
            target_career_id = first_career.id if first_career else 1

        roadmap = self.db.query(LearningRoadmap).filter(
            LearningRoadmap.user_id == user_id,
            LearningRoadmap.is_active == True
        ).first()

        if not roadmap:
            roadmap = LearningRoadmap(
                user_id=user_id,
                career_id=target_career_id,
                current_version=1,
                is_active=True
            )
            self.db.add(roadmap)
            self.db.flush()
            version_num = 1
        else:
            roadmap.career_id = target_career_id
            version_num = roadmap.current_version + 1
            roadmap.current_version = version_num

        version = RoadmapVersion(
            roadmap_id=roadmap.id,
            version_number=version_num,
            change_trigger=trigger,
            change_reason=reason,
            summary=f"Version {version_num} synthesized ({len(items_data)} learning modules)."
        )
        self.db.add(version)
        self.db.flush()

        # Fetch skill map
        skills = {s.name: s.id for s in self.db.query(Skill).all()}

        for item in items_data:
            s_name = item.get("skill_name")
            s_id = skills.get(s_name, 1)

            roadmap_item = RoadmapItem(
                roadmap_version_id=version.id,
                skill_id=s_id,
                title=item.get("title", f"Learn {s_name}"),
                learning_objective=item.get("learning_objective", ""),
                priority=item.get("priority", "High"),
                difficulty=item.get("difficulty", "Intermediate"),
                estimated_duration_days=item.get("estimated_duration_days", 7),
                status=item.get("status", "pending"),
                resource_url=item.get("resource_url"),
                practical_exercise=item.get("practical_exercise"),
                order_index=item.get("order_index", 0)
            )
            self.db.add(roadmap_item)

        self.db.commit()
