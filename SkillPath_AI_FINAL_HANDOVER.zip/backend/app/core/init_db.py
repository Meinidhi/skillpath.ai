from sqlalchemy.orm import Session
from app.core.database import Base, engine, SessionLocal
from app.core.security import get_password_hash
from app.models.models import (
    User, LearnerProfile, Skill, LearnerSkill, CareerRole, CareerRequirement,
    LearningResource, Assessment, AssessmentQuestion
)
from app.data.seed_data import (
    SEED_SKILLS, SEED_CAREERS, SEED_RESOURCES, SEED_ASSESSMENTS
)

def init_db(db: Session) -> None:
    # 1. Create tables if they do not exist
    Base.metadata.create_all(bind=engine)

    # 2. Seed Skills
    existing_skills_count = db.query(Skill).count()
    skill_map = {}
    if existing_skills_count == 0:
        for s_data in SEED_SKILLS:
            skill = Skill(
                name=s_data["name"],
                category=s_data["category"],
                description=s_data.get("description", "")
            )
            db.add(skill)
        db.commit()
    
    # Reload skills into lookup map
    for s in db.query(Skill).all():
        skill_map[s.name] = s

    # 3. Seed Careers & Requirements
    existing_careers_count = db.query(CareerRole).count()
    if existing_careers_count == 0:
        for c_data in SEED_CAREERS:
            career = CareerRole(
                title=c_data["title"],
                category=c_data["category"],
                description=c_data["description"],
                average_salary=c_data.get("average_salary", "$100,000"),
                growth_rate=c_data.get("growth_rate", "+20%")
            )
            db.add(career)
            db.flush()

            for req in c_data.get("requirements", []):
                skill_obj = skill_map.get(req["skill"])
                if skill_obj:
                    career_req = CareerRequirement(
                        career_id=career.id,
                        skill_id=skill_obj.id,
                        required_proficiency=req.get("required_proficiency", "Intermediate"),
                        importance=req.get("importance", "Critical"),
                        prerequisite_skills=req.get("prerequisites", [])
                    )
                    db.add(career_req)
        db.commit()

    # 4. Seed Learning Resources
    existing_resources_count = db.query(LearningResource).count()
    if existing_resources_count == 0:
        for r_data in SEED_RESOURCES:
            skill_obj = skill_map.get(r_data["skill"])
            if skill_obj:
                resource = LearningResource(
                    skill_id=skill_obj.id,
                    title=r_data["title"],
                    url=r_data["url"],
                    provider=r_data["provider"],
                    resource_type=r_data.get("resource_type", "Guide"),
                    difficulty=r_data.get("difficulty", "Beginner"),
                    estimated_hours=r_data.get("estimated_hours", 5.0),
                    rating=r_data.get("rating", 4.8)
                )
                db.add(resource)
        db.commit()

    # 5. Seed Assessments & Questions
    existing_assessments_count = db.query(Assessment).count()
    if existing_assessments_count == 0:
        for a_data in SEED_ASSESSMENTS:
            skill_obj = skill_map.get(a_data["skill"])
            if skill_obj:
                assessment = Assessment(
                    skill_id=skill_obj.id,
                    title=a_data["title"],
                    category=a_data["category"],
                    difficulty=a_data.get("difficulty", "Intermediate"),
                    pass_score=a_data.get("pass_score", 70.0)
                )
                db.add(assessment)
                db.flush()

                for q_data in a_data.get("questions", []):
                    question = AssessmentQuestion(
                        assessment_id=assessment.id,
                        question_text=q_data["question_text"],
                        options=q_data["options"],
                        correct_answer_index=q_data["correct_answer_index"],
                        explanation=q_data["explanation"],
                        concept_tag=q_data.get("concept_tag", "Core Concepts")
                    )
                    db.add(question)
        db.commit()

    # 6. Seed Demo User & Demo Profile (if not present)
    demo_user = db.query(User).filter(User.email == "demo@skillpath.ai").first()
    if not demo_user:
        demo_user = User(
            email="demo@skillpath.ai",
            hashed_password=get_password_hash("password123"),
            full_name="Alex Chen",
            is_active=True,
            is_demo=True
        )
        db.add(demo_user)
        db.flush()

        # Find Full Stack Developer career id
        fs_career = db.query(CareerRole).filter(CareerRole.title == "Full Stack Developer").first()

        profile = LearnerProfile(
            user_id=demo_user.id,
            education="B.S. in Computer Science",
            institution="State Technical Institute",
            academic_year="3rd Year",
            experience_level="Intermediate",
            target_career_id=fs_career.id if fs_career else None,
            preferred_learning_style="Hands-on",
            soft_skills=["Problem Solving", "Communication", "Critical Thinking"],
            certifications=[{"title": "Responsive Web Design", "issuer": "freeCodeCamp", "year": 2024}],
            projects=[{"title": "Portfolio Website", "description": "Responsive personal website using HTML/CSS & JS", "technologies": ["HTML", "CSS", "JavaScript"]}]
        )
        db.add(profile)

        # Initial skills for Alex Chen
        initial_skills = [
            ("HTML/CSS", "Intermediate", "Self-Declared", 0.45),
            ("JavaScript", "Intermediate", "Self-Declared", 0.40),
            ("Python", "Beginner", "Self-Declared", 0.35),
            ("Git & Version Control", "Intermediate", "Self-Declared", 0.50),
        ]
        for s_name, prof, evid, conf in initial_skills:
            if s_name in skill_map:
                ls = LearnerSkill(
                    user_id=demo_user.id,
                    skill_id=skill_map[s_name].id,
                    proficiency_level=prof,
                    evidence_source=evid,
                    confidence_level=conf
                )
                db.add(ls)

        db.commit()
