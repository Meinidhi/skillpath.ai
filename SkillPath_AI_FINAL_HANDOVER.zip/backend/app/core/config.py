import os
from pydantic import BaseModel

class Settings(BaseModel):
    PROJECT_NAME: str = "SkillPath AI"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api"
    SECRET_KEY: str = os.getenv("SECRET_KEY", "super-secret-skillpath-competition-key-2026")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days
    
    # SQLite local zero-config database
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./skillpath.db")
    
    # LLM settings (Clean interface for optional future providers)
    LLM_PROVIDER: str = os.getenv("LLM_PROVIDER", "deterministic")  # deterministic | openai | local
    LLM_API_KEY: str = os.getenv("LLM_API_KEY", "")

settings = Settings()
