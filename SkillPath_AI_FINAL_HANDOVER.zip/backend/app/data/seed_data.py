from typing import Dict, Any, List

SEED_SKILLS = [
    # Frontend
    {"name": "HTML/CSS", "category": "Frontend", "description": "Semantic markup, CSS Grid, Flexbox, responsive design, accessibility."},
    {"name": "JavaScript", "category": "Frontend", "description": "Core language fundamentals, closures, asynchronous programming, DOM, ES6+."},
    {"name": "TypeScript", "category": "Frontend", "description": "Static type system, interfaces, generics, type guards, TS compiler."},
    {"name": "React", "category": "Frontend", "description": "Component architecture, hooks, state management, virtual DOM, performance optimization."},
    {"name": "Next.js", "category": "Frontend", "description": "Server-side rendering, static site generation, API routes, App Router."},
    {"name": "UI/UX Design & Figma", "category": "Design", "description": "Design systems, wireframing, prototyping, user research, accessibility guidelines."},

    # Backend
    {"name": "Python", "category": "Backend", "description": "Python language, data structures, OOP, standard library, virtual environments."},
    {"name": "Node.js", "category": "Backend", "description": "Event-driven runtime, Express/Fastify, streams, asynchronous I/O, npm ecosystem."},
    {"name": "FastAPI", "category": "Backend", "description": "Modern high-performance web framework, Pydantic validation, dependency injection, async handlers."},
    {"name": "REST APIs", "category": "Backend", "description": "RESTful principles, HTTP methods, status codes, authentication, API documentation."},
    {"name": "SQL & Databases", "category": "Database", "description": "Relational data modeling, complex queries, joins, indexes, transactions, normalization."},
    {"name": "PostgreSQL", "category": "Database", "description": "Advanced relational database features, JSONB, indexing strategies, query planning."},

    # AI & Data
    {"name": "Machine Learning", "category": "AI/ML", "description": "Supervised & unsupervised learning, scikit-learn, regression, classification, clustering."},
    {"name": "Deep Learning & PyTorch", "category": "AI/ML", "description": "Neural networks, PyTorch tensors, backpropagation, CNNs, transformers."},
    {"name": "Pandas & Data Analysis", "category": "Data", "description": "Data wrangling, cleaning, exploratory analysis, NumPy, Pandas DataFrames."},
    {"name": "Data Visualization", "category": "Data", "description": "Visualizing distributions and trends using Matplotlib, Seaborn, Tableau, Power BI."},

    # DevOps, Cloud & Security
    {"name": "Git & Version Control", "category": "Core CS", "description": "Branching workflows, commits, merging, rebasing, pull requests, resolving conflicts."},
    {"name": "Docker & Containers", "category": "DevOps", "description": "Containerization, Dockerfiles, images, volumes, multi-stage builds, docker-compose."},
    {"name": "CI/CD Pipelines", "category": "DevOps", "description": "Automated testing, continuous integration, GitHub Actions, build automation."},
    {"name": "Linux & Shell Scripting", "category": "DevOps", "description": "Bash scripting, Unix permissions, process management, networking utilities."},
    {"name": "Cloud Computing (AWS)", "category": "Cloud", "description": "Core cloud concepts: compute (EC2), storage (S3), IAM, serverless, networking (VPC)."},
    {"name": "Kubernetes", "category": "DevOps", "description": "Container orchestration, pods, deployments, services, ingress, helm charts."},
    {"name": "Cybersecurity Fundamentals", "category": "Security", "description": "CIA triad, threat modeling, OWASP Top 10, cryptographic primitives, defensive security."},
    {"name": "Network Security", "category": "Security", "description": "TCP/IP model, firewalls, packet analysis, Wireshark, VPNs, zero-trust architecture."}
]

SEED_CAREERS = [
    {
        "title": "Full Stack Developer",
        "category": "Software Engineering",
        "description": "Architects, builds, and maintains both client-facing web applications and robust server-side systems and databases.",
        "average_salary": "$105,000 - $145,000",
        "growth_rate": "+24% (Much faster than average)",
        "requirements": [
            {"skill": "HTML/CSS", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": []},
            {"skill": "JavaScript", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": ["HTML/CSS"]},
            {"skill": "React", "required_proficiency": "Intermediate", "importance": "Critical", "prerequisites": ["JavaScript"]},
            {"skill": "Node.js", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": ["JavaScript"]},
            {"skill": "SQL & Databases", "required_proficiency": "Intermediate", "importance": "Critical", "prerequisites": []},
            {"skill": "REST APIs", "required_proficiency": "Intermediate", "importance": "Critical", "prerequisites": ["Node.js"]},
            {"skill": "Git & Version Control", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": []},
            {"skill": "Docker & Containers", "required_proficiency": "Beginner", "importance": "Medium", "prerequisites": ["Linux & Shell Scripting"]}
        ]
    },
    {
        "title": "Frontend Developer",
        "category": "Software Engineering",
        "description": "Specializes in building responsive, accessible, high-performance user interfaces and delightful digital experiences.",
        "average_salary": "$95,000 - $130,000",
        "growth_rate": "+21% (Faster than average)",
        "requirements": [
            {"skill": "HTML/CSS", "required_proficiency": "Expert", "importance": "Critical", "prerequisites": []},
            {"skill": "JavaScript", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": ["HTML/CSS"]},
            {"skill": "TypeScript", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": ["JavaScript"]},
            {"skill": "React", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": ["JavaScript"]},
            {"skill": "Next.js", "required_proficiency": "Intermediate", "importance": "Medium", "prerequisites": ["React"]},
            {"skill": "UI/UX Design & Figma", "required_proficiency": "Intermediate", "importance": "Medium", "prerequisites": []},
            {"skill": "Git & Version Control", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": []}
        ]
    },
    {
        "title": "Backend Developer",
        "category": "Software Engineering",
        "description": "Designs scalable server architectures, resilient APIs, database schemas, and data pipelines.",
        "average_salary": "$110,000 - $150,000",
        "growth_rate": "+22% (Faster than average)",
        "requirements": [
            {"skill": "Python", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": []},
            {"skill": "FastAPI", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": ["Python"]},
            {"skill": "SQL & Databases", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": []},
            {"skill": "PostgreSQL", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": ["SQL & Databases"]},
            {"skill": "REST APIs", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": ["FastAPI"]},
            {"skill": "Docker & Containers", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": ["Linux & Shell Scripting"]},
            {"skill": "Git & Version Control", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": []}
        ]
    },
    {
        "title": "AI Engineer",
        "category": "Artificial Intelligence",
        "description": "Builds and deploys machine learning and deep learning models into production systems, integrating AI into software products.",
        "average_salary": "$135,000 - $185,000",
        "growth_rate": "+38% (Extremely high demand)",
        "requirements": [
            {"skill": "Python", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": []},
            {"skill": "Machine Learning", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": ["Python", "Pandas & Data Analysis"]},
            {"skill": "Deep Learning & PyTorch", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": ["Machine Learning"]},
            {"skill": "Pandas & Data Analysis", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": ["Python"]},
            {"skill": "FastAPI", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": ["Python"]},
            {"skill": "Docker & Containers", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": []},
            {"skill": "Git & Version Control", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": []}
        ]
    },
    {
        "title": "Data Scientist",
        "category": "Data & Analytics",
        "description": "Leverages statistical modeling, machine learning, and data wrangling to uncover deep insights and drive strategic decisions.",
        "average_salary": "$120,000 - $160,000",
        "growth_rate": "+28% (Much faster than average)",
        "requirements": [
            {"skill": "Python", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": []},
            {"skill": "Pandas & Data Analysis", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": ["Python"]},
            {"skill": "Machine Learning", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": ["Pandas & Data Analysis"]},
            {"skill": "SQL & Databases", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": []},
            {"skill": "Data Visualization", "required_proficiency": "Advanced", "importance": "High", "prerequisites": ["Pandas & Data Analysis"]},
            {"skill": "Git & Version Control", "required_proficiency": "Intermediate", "importance": "Medium", "prerequisites": []}
        ]
    },
    {
        "title": "Data Analyst",
        "category": "Data & Analytics",
        "description": "Translates complex datasets into actionable business dashboards, KPI reporting, and strategic intelligence.",
        "average_salary": "$75,000 - $105,000",
        "growth_rate": "+18% (Faster than average)",
        "requirements": [
            {"skill": "SQL & Databases", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": []},
            {"skill": "Pandas & Data Analysis", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": ["Python"]},
            {"skill": "Data Visualization", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": []},
            {"skill": "Python", "required_proficiency": "Intermediate", "importance": "Medium", "prerequisites": []}
        ]
    },
    {
        "title": "Cybersecurity Analyst",
        "category": "Security",
        "description": "Monitors, detects, and defends networks and systems from unauthorized access, cyber threats, and security vulnerabilities.",
        "average_salary": "$100,000 - $140,000",
        "growth_rate": "+32% (Much faster than average)",
        "requirements": [
            {"skill": "Cybersecurity Fundamentals", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": []},
            {"skill": "Network Security", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": ["Cybersecurity Fundamentals"]},
            {"skill": "Linux & Shell Scripting", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": []},
            {"skill": "Python", "required_proficiency": "Intermediate", "importance": "Medium", "prerequisites": []},
            {"skill": "Cloud Computing (AWS)", "required_proficiency": "Intermediate", "importance": "Medium", "prerequisites": []}
        ]
    },
    {
        "title": "Cloud Engineer",
        "category": "Cloud & Infrastructure",
        "description": "Deploys, monitors, and optimizes cloud computing infrastructure, security policies, and high-availability systems.",
        "average_salary": "$115,000 - $155,000",
        "growth_rate": "+25% (Much faster than average)",
        "requirements": [
            {"skill": "Cloud Computing (AWS)", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": []},
            {"skill": "Linux & Shell Scripting", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": []},
            {"skill": "Docker & Containers", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": ["Linux & Shell Scripting"]},
            {"skill": "Kubernetes", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": ["Docker & Containers"]},
            {"skill": "CI/CD Pipelines", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": []},
            {"skill": "Git & Version Control", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": []}
        ]
    },
    {
        "title": "DevOps Engineer",
        "category": "DevOps",
        "description": "Bridges software development and IT operations through continuous integration, deployment pipelines, infrastructure as code, and automation.",
        "average_salary": "$120,000 - $160,000",
        "growth_rate": "+26% (Much faster than average)",
        "requirements": [
            {"skill": "Docker & Containers", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": ["Linux & Shell Scripting"]},
            {"skill": "Kubernetes", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": ["Docker & Containers"]},
            {"skill": "CI/CD Pipelines", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": ["Git & Version Control"]},
            {"skill": "Linux & Shell Scripting", "required_proficiency": "Advanced", "importance": "Critical", "prerequisites": []},
            {"skill": "Cloud Computing (AWS)", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": []},
            {"skill": "Git & Version Control", "required_proficiency": "Advanced", "importance": "High", "prerequisites": []},
            {"skill": "Python", "required_proficiency": "Intermediate", "importance": "Medium", "prerequisites": []}
        ]
    },
    {
        "title": "UI/UX Designer",
        "category": "Design",
        "description": "Crafts intuitive user journeys, interactive wireframes, design systems, and conducts user research to solve complex customer pain points.",
        "average_salary": "$85,000 - $125,000",
        "growth_rate": "+16% (Faster than average)",
        "requirements": [
            {"skill": "UI/UX Design & Figma", "required_proficiency": "Expert", "importance": "Critical", "prerequisites": []},
            {"skill": "HTML/CSS", "required_proficiency": "Intermediate", "importance": "High", "prerequisites": []},
            {"skill": "JavaScript", "required_proficiency": "Beginner", "importance": "Nice-to-have", "prerequisites": ["HTML/CSS"]}
        ]
    }
]

SEED_RESOURCES = [
    # JavaScript
    {
        "skill": "JavaScript",
        "title": "MDN JavaScript Guide & Reference",
        "url": "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide",
        "provider": "MDN Web Docs",
        "resource_type": "Documentation",
        "difficulty": "Beginner",
        "estimated_hours": 12.0,
        "rating": 4.9
    },
    {
        "skill": "JavaScript",
        "title": "freeCodeCamp JavaScript Algorithms & Data Structures",
        "url": "https://www.freecodecamp.org/learn/javascript-algorithms-and-data-structures-v8/",
        "provider": "freeCodeCamp",
        "resource_type": "Interactive",
        "difficulty": "Intermediate",
        "estimated_hours": 30.0,
        "rating": 4.8
    },
    {
        "skill": "JavaScript",
        "title": "JavaScript.info: The Modern JavaScript Tutorial",
        "url": "https://javascript.info/",
        "provider": "JavaScript.info",
        "resource_type": "Interactive",
        "difficulty": "Intermediate",
        "estimated_hours": 20.0,
        "rating": 4.9
    },

    # React
    {
        "skill": "React",
        "title": "React Official Documentation & Interactive Quick Start",
        "url": "https://react.dev/learn",
        "provider": "React Documentation",
        "resource_type": "Interactive",
        "difficulty": "Beginner",
        "estimated_hours": 15.0,
        "rating": 4.9
    },
    {
        "skill": "React",
        "title": "freeCodeCamp React Course for Beginners",
        "url": "https://www.freecodecamp.org/news/free-react-course-2024/",
        "provider": "freeCodeCamp",
        "resource_type": "Guide",
        "difficulty": "Intermediate",
        "estimated_hours": 18.0,
        "rating": 4.7
    },

    # Python
    {
        "skill": "Python",
        "title": "Official Python 3 Tutorial & Documentation",
        "url": "https://docs.python.org/3/tutorial/",
        "provider": "Python Documentation",
        "resource_type": "Documentation",
        "difficulty": "Beginner",
        "estimated_hours": 10.0,
        "rating": 4.8
    },
    {
        "skill": "Python",
        "title": "freeCodeCamp Scientific Computing with Python",
        "url": "https://www.freecodecamp.org/learn/scientific-computing-with-python/",
        "provider": "freeCodeCamp",
        "resource_type": "Interactive",
        "difficulty": "Intermediate",
        "estimated_hours": 25.0,
        "rating": 4.8
    },

    # HTML/CSS
    {
        "skill": "HTML/CSS",
        "title": "MDN Learn Web Development: HTML & CSS",
        "url": "https://developer.mozilla.org/en-US/docs/Learn/HTML",
        "provider": "MDN Web Docs",
        "resource_type": "Interactive",
        "difficulty": "Beginner",
        "estimated_hours": 15.0,
        "rating": 4.9
    },
    {
        "skill": "HTML/CSS",
        "title": "W3Schools CSS Flexbox and Grid Tutorial",
        "url": "https://www.w3schools.com/css/css3_flexbox.asp",
        "provider": "W3Schools",
        "resource_type": "Guide",
        "difficulty": "Beginner",
        "estimated_hours": 6.0,
        "rating": 4.6
    },

    # SQL & Databases
    {
        "skill": "SQL & Databases",
        "title": "SQLBolt: Interactive Learn SQL with Simple Exercises",
        "url": "https://sqlbolt.com/",
        "provider": "SQLBolt",
        "resource_type": "Interactive",
        "difficulty": "Beginner",
        "estimated_hours": 8.0,
        "rating": 4.9
    },
    {
        "skill": "SQL & Databases",
        "title": "W3Schools SQL Tutorial & Interactive Editor",
        "url": "https://www.w3schools.com/sql/",
        "provider": "W3Schools",
        "resource_type": "Interactive",
        "difficulty": "Beginner",
        "estimated_hours": 10.0,
        "rating": 4.7
    },

    # Machine Learning & AI
    {
        "skill": "Machine Learning",
        "title": "Scikit-Learn Official User Guide & Tutorials",
        "url": "https://scikit-learn.org/stable/user_guide.html",
        "provider": "Scikit-Learn Docs",
        "resource_type": "Documentation",
        "difficulty": "Intermediate",
        "estimated_hours": 20.0,
        "rating": 4.9
    },
    {
        "skill": "Deep Learning & PyTorch",
        "title": "PyTorch 60-Minute Blitz & Deep Learning Fundamentals",
        "url": "https://pytorch.org/tutorials/beginner/deep_learning_60min_blitz.html",
        "provider": "PyTorch Documentation",
        "resource_type": "Interactive",
        "difficulty": "Advanced",
        "estimated_hours": 16.0,
        "rating": 4.9
    },

    # Docker & DevOps
    {
        "skill": "Docker & Containers",
        "title": "Docker Official Getting Started Guide",
        "url": "https://docs.docker.com/get-started/",
        "provider": "Docker Docs",
        "resource_type": "Guide",
        "difficulty": "Beginner",
        "estimated_hours": 8.0,
        "rating": 4.8
    },
    {
        "skill": "Git & Version Control",
        "title": "Pro Git Book (Free by Scott Chacon and Ben Straub)",
        "url": "https://git-scm.com/book/en/v2",
        "provider": "Git Official",
        "resource_type": "Documentation",
        "difficulty": "Beginner",
        "estimated_hours": 10.0,
        "rating": 4.9
    },
    {
        "skill": "FastAPI",
        "title": "FastAPI Tutorial - User Guide",
        "url": "https://fastapi.tiangolo.com/tutorial/",
        "provider": "FastAPI Documentation",
        "resource_type": "Documentation",
        "difficulty": "Beginner",
        "estimated_hours": 10.0,
        "rating": 4.9
    },
    {
        "skill": "Pandas & Data Analysis",
        "title": "10 Minutes to Pandas Official Guide",
        "url": "https://pandas.pydata.org/docs/user_guide/10min.html",
        "provider": "Pandas Documentation",
        "resource_type": "Guide",
        "difficulty": "Beginner",
        "estimated_hours": 6.0,
        "rating": 4.8
    }
]

SEED_ASSESSMENTS = [
    {
        "skill": "JavaScript",
        "title": "Core JavaScript Competency Assessment",
        "category": "Frontend",
        "difficulty": "Intermediate",
        "pass_score": 70.0,
        "questions": [
            {
                "question_text": "What is the primary characteristic of a Closure in JavaScript?",
                "options": [
                    "A function bundled with references to its surrounding lexical environment",
                    "A method used to immediately terminate an asynchronous loop",
                    "A technique for converting objects into primitive JSON strings",
                    "A strict mode restriction preventing global variable creation"
                ],
                "correct_answer_index": 0,
                "explanation": "A closure is the combination of a function bundled together (enclosed) with references to its surrounding state (the lexical environment), allowing an inner function to access an outer function's scope.",
                "concept_tag": "Closures & Scope"
            },
            {
                "question_text": "In JavaScript's Event Loop, which queue takes priority when executing pending callbacks?",
                "options": [
                    "Macrotask queue (e.g., setTimeout, setInterval)",
                    "Microtask queue (e.g., Promise.then, queueMicrotask)",
                    "Rendering frame queue",
                    "Network I/O callback pool"
                ],
                "correct_answer_index": 1,
                "explanation": "The microtask queue (which handles resolved Promises and mutation observers) is always completely drained after the current synchronous script runs and before any new macrotask (such as setTimeout) is executed.",
                "concept_tag": "Event Loop & Concurrency"
            },
            {
                "question_text": "What will `console.log(typeof NaN)` output in modern JavaScript?",
                "options": [
                    "'undefined'",
                    "'nan'",
                    "'number'",
                    "'object'"
                ],
                "correct_answer_index": 2,
                "explanation": "In JavaScript, NaN stands for 'Not-a-Number', but its formal ECMA primitive type is defined as 'number'.",
                "concept_tag": "Type Coercion & Primitives"
            },
            {
                "question_text": "When using `async/await`, how do unhandled rejected promises propagate?",
                "options": [
                    "They are automatically swallowed with a warning in production",
                    "They throw an exception that can be caught with a standard `try...catch` block",
                    "They cause the browser window to instantly crash",
                    "They convert the return value to null automatically"
                ],
                "correct_answer_index": 1,
                "explanation": "When an awaited promise rejects, the `await` expression throws the rejected value, allowing developers to handle asynchronous errors using standard `try...catch` syntax.",
                "concept_tag": "Async/Await & Error Handling"
            },
            {
                "question_text": "What is the key difference between `==` (loose equality) and `===` (strict equality)?",
                "options": [
                    "`==` compares memory addresses, while `===` compares values",
                    "`==` performs type coercion before comparison, while `===` checks both value and type without coercion",
                    "`===` only works for numbers and strings, not objects",
                    "There is no difference in ES6+"
                ],
                "correct_answer_index": 1,
                "explanation": "`==` performs implicit type conversion if operands are of different types, whereas `===` strictly checks that both operands share identical types and values.",
                "concept_tag": "Equality & Comparisons"
            }
        ]
    },
    {
        "skill": "Python",
        "title": "Python Core & Backend Proficiency Assessment",
        "category": "Backend",
        "difficulty": "Intermediate",
        "pass_score": 70.0,
        "questions": [
            {
                "question_text": "What does Python's Global Interpreter Lock (GIL) primarily restrict?",
                "options": [
                    "Prevents multiple operating system threads from executing Python bytecodes simultaneously in CPython",
                    "Restricts access to private class variables and methods",
                    "Blocks untrusted network sockets from opening ports below 1024",
                    "Prohibits recursion depths exceeding 1000 frames"
                ],
                "correct_answer_index": 0,
                "explanation": "The GIL is a mutex that protects access to Python objects, preventing multiple native threads from executing Python bytecodes at once in standard CPython.",
                "concept_tag": "Python GIL & Concurrency"
            },
            {
                "question_text": "How do Python generator functions differ from regular functions?",
                "options": [
                    "Generators run on a separate CPU core automatically",
                    "Generators use the `yield` statement and produce a lazy sequence of values one at a time on demand",
                    "Generators cannot take arguments",
                    "Generators always return a list"
                ],
                "correct_answer_index": 1,
                "explanation": "Generators yield values iteratively rather than returning all results at once, conserving memory and enabling lazy evaluation over massive or infinite datasets.",
                "concept_tag": "Generators & Iteration"
            },
            {
                "question_text": "Which data structure in Python provides O(1) average time complexity for lookups?",
                "options": [
                    "List",
                    "Tuple",
                    "Dictionary (dict) / Set",
                    "Linked List"
                ],
                "correct_answer_index": 2,
                "explanation": "Python dictionaries and sets are implemented using hash tables, offering amortized O(1) lookup, insertion, and deletion complexity.",
                "concept_tag": "Data Structures & Complexity"
            },
            {
                "question_text": "What is the purpose of Python's `@property` decorator?",
                "options": [
                    "To declare a database table column in SQLAlchemy",
                    "To define a method that can be accessed like an attribute, allowing getter, setter, and validation logic",
                    "To make an object immutable across the application",
                    "To compile the function into native C code"
                ],
                "correct_answer_index": 1,
                "explanation": "The `@property` decorator allows a method to be accessed as an attribute, enabling encapsulation, computed properties, and validation hooks without changing client access syntax.",
                "concept_tag": "OOP & Decorators"
            },
            {
                "question_text": "In Python list comprehensions, what is the best practice for readable data transformations?",
                "options": [
                    "Nest at least 4 loops inside a single list comprehension",
                    "Use them for clear mapping and filtering, refactoring complex multi-level logic into helper functions",
                    "Always prefer `map()` and `filter()` with lambda over list comprehensions",
                    "Never use conditions in list comprehensions"
                ],
                "correct_answer_index": 1,
                "explanation": "Pythonic style favors list comprehensions for concise mapping and filtering, but encourages standard loops or functions when nesting becomes too dense to read easily.",
                "concept_tag": "Functional Python & Idioms"
            }
        ]
    },
    {
        "skill": "React",
        "title": "React Architecture & Component Design Assessment",
        "category": "Frontend",
        "difficulty": "Intermediate",
        "pass_score": 70.0,
        "questions": [
            {
                "question_text": "Why must dependencies be specified accurately in the `useEffect` dependency array?",
                "options": [
                    "Omitting dependencies can cause stale closures capturing outdated state or props",
                    "React will crash if the array contains more than two items",
                    "The dependency array determines the CSS styling of the component",
                    "Dependencies convert functional components into class components"
                ],
                "correct_answer_index": 0,
                "explanation": "React's linter requires all reactive values used inside `useEffect` to be in the dependency array; missing dependencies lead to stale closures where the effect refers to old state.",
                "concept_tag": "React Hooks & Lifecycle"
            },
            {
                "question_text": "What is the benefit of the Virtual DOM in React?",
                "options": [
                    "It replaces HTML with binary bytecode",
                    "It enables React to diff changes in memory and batch minimal real DOM mutations",
                    "It runs all UI logic on the web server",
                    "It guarantees 120 FPS animation without GPU"
                ],
                "correct_answer_index": 1,
                "explanation": "The Virtual DOM is a lightweight JavaScript representation of the actual DOM. React compares Virtual DOM trees (reconciliation) and updates only the necessary nodes in the real browser DOM.",
                "concept_tag": "Virtual DOM & Reconciliation"
            },
            {
                "question_text": "When should you use `useCallback` or `useMemo` in React?",
                "options": [
                    "Wrap every single function and variable in every component unconditionally",
                    "When passing callbacks to optimized child components or when computing expensive memoized calculations",
                    "Only when using TypeScript",
                    "To replace `useState` entirely"
                ],
                "correct_answer_index": 1,
                "explanation": "`useMemo` and `useCallback` have overhead and should be reserved for expensive calculations or preserving referential identity when passing props to memoized components (`React.memo`).",
                "concept_tag": "Performance Optimization"
            },
            {
                "question_text": "What is prop drilling and how is it solved in modern React?",
                "options": [
                    "Passing props down multiple nested component layers, resolved using Context API or state management",
                    "A compiler bug where props are dropped during minification",
                    "Mutating child state directly from a parent component",
                    "A styling technique for responsive grid columns"
                ],
                "correct_answer_index": 0,
                "explanation": "Prop drilling occurs when data must pass through intermediary components that don't need it. React Context, Zustand, or Redux allow deeply nested children to consume state directly.",
                "concept_tag": "State Management & Architecture"
            }
        ]
    },
    {
        "skill": "SQL & Databases",
        "title": "Relational Databases & SQL Querying Assessment",
        "category": "Database",
        "difficulty": "Intermediate",
        "pass_score": 70.0,
        "questions": [
            {
                "question_text": "What is the primary difference between a `WHERE` clause and a `HAVING` clause?",
                "options": [
                    "`WHERE` filters rows before grouping/aggregation; `HAVING` filters aggregated groups after `GROUP BY`",
                    "`HAVING` only works on strings, while `WHERE` works on numbers",
                    "`WHERE` requires an index, while `HAVING` creates an index",
                    "They are exact synonyms in SQL:2023"
                ],
                "correct_answer_index": 0,
                "explanation": "`WHERE` filters individual records before any grouping occurs. `HAVING` filters the results of aggregate functions (like COUNT, SUM, AVG) after `GROUP BY` has grouped the rows.",
                "concept_tag": "Aggregations & Filtering"
            },
            {
                "question_text": "In relational databases, what does the ACID acronym guarantee for transactions?",
                "options": [
                    "Atomicity, Consistency, Isolation, Durability",
                    "Asynchronous, Concurrent, Indexed, Distributed",
                    "Automated, Clustered, Integrated, Decoupled",
                    "Array, Cursor, Iteration, Deletion"
                ],
                "correct_answer_index": 0,
                "explanation": "ACID guarantees that database transactions are processed reliably: all or nothing (Atomicity), maintaining valid states (Consistency), safe from concurrent conflicts (Isolation), and surviving crashes (Durability).",
                "concept_tag": "Transactions & ACID"
            },
            {
                "question_text": "Which JOIN returns all rows from the left table and matched rows from the right table?",
                "options": [
                    "INNER JOIN",
                    "LEFT (OUTER) JOIN",
                    "RIGHT JOIN",
                    "CROSS JOIN"
                ],
                "correct_answer_index": 1,
                "explanation": "A LEFT JOIN returns all records from the left table, and the matching records from the right table (with NULL for non-matching right table columns).",
                "concept_tag": "SQL Joins & Relational Algebra"
            }
        ]
    }
]
