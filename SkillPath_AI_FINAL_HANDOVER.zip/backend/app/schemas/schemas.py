from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime

# ================= AUTH SCHEMAS =================
class UserCreate(BaseModel):
    email: str
    password: str = Field(..., min_length=6)
    full_name: str
    education: Optional[str] = "Undergraduate"
    institution: Optional[str] = "University / College"
    academic_year: Optional[str] = "3rd Year"
    experience_level: Optional[str] = "Beginner"
    target_career_id: Optional[int] = None
    preferred_learning_style: Optional[str] = "Hands-on"

class UserLogin(BaseModel):
    email: str
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str
    user: Dict[str, Any]

class UserResponse(BaseModel):
    id: int
    email: str
    full_name: str
    is_active: bool
    is_demo: bool
    created_at: datetime

    class Config:
        from_attributes = True

# ================= PROFILE SCHEMAS =================
class LearnerProfileUpdate(BaseModel):
    education: Optional[str] = None
    institution: Optional[str] = None
    academic_year: Optional[str] = None
    experience_level: Optional[str] = None
    target_career_id: Optional[int] = None
    preferred_learning_style: Optional[str] = None
    soft_skills: Optional[List[str]] = None
    certifications: Optional[List[Dict[str, Any]]] = None
    projects: Optional[List[Dict[str, Any]]] = None

class LearnerProfileResponse(BaseModel):
    id: int
    user_id: int
    education: str
    institution: str
    academic_year: str
    experience_level: str
    target_career_id: Optional[int]
    target_career_title: Optional[str] = None
    preferred_learning_style: str
    soft_skills: List[str]
    certifications: List[Dict[str, Any]]
    projects: List[Dict[str, Any]]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

# ================= SKILL SCHEMAS =================
class SkillBase(BaseModel):
    id: int
    name: str
    category: str
    description: Optional[str]

    class Config:
        from_attributes = True

class LearnerSkillUpdate(BaseModel):
    skill_name: str
    proficiency_level: str  # Beginner, Intermediate, Advanced, Expert
    evidence_source: Optional[str] = "Self-Declared"

class LearnerSkillBatchUpdate(BaseModel):
    skills: List[LearnerSkillUpdate]

class LearnerSkillResponse(BaseModel):
    id: int
    skill_id: int
    skill_name: str
    category: str
    proficiency_level: str
    evidence_source: str
    confidence_level: float
    last_assessed_date: datetime

    class Config:
        from_attributes = True

class SkillAnalysisResult(BaseModel):
    overall_proficiency: str
    strengths: List[Dict[str, Any]]
    weaknesses: List[Dict[str, Any]]
    skill_distribution: Dict[str, int]
    category_coverage: Dict[str, float]
    total_skills_recorded: int
    average_confidence: float

# ================= CAREER SCHEMAS =================
class CareerRequirementResponse(BaseModel):
    id: int
    skill_id: int
    skill_name: str
    required_proficiency: str
    importance: str
    prerequisite_skills: List[str]

    class Config:
        from_attributes = True

class CareerRoleResponse(BaseModel):
    id: int
    title: str
    description: str
    category: str
    average_salary: str
    growth_rate: str
    requirements: List[CareerRequirementResponse] = []

    class Config:
        from_attributes = True

class CareerMatchSkillDetail(BaseModel):
    skill_name: str
    status: str  # "meets", "underdeveloped", "missing"
    required_proficiency: str
    current_proficiency: Optional[str] = None
    importance: str
    confidence: float = 0.0

class CareerMatchResult(BaseModel):
    career_id: int
    career_title: str
    career_readiness_score: float  # 0 to 100
    formula_breakdown: str
    meeting_skills: List[CareerMatchSkillDetail]
    underdeveloped_skills: List[CareerMatchSkillDetail]
    missing_skills: List[CareerMatchSkillDetail]
    total_required: int
    critical_missing: List[str]

class CareerGoalChangeRequest(BaseModel):
    new_career_id: int

# ================= ROADMAP SCHEMAS =================
class RoadmapItemResponse(BaseModel):
    id: int
    skill_id: int
    skill_name: str
    title: str
    learning_objective: str
    priority: str
    difficulty: str
    estimated_duration_days: int
    status: str
    resource_url: Optional[str]
    practical_exercise: Optional[str]
    order_index: int
    completed_at: Optional[datetime]

    class Config:
        from_attributes = True

class RoadmapItemStatusUpdate(BaseModel):
    status: str  # pending, in_progress, completed, needs_revision

class RoadmapVersionResponse(BaseModel):
    id: int
    version_number: int
    change_trigger: str
    change_reason: Optional[str]
    summary: Optional[str]
    created_at: datetime
    items: List[RoadmapItemResponse] = []

    class Config:
        from_attributes = True

class LearningRoadmapResponse(BaseModel):
    id: int
    career_id: int
    career_title: str
    current_version: int
    is_active: bool
    current_items: List[RoadmapItemResponse] = []
    versions: List[RoadmapVersionResponse] = []

# ================= RESOURCE SCHEMAS =================
class LearningResourceResponse(BaseModel):
    id: int
    skill_id: int
    skill_name: str
    title: str
    url: str
    provider: str
    resource_type: str
    difficulty: str
    estimated_hours: float
    rating: float

    class Config:
        from_attributes = True

# ================= ASSESSMENT SCHEMAS =================
class AssessmentQuestionPublic(BaseModel):
    id: int
    question_text: str
    options: List[str]
    concept_tag: str

class AssessmentDetailResponse(BaseModel):
    id: int
    skill_id: int
    skill_name: str
    title: str
    category: str
    difficulty: str
    pass_score: float
    questions: List[AssessmentQuestionPublic]

class AssessmentSubmitRequest(BaseModel):
    assessment_id: int
    answers: Dict[int, int]  # question_id -> selected_option_index

class AssessmentAttemptResponse(BaseModel):
    id: int
    assessment_id: int
    skill_name: str
    score: float
    total_questions: int
    correct_count: int
    passed: bool
    weak_concepts: List[str]
    explanations: List[Dict[str, Any]]
    attempted_at: datetime
    adaptation_triggered: bool = False
    adaptation_summary: Optional[str] = None

# ================= MENTOR SCHEMAS =================
class MentorMessageRequest(BaseModel):
    message: str

class MentorMessageResponse(BaseModel):
    id: int
    message: str
    sender: str
    context_metadata: Dict[str, Any]
    timestamp: datetime

# ================= AGENT SCHEMAS =================
class AgentExecutionResponse(BaseModel):
    id: int
    workflow_id: str
    agent_name: str
    responsibility: str
    status: str
    input_summary: Optional[str]
    output_summary: Optional[str]
    execution_time_ms: int
    timestamp: datetime

    class Config:
        from_attributes = True

class WorkflowResultResponse(BaseModel):
    workflow_id: str
    trigger: str
    status: str
    agents_executed: List[str]
    summary: str
    executions: List[AgentExecutionResponse]
    details: Dict[str, Any] = {}

# ================= PROGRESS SCHEMAS =================
class ProgressOverviewResponse(BaseModel):
    career_readiness_score: float
    target_career: str
    overall_progress_pct: float
    skills_mastered_count: int
    skills_in_progress_count: int
    total_skills_count: int
    assessments_completed_count: int
    average_assessment_score: float
    roadmap_completion_pct: float
    active_tasks_count: int
    recent_activities: List[Dict[str, Any]]
    upcoming_tasks: List[RoadmapItemResponse]
    skill_radar_data: List[Dict[str, Any]]
    history_trend: List[Dict[str, Any]]
