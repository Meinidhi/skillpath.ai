import time
from backend.agents.context import LearnerContext

class ProgressAgent:
    name: str = "Progress Agent"
    responsibility: str = "Evaluates assessment outcomes, detects weak concepts, tracks milestone attainment, and determines whether adaptive reassessment is required."

    def run(self, context: LearnerContext) -> dict:
        start_time = time.time()

        attempt = context.recent_attempt or {}
        skill_name = attempt.get("skill_name", "Skill")
        score = attempt.get("score", 0.0)
        passed = attempt.get("passed", False)
        weak_concepts = attempt.get("weak_concepts", [])

        # Detect poor performance
        is_poor = score < 65.0 or not passed

        if is_poor:
            context.reassessment_needed = True
            weak_tags = weak_concepts if weak_concepts else ["Core Concepts", "Foundational Mechanics"]
            remedial_title = f"Remedial Concept Reinforcement: {skill_name} ({', '.join(weak_tags[:2])})"
            
            context.remedial_task = {
                "skill_name": skill_name,
                "title": remedial_title,
                "learning_objective": f"Address diagnostic deficits in {skill_name}: {', '.join(weak_tags)}.",
                "practical_exercise": f"Complete 5 targeted debugging exercises specifically focusing on {', '.join(weak_tags)}.",
                "priority": "Critical",
                "difficulty": "Beginner",
                "estimated_duration_days": 4,
                "status": "needs_revision",
                "resource_url": "https://developer.mozilla.org" if "JavaScript" in skill_name else "https://docs.python.org"
            }

            summary = (
                f"Assessment Diagnostic for {skill_name}: Deficit Detected (Score: {int(score)}%). "
                f"Weak concepts: {', '.join(weak_tags)}. "
                f"Flagged reassessment required. Remedial intervention queued."
            )
        else:
            context.reassessment_needed = False
            context.remedial_task = None
            summary = (
                f"Assessment Diagnostic for {skill_name}: Proficiency Verified (Score: {int(score)}%). "
                f"No remedial reassessment needed."
            )

        elapsed_ms = int((time.time() - start_time) * 1000)

        return {
            "agent_name": self.name,
            "responsibility": self.responsibility,
            "status": "success",
            "execution_time_ms": elapsed_ms,
            "input_summary": f"Evaluated assessment score ({int(score)}%) on {skill_name}",
            "output_summary": summary,
            "score": score,
            "passed": passed,
            "reassessment_needed": context.reassessment_needed,
            "weak_concepts": weak_concepts,
            "remedial_task": context.remedial_task
        }
