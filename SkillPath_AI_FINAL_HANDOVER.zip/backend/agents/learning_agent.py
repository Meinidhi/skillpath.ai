import time
from backend.agents.context import LearnerContext
from backend.agents.rule_based_provider import RuleBasedProvider

class LearningAgent:
    name: str = "Learning Agent"
    responsibility: str = "Generates personalized roadmaps, arranges learning prerequisites, recommends curated resources, and sequences exercises."

    def run(self, context: LearnerContext) -> dict:
        start_time = time.time()

        roadmap_items = RuleBasedProvider.generate_roadmap_items(
            context.missing_skills,
            context.underdeveloped_skills,
            context.preferred_learning_style,
            remedial_task=context.remedial_task if context.reassessment_needed else None
        )

        context.new_roadmap_items = roadmap_items

        elapsed_ms = int((time.time() - start_time) * 1000)
        summary = (
            f"Synthesized personalized curriculum with {len(roadmap_items)} sequential modules. "
            f"Tailored for '{context.preferred_learning_style}' style. "
            f"Remedial tasks injected: {'Yes' if context.reassessment_needed else 'No'}."
        )

        return {
            "agent_name": self.name,
            "responsibility": self.responsibility,
            "status": "success",
            "execution_time_ms": elapsed_ms,
            "input_summary": f"Sequencing {len(context.missing_skills)} missing and {len(context.underdeveloped_skills)} underdeveloped competencies",
            "output_summary": summary,
            "total_items": len(roadmap_items),
            "roadmap_items": roadmap_items
        }
