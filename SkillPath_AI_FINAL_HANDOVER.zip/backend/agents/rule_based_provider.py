from typing import Dict, Any, List, Optional
from app.data.seed_data import SEED_RESOURCES
from app.agents.learning_agent import SKILL_PRACTICAL_EXERCISES

PROFICIENCY_RANK = {
    "Beginner": 1,
    "Intermediate": 2,
    "Advanced": 3,
    "Expert": 4
}

RANK_TO_PROFICIENCY = {
    1: "Beginner",
    2: "Intermediate",
    3: "Advanced",
    4: "Expert"
}

class RuleBasedProvider:
    """
    Deterministic Intelligence Engine for SkillPath AI.
    Executes rule-based and evidence-based logic for skill calibration,
    career matching, roadmap synthesis, and contextual mentoring.
    No external LLM API or paid dependencies required.
    """

    @staticmethod
    def calculate_career_match(requirements: List[Dict[str, Any]], analyzed_skills: List[Dict[str, Any]]) -> Dict[str, Any]:
        user_skills_map = {
            s["skill_name"].lower().strip(): s for s in analyzed_skills
        }

        meeting = []
        underdeveloped = []
        missing = []
        critical_missing = []

        total_weight = 0.0
        earned_weight = 0.0

        importance_multipliers = {
            "Critical": 1.5,
            "High": 1.2,
            "Medium": 1.0,
            "Nice-to-have": 0.8
        }

        for req in requirements:
            skill_name = req.get("skill_name", "")
            req_prof = req.get("required_proficiency", "Intermediate")
            importance = req.get("importance", "High")
            multiplier = importance_multipliers.get(importance, 1.0)
            total_weight += (1.0 * multiplier)

            key = skill_name.lower().strip()
            user_skill = user_skills_map.get(key)
            req_rank = PROFICIENCY_RANK.get(req_prof, 2)

            if user_skill:
                user_prof = user_skill.get("proficiency_level", "Beginner")
                user_rank = PROFICIENCY_RANK.get(user_prof, 1)
                confidence = user_skill.get("confidence_level", 0.35)

                if user_rank >= req_rank:
                    meeting.append({
                        "skill_name": skill_name,
                        "status": "meets",
                        "required_proficiency": req_prof,
                        "current_proficiency": user_prof,
                        "importance": importance,
                        "confidence": confidence
                    })
                    earned_weight += (1.0 * multiplier)
                else:
                    underdeveloped.append({
                        "skill_name": skill_name,
                        "status": "underdeveloped",
                        "required_proficiency": req_prof,
                        "current_proficiency": user_prof,
                        "importance": importance,
                        "confidence": confidence
                    })
                    earned_weight += ((user_rank / max(1, req_rank)) * multiplier)
            else:
                missing.append({
                    "skill_name": skill_name,
                    "status": "missing",
                    "required_proficiency": req_prof,
                    "current_proficiency": None,
                    "importance": importance,
                    "confidence": 0.0
                })
                if importance == "Critical":
                    critical_missing.append(skill_name)

        readiness_score = round(min(100.0, (earned_weight / max(1.0, total_weight)) * 100.0), 1)
        formula_breakdown = (
            f"Readiness Score: {readiness_score}%. "
            f"Earned Weight ({round(earned_weight, 2)}) / Required Weight ({round(total_weight, 2)}). "
            f"Meeting: {len(meeting)}, Underdeveloped: {len(underdeveloped)}, Missing: {len(missing)}."
        )

        return {
            "career_readiness_score": readiness_score,
            "formula_breakdown": formula_breakdown,
            "meeting_skills": meeting,
            "underdeveloped_skills": underdeveloped,
            "missing_skills": missing,
            "critical_missing": critical_missing,
            "total_required": len(requirements)
        }

    @staticmethod
    def calibrate_skills_with_evidence(learner_skills: List[Dict[str, Any]], attempts: List[Dict[str, Any]]) -> Dict[str, Any]:
        attempts_by_skill: Dict[str, List[Dict[str, Any]]] = {}
        for a in attempts:
            s_name = a.get("skill_name")
            if s_name:
                attempts_by_skill.setdefault(s_name, []).append(a)

        analyzed = []
        strengths = []
        weaknesses = []
        distribution = {"Beginner": 0, "Intermediate": 0, "Advanced": 0, "Expert": 0}

        for ls in learner_skills:
            name = ls.get("skill_name")
            cat = ls.get("category", "General")
            prof = ls.get("proficiency_level", "Beginner")
            conf = float(ls.get("confidence_level", 0.35))
            source = ls.get("evidence_source", "Self-Declared")

            recent = attempts_by_skill.get(name, [])
            if recent:
                latest = recent[-1]
                score = latest.get("score", 0.0)
                passed = latest.get("passed", False)
                if passed:
                    conf = min(0.95, round(0.70 + (score / 100.0) * 0.25, 2))
                    source = f"Assessment Verified ({int(score)}%)"
                    if score >= 85 and PROFICIENCY_RANK.get(prof, 1) < 3:
                        prof = "Advanced"
                    elif score >= 70 and PROFICIENCY_RANK.get(prof, 1) < 2:
                        prof = "Intermediate"
                else:
                    conf = min(0.60, round(0.30 + (score / 100.0) * 0.20, 2))
                    source = f"Assessment Deficit ({int(score)}%)"
                    if score < 60:
                        prof = "Beginner"

            distribution[prof] = distribution.get(prof, 0) + 1
            item = {
                "skill_name": name,
                "category": cat,
                "proficiency_level": prof,
                "confidence_level": conf,
                "evidence_source": source,
                "numeric_rank": PROFICIENCY_RANK.get(prof, 1)
            }
            analyzed.append(item)

            if PROFICIENCY_RANK.get(prof, 1) >= 2 and conf >= 0.50:
                strengths.append(item)
            elif conf < 0.50 or prof == "Beginner":
                weaknesses.append(item)

        return {
            "analyzed_skills": analyzed,
            "strengths": strengths,
            "weaknesses": weaknesses,
            "distribution": distribution
        }

    @staticmethod
    def generate_roadmap_items(
        missing_skills: List[Dict[str, Any]],
        underdeveloped_skills: List[Dict[str, Any]],
        preferred_style: str = "Hands-on",
        remedial_task: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        items = []

        # If there's an adaptive remedial task (Scenario B), inject it first!
        if remedial_task:
            items.append({
                "skill_name": remedial_task.get("skill_name", "Skill"),
                "title": remedial_task.get("title", "Remedial Concept Reinforcement"),
                "learning_objective": remedial_task.get("learning_objective", "Targeted concept revision"),
                "priority": "Critical",
                "difficulty": "Beginner",
                "estimated_duration_days": remedial_task.get("estimated_duration_days", 4),
                "status": "needs_revision",
                "resource_url": remedial_task.get("resource_url", "https://developer.mozilla.org"),
                "practical_exercise": remedial_task.get("practical_exercise", "Complete 5 targeted debugging exercises."),
                "order_index": 1
            })

        # Sort missing & underdeveloped by importance
        importance_order = {"Critical": 0, "High": 1, "Medium": 2, "Nice-to-have": 3}
        candidates = missing_skills + underdeveloped_skills
        candidates.sort(key=lambda x: (0 if x.get("status") == "missing" else 1, importance_order.get(x.get("importance"), 2)))

        start_order = len(items) + 1
        for idx, cand in enumerate(candidates):
            skill_name = cand.get("skill_name", "")
            req_prof = cand.get("required_proficiency", "Intermediate")
            importance = cand.get("importance", "High")

            ex_data = SKILL_PRACTICAL_EXERCISES.get(skill_name, {
                "objective": f"Acquire professional competence in {skill_name}.",
                "exercise": f"Build a practical capstone component implementing {skill_name}.",
                "duration_days": 7
            })

            # Match vetted resource
            matched_resource = "https://freecodecamp.org"
            for r in SEED_RESOURCES:
                if r["skill"] == skill_name:
                    matched_resource = r["url"]
                    break

            items.append({
                "skill_name": skill_name,
                "title": f"Master {skill_name} ({req_prof} Level)",
                "learning_objective": ex_data["objective"],
                "priority": importance,
                "difficulty": req_prof,
                "estimated_duration_days": ex_data["duration_days"],
                "status": "pending",
                "resource_url": matched_resource,
                "practical_exercise": ex_data["exercise"],
                "order_index": start_order + idx
            })

        return items

    @staticmethod
    def generate_mentor_reply(
        user_message: str,
        full_name: str,
        career_title: str,
        career_score: float,
        strengths: List[str],
        missing: List[str],
        current_task: Optional[Dict[str, Any]] = None,
        recent_attempt: Optional[Dict[str, Any]] = None
    ) -> str:
        msg = user_message.lower()

        if any(w in msg for w in ["ready", "readiness", "score", "chance", "how close", "am i ready"]):
            return (
                f"Hello {full_name}! Based on your verified learning telemetry, your current **Career Readiness Score is {career_score}%** for the **{career_title}** role.\n\n"
                f"**Key Strengths Already Established:**\n"
                f"{chr(10).join(['• ' + s for s in strengths[:3]]) if strengths else '• Core foundational knowledge'}\n\n"
                f"**Immediate High-Priority Competencies to Acquire:**\n"
                f"{chr(10).join(['• ' + s for s in missing[:3]]) if missing else '• You meet all essential requirements!'}\n\n"
                f"Focus on your active roadmap modules to steadily elevate your score toward 100%!"
            )
        elif any(w in msg for w in ["next", "step", "roadmap", "what should i do", "what to do"]):
            if current_task:
                return (
                    f"Your recommended immediate priority is: **{current_task.get('title', 'Active Task')}**.\n\n"
                    f"**Core Objective:** {current_task.get('learning_objective', '')}\n\n"
                    f"**Hands-on Project:** {current_task.get('practical_exercise', '')}\n\n"
                    f"**Study Resource:** [Launch Learning Module]({current_task.get('resource_url', 'https://freecodecamp.org')})"
                )
            return f"You can choose an upcoming module from your Learning Roadmap page or take a skill assessment to verify your level."
        elif any(w in msg for w in ["assessment", "test", "failed", "score", "javascript", "react"]):
            if recent_attempt:
                s_name = recent_attempt.get("skill_name", "Skill")
                score = recent_attempt.get("score", 0.0)
                weak = recent_attempt.get("weak_concepts", [])
                if score >= 70:
                    return f"Great job on your {s_name} assessment! You scored {int(score)}% and verified your competency."
                return (
                    f"I see you scored **{int(score)}%** on your recent {s_name} assessment. Don't worry!\n\n"
                    f"Our Progress Agent has identified key growth areas: **{', '.join(weak) if weak else 'Core concepts'}**.\n\n"
                    f"Your roadmap has been automatically updated with targeted remedial practice. Review the materials and test again!"
                )
            return "Skill assessments test your abilities with real MCQs and elevate your confidence rating. Try the JavaScript or Python assessment!"
        elif any(w in msg for w in ["switch", "change", "career", "ai engineer", "full stack"]):
            return (
                f"Targeting a new trajectory like **AI Engineer** is seamless! "
                f"When you change your goal, SkillPath AI's multi-agent orchestrator recalculates your readiness, "
                f"maps your existing strengths (like Python and Git), and generates a new versioned roadmap while preserving your history."
            )
        else:
            return (
                f"Hello {full_name}! I am your AI Mentor on SkillPath AI.\n\n"
                f"• Target Career: **{career_title}** ({career_score}% Readiness)\n"
                f"• Active Task: **{current_task.get('title') if current_task else 'Select from Roadmap'}**\n\n"
                f"How can I assist your learning journey today?"
            )
