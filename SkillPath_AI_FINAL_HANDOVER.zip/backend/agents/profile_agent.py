import time
from backend.agents.context import LearnerContext

class ProfileAgent:
    name: str = "Profile Agent"
    responsibility: str = "Processes learner profile, normalizes skill levels, identifies missing profile info, and prepares structured learner context."

    def run(self, context: LearnerContext) -> dict:
        start_time = time.time()
        missing = []
        if not context.education or context.education == "Not Specified":
            missing.append("Education Degree")
        if not context.institution or context.institution == "Not Specified":
            missing.append("College / Institution")
        if not context.target_career_id:
            missing.append("Target Career Goal")

        categorized = {}
        for s in context.learner_skills:
            cat = s.get("category", "General")
            categorized.setdefault(cat, []).append(s.get("skill_name"))

        elapsed_ms = int((time.time() - start_time) * 1000)
        summary = (
            f"Profile processed for {context.full_name}. "
            f"Identified {len(context.learner_skills)} existing skills across {len(categorized)} domains. "
            f"Target career: '{context.target_career_title}'."
        )

        return {
            "agent_name": self.name,
            "responsibility": self.responsibility,
            "status": "success",
            "execution_time_ms": elapsed_ms,
            "input_summary": f"Ingested profile data for {context.full_name} ({context.education})",
            "output_summary": summary,
            "missing_fields": missing,
            "categorized_skills": categorized
        }
