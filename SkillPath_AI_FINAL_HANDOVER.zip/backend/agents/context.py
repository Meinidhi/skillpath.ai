from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional

class LearnerContext(BaseModel):
    """
    Shared Pydantic LearnerContext passed between all six agents and orchestrator.
    Encapsulates real user state, empirical evidence, skill rankings,
    career requirements, and workflow triggers.
    """
    user_id: int
    full_name: str = "Learner"
    email: str = ""
    education: str = "Undergraduate"
    institution: str = "University"
    academic_year: str = "3rd Year"
    experience_level: str = "Beginner"
    preferred_learning_style: str = "Hands-on"
    
    # Career Target
    target_career_id: Optional[int] = None
    target_career_title: str = "Unassigned"
    target_career_requirements: List[Dict[str, Any]] = Field(default_factory=list)
    
    # Skills & Evidence
    learner_skills: List[Dict[str, Any]] = Field(default_factory=list)
    assessment_attempts: List[Dict[str, Any]] = Field(default_factory=list)
    
    # Processed Analysis Outputs
    analyzed_skills: List[Dict[str, Any]] = Field(default_factory=list)
    strengths: List[Dict[str, Any]] = Field(default_factory=list)
    weaknesses: List[Dict[str, Any]] = Field(default_factory=list)
    
    # Career Match
    career_readiness_score: float = 0.0
    formula_breakdown: str = ""
    meeting_skills: List[Dict[str, Any]] = Field(default_factory=list)
    underdeveloped_skills: List[Dict[str, Any]] = Field(default_factory=list)
    missing_skills: List[Dict[str, Any]] = Field(default_factory=list)
    critical_missing: List[str] = Field(default_factory=list)
    
    # Active Roadmap
    active_roadmap_id: Optional[int] = None
    active_roadmap_items: List[Dict[str, Any]] = Field(default_factory=list)
    current_task: Optional[Dict[str, Any]] = None
    new_roadmap_items: List[Dict[str, Any]] = Field(default_factory=list)
    
    # Adaptive State
    trigger: str = "Initial"
    change_reason: Optional[str] = None
    reassessment_needed: bool = False
    remedial_task: Optional[Dict[str, Any]] = None
    recent_attempt: Optional[Dict[str, Any]] = None
    
    # Mentor
    user_message: Optional[str] = None
    mentor_response: Optional[str] = None
    
    # Execution Metadata
    workflow_id: str = ""
    agent_executions: List[Dict[str, Any]] = Field(default_factory=list)
