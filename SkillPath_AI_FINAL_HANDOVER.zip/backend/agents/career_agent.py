import time
from backend.agents.context import LearnerContext
from backend.agents.rule_based_provider import RuleBasedProvider

class CareerAgent:
    name: str = "Career Agent"
    responsibility: str = "Compares learner skills with career requirements, calculates career readiness, and prioritizes missing competencies."

    def run(self, context: LearnerContext) -> dict:
        start_time = time.time()

        match_result = RuleBasedProvider.calculate_career_match(
            context.target_career_requirements,
            context.analyzed_skills
        )

        context.career_readiness_score = match_result["career_readiness_score"]
        context.formula_breakdown = match_result["formula_breakdown"]
        context.meeting_skills = match_result["meeting_skills"]
        context.underdeveloped_skills = match_result["underdeveloped_skills"]
        context.missing_skills = match_result["missing_skills"]
        context.critical_missing = match_result["critical_missing"]

        elapsed_ms = int((time.time() - start_time) * 1000)
        summary = (
            f"Career match calculated for '{context.target_career_title}'. "
            f"Readiness Score: {context.career_readiness_score}%. "
            f"Meeting: {len(context.meeting_skills)}, Underdeveloped: {len(context.underdeveloped_skills)}, "
            f"Missing: {len(context.missing_skills)} (Critical: {len(context.critical_missing)})."
        )

        return {
            "agent_name": self.name,
            "responsibility": self.responsibility,
            "status": "success",
            "execution_time_ms": elapsed_ms,
            "input_summary": f"Matching learner skills against {len(context.target_career_requirements)} requirements for {context.target_career_title}",
            "output_summary": summary,
            "career_readiness_score": context.career_readiness_score,
            "formula_breakdown": context.formula_breakdown,
            "meeting_skills": context.meeting_skills,
            "underdeveloped_skills": context.underdeveloped_skills,
            "missing_skills": context.missing_skills,
            "critical_missing": context.critical_missing
        }
