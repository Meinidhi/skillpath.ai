import time
from backend.agents.context import LearnerContext
from backend.agents.rule_based_provider import RuleBasedProvider

class SkillAnalysisAgent:
    name: str = "Skill Analysis Agent"
    responsibility: str = "Analyzes current skills, evaluates assessment evidence, weights confidence, and maps strengths/weaknesses."

    def run(self, context: LearnerContext) -> dict:
        start_time = time.time()

        calibration = RuleBasedProvider.calibrate_skills_with_evidence(
            context.learner_skills,
            context.assessment_attempts
        )

        context.analyzed_skills = calibration["analyzed_skills"]
        context.strengths = calibration["strengths"]
        context.weaknesses = calibration["weaknesses"]

        elapsed_ms = int((time.time() - start_time) * 1000)
        summary = (
            f"Evaluated {len(context.analyzed_skills)} skills against empirical evidence. "
            f"Confirmed {len(context.strengths)} strengths, {len(context.weaknesses)} growth areas. "
            f"Proficiency distribution: {calibration['distribution']}."
        )

        return {
            "agent_name": self.name,
            "responsibility": self.responsibility,
            "status": "success",
            "execution_time_ms": elapsed_ms,
            "input_summary": f"Analyzing {len(context.learner_skills)} skills against {len(context.assessment_attempts)} assessment records",
            "output_summary": summary,
            "analyzed_skills": context.analyzed_skills,
            "strengths": context.strengths,
            "weaknesses": context.weaknesses,
            "distribution": calibration["distribution"]
        }
