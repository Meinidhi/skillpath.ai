import time
from backend.agents.context import LearnerContext
from backend.agents.rule_based_provider import RuleBasedProvider

class AIMentorAgent:
    name: str = "AI Mentor Agent"
    responsibility: str = "Provides hyper-personalized, context-aware mentoring, career transition coaching, and grounded assessment feedback."

    def run(self, context: LearnerContext) -> dict:
        start_time = time.time()

        user_msg = context.user_message or ""
        trigger = context.trigger or "General"

        # Specialized trigger flows
        if trigger == "CareerGoalChange":
            response = (
                f"Welcome to your newly targeted trajectory as an **{context.target_career_title}**, {context.full_name}!\n\n"
                f"Our multi-agent system has recalculated your **Career Readiness Score to {context.career_readiness_score}%**. "
                f"Your existing competencies in {[s.get('skill_name') for s in context.strengths[:3]]} provide a solid foundation!\n\n"
                f"We have generated a new versioned learning roadmap targeting your new priorities: "
                f"{', '.join([s.get('skill_name') for s in context.missing_skills[:3]])}. "
                f"Your previous roadmaps remain safely preserved in your history. Let's begin!"
            )
        elif trigger == "AssessmentEvaluation":
            attempt = context.recent_attempt or {}
            score = attempt.get("score", 0.0)
            skill = attempt.get("skill_name", "Skill")
            weak = attempt.get("weak_concepts", [])

            if score < 65.0:
                response = (
                    f"Hello {context.full_name}. I reviewed your diagnostic score of **{int(score)}%** on **{skill}**.\n\n"
                    f"Do not be discouraged! These assessments are specifically designed to expose blind spots before interview time. "
                    f"Our Progress Agent flagged key concepts to revisit: **{', '.join(weak) if weak else 'Core fundamentals'}**.\n\n"
                    f"Your learning roadmap has been adapted with a priority remedial practice task and curated documentation. "
                    f"Take a moment to review the exercises, and re-test when you feel ready!"
                )
            else:
                response = (
                    f"Congratulations {context.full_name}! You scored **{int(score)}%** on **{skill}** and proved your competency!\n\n"
                    f"This verified evidence has been integrated into your Skill Analysis profile, raising your confidence score. "
                    f"You are on track toward your target role of **{context.target_career_title}**!"
                )
        else:
            response = RuleBasedProvider.generate_mentor_reply(
                user_message=user_msg,
                full_name=context.full_name,
                career_title=context.target_career_title,
                career_score=context.career_readiness_score,
                strengths=[s.get("skill_name", "") for s in context.strengths],
                missing=[s.get("skill_name", "") for s in context.missing_skills],
                current_task=context.current_task,
                recent_attempt=context.recent_attempt
            )

        context.mentor_response = response
        elapsed_ms = int((time.time() - start_time) * 1000)

        return {
            "agent_name": self.name,
            "responsibility": self.responsibility,
            "status": "success",
            "execution_time_ms": elapsed_ms,
            "input_summary": f"Providing guidance for trigger '{trigger}' (Readiness: {context.career_readiness_score}%)",
            "output_summary": f"Generated contextual mentor guidance ({len(response)} chars)",
            "mentor_response": response
        }
