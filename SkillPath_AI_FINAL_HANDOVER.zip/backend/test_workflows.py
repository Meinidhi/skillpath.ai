import sys
import os

# Ensure project root and backend are on sys.path
backend_dir = os.path.dirname(os.path.abspath(__file__))
project_dir = os.path.dirname(backend_dir)
if project_dir not in sys.path:
    sys.path.insert(0, project_dir)
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

from app.core.database import SessionLocal, engine, Base
from app.core.init_db import init_db
from app.models.models import (
    User, LearnerProfile, CareerRole, Assessment, AssessmentAttempt,
    LearningRoadmap, RoadmapVersion, AgentExecution
)
from backend.agents.orchestrator import CustomOrchestrator

def run_tests():
    print("==================================================")
    print("   SKILLPATH AI - BACKEND WORKFLOW VERIFICATION   ")
    print("==================================================")

    # 1. Initialize DB & Seed Data
    print("\n[Step 1] Initializing SQLite Database & Seeding Data...")
    db = SessionLocal()
    init_db(db)
    print("✓ Tables created and verified.")
    careers_count = db.query(CareerRole).count()
    assessments_count = db.query(Assessment).count()
    print(f"✓ Seeded {careers_count} career paths and {assessments_count} skill assessments.")

    # 2. Verify Demo User
    print("\n[Step 2] Verifying Demo User (Alex Chen)...")
    demo = db.query(User).filter(User.email == "demo@skillpath.ai").first()
    assert demo is not None, "Demo user must exist"
    print(f"✓ Found Demo User: {demo.full_name} ({demo.email}), id={demo.id}")

    orchestrator = CustomOrchestrator(db)

    # 3. Test Full Stack Developer Initial Roadmap
    print("\n[Step 3] Generating Initial Roadmap for Full Stack Developer...")
    init_result = orchestrator.run_initial_onboarding_workflow(demo.id)
    assert init_result["status"] == "success"
    print(f"✓ Initial Workflow Completed:")
    print(f"  - Career Readiness: {init_result['readiness_score']}%")
    print(f"  - Roadmap Version: {init_result['roadmap_version']}")
    print(f"  - Mentor Welcome: {init_result['mentor_welcome'][:100]}...")

    # 4. Verify Roadmap in DB
    roadmap = db.query(LearningRoadmap).filter(
        LearningRoadmap.user_id == demo.id,
        LearningRoadmap.is_active == True
    ).first()
    assert roadmap is not None
    assert len(roadmap.versions) >= 1
    v1 = roadmap.versions[-1]
    print(f"✓ Stored Roadmap Version {v1.version_number} with {len(v1.items)} modules.")

    # 5. Test Scenario B: Poor JavaScript Assessment Performance
    print("\n[Step 4] Executing SCENARIO B: Poor Assessment Performance...")
    js_assessment = db.query(Assessment).filter(Assessment.title.like("%JavaScript%")).first()
    assert js_assessment is not None, "JavaScript assessment required"

    # Simulate failing attempt (1 correct out of 5 -> 20% score)
    bad_attempt = AssessmentAttempt(
        user_id=demo.id,
        assessment_id=js_assessment.id,
        score=20.0,
        total_questions=5,
        correct_count=1,
        passed=False,
        weak_concepts=["Closures & Scope", "Event Loop & Concurrency", "Async/Await & Error Handling"],
        answers_summary=[]
    )
    db.add(bad_attempt)
    db.commit()
    db.refresh(bad_attempt)

    assess_result = orchestrator.run_assessment_workflow(demo.id, bad_attempt.id)
    assert assess_result["status"] == "success"
    assert assess_result["reassessment_needed"] is True, "Reassessment must be triggered for low score"
    print(f"✓ Scenario B Result:")
    print(f"  - Score: {assess_result['score']}%")
    print(f"  - Reassessment Needed: {assess_result['reassessment_needed']}")
    print(f"  - New Roadmap Version: {assess_result['new_roadmap_version']}")
    print(f"  - Mentor Feedback: {assess_result['mentor_feedback'][:120]}...")

    # Check that roadmap version increased and remedial task exists
    db.refresh(roadmap)
    assert roadmap.current_version > 1, "Roadmap version must increment after adaptation"
    latest_v = roadmap.versions[0]
    has_remedial = any(item.status == "needs_revision" for item in latest_v.items)
    assert has_remedial, "Adapted roadmap must contain remedial practice task"
    print(f"✓ Adapted Roadmap Version {latest_v.version_number} contains remedial task ({has_remedial}).")

    # 6. Test Scenario A: Career Goal Change to AI Engineer
    print("\n[Step 5] Executing SCENARIO A: Career Goal Change to AI Engineer...")
    ai_career = db.query(CareerRole).filter(CareerRole.title == "AI Engineer").first()
    assert ai_career is not None, "AI Engineer career must exist"

    career_change_result = orchestrator.run_career_change_workflow(demo.id, ai_career.id)
    assert career_change_result["status"] == "success"
    print(f"✓ Scenario A Result:")
    print(f"  - Transitioned: '{career_change_result['from_career']}' -> '{career_change_result['to_career']}'")
    print(f"  - Recalculated Readiness: {career_change_result['new_readiness_score']}%")
    print(f"  - New Roadmap Version: {career_change_result['roadmap_version']}")
    print(f"  - Mentor Welcome: {career_change_result['mentor_welcome'][:120]}...")

    # 7. Verify All Roadmap Versions Remain Accessible
    print("\n[Step 6] Verifying Roadmap Version Preservation...")
    db.refresh(roadmap)
    print(f"✓ Total Stored Roadmap Versions: {len(roadmap.versions)}")
    for v in roadmap.versions:
        print(f"  • Version {v.version_number}: Trigger='{v.change_trigger}', Reason='{v.change_reason[:60]}...' ({len(v.items)} items)")
    assert len(roadmap.versions) >= 3, "All previous versions must be preserved"

    # 8. Verify Six Agents Executed & Logged to DB
    print("\n[Step 7] Verifying Agent Execution Logs...")
    logs = db.query(AgentExecution).filter(AgentExecution.user_id == demo.id).all()
    agent_names = set(l.agent_name for l in logs)
    print(f"✓ Found {len(logs)} execution records logged in database.")
    print(f"✓ Distinct Agents Executed: {agent_names}")
    expected_agents = {"Profile Agent", "Skill Analysis Agent", "Career Agent", "Learning Agent", "Progress Agent", "AI Mentor Agent"}
    assert expected_agents.issubset(agent_names), f"All 6 agents must be recorded, got {agent_names}"

    db.close()
    print("\n==================================================")
    print("   ALL BACKEND ADAPTIVE TESTS PASSED SUCCESSFULLY! ")
    print("==================================================")

if __name__ == "__main__":
    run_tests()
