import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { ProgressOverview } from '../types';
import {
  TrendingUp, Award, CheckCircle, Clock, ArrowRight,
  Sparkles, Bot, AlertTriangle, ShieldCheck, PlayCircle, ExternalLink
} from 'lucide-react';

interface DashboardViewProps {
  onNavigate: (tab: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigate }) => {
  const [data, setData] = useState<ProgressOverview | null>(null);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    try {
      setLoading(true);
      const res = await api.getProgressOverview();
      setData(res);
    } catch (err) {
      console.error("Dashboard error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCompleteTask = async (taskId: number) => {
    try {
      await api.updateItemStatus(taskId, 'completed');
      loadData();
    } catch (err) {
      console.error(err);
    }
  };

  if (loading && !data) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center space-y-3">
          <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-xs text-slate-500 font-medium">Synthesizing multi-agent intelligence...</p>
        </div>
      </div>
    );
  }

  const activeTask = data?.upcoming_tasks && data.upcoming_tasks.length > 0 ? data.upcoming_tasks[0] : null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner / Hero Metric */}
      <div className="rounded-3xl bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-900 text-white p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-white/5 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur border border-white/20 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-sky-300" />
              <span>Target Role: {data?.target_career || 'Full Stack Developer'}</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight">
              Personal Learning Command Center
            </h1>
            <p className="text-xs sm:text-sm text-blue-100/90 max-w-xl">
              Six autonomous agents analyze your skills, sequence your curriculum, and adapt your trajectory as you learn.
            </p>
          </div>

          {/* Big Readiness Score */}
          <div className="flex items-center space-x-4 bg-white/10 backdrop-blur p-4 sm:p-5 rounded-2xl border border-white/20 shrink-0">
            <div className="text-right">
              <span className="block text-[11px] uppercase tracking-wider text-blue-200 font-bold">Career Readiness</span>
              <span className="text-3xl sm:text-4xl font-black">{data?.career_readiness_score || 0}%</span>
            </div>
            <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center text-white">
              <TrendingUp className="w-7 h-7 text-sky-300" />
            </div>
          </div>
        </div>

        {/* Quick Scenario Demonstration Banner for Judges */}
        <div className="mt-6 pt-4 border-t border-white/15 flex flex-wrap items-center justify-between gap-3 text-xs">
          <span className="text-blue-100 font-medium">
            ⚡ <strong>Competition Highlights:</strong> Live demonstration of Scenario A (Career Goal Transition) and Scenario B (Assessment Deficit Adaptation).
          </span>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => onNavigate('careers')}
              className="px-3 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-white font-semibold transition-all cursor-pointer"
            >
              Test Scenario A (AI Engineer)
            </button>
            <button
              onClick={() => onNavigate('assessments')}
              className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-500 text-slate-900 font-bold transition-all cursor-pointer shadow"
            >
              Test Scenario B (JavaScript 20%)
            </button>
          </div>
        </div>
      </div>

      {/* 4 Quick Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Skills Mastered</span>
            <Award className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{data?.skills_mastered_count || 0}</div>
          <p className="text-[11px] text-slate-500 mt-1">Advanced or Expert tier</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Skills In Progress</span>
            <Clock className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{data?.skills_in_progress_count || 0}</div>
          <p className="text-[11px] text-slate-500 mt-1">Across active domains</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Roadmap Progress</span>
            <CheckCircle className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{data?.roadmap_completion_pct || 0}%</div>
          <p className="text-[11px] text-slate-500 mt-1">{data?.active_tasks_count || 0} modules remaining</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Assessments Passed</span>
            <ShieldCheck className="w-4 h-4 text-purple-500" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{data?.assessments_completed_count || 0}</div>
          <p className="text-[11px] text-slate-500 mt-1">Avg Score: {data?.average_assessment_score || 0}%</p>
        </div>
      </div>

      {/* Main Grid: Active Task + Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Active Task & Upcoming Modules */}
        <div className="lg:col-span-2 space-y-6">
          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                  Recommended Immediate Step
                </span>
                <h2 className="text-lg font-bold text-slate-900 mt-1">Active Learning Milestone</h2>
              </div>
              <button
                onClick={() => onNavigate('roadmap')}
                className="text-xs text-blue-600 hover:text-blue-800 font-semibold flex items-center space-x-1"
              >
                <span>View Full Roadmap</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {activeTask ? (
              <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center space-x-2">
                      <h3 className="font-bold text-slate-900 text-base">{activeTask.title}</h3>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        activeTask.priority === 'Critical' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'
                      }`}>
                        {activeTask.priority} Priority
                      </span>
                      {activeTask.status === 'needs_revision' && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800 flex items-center">
                          <AlertTriangle className="w-3 h-3 mr-1" />
                          Remedial Intervention
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-600 mt-1">{activeTask.learning_objective}</p>
                  </div>
                  <span className="text-xs font-semibold text-slate-500 shrink-0">~{activeTask.estimated_duration_days} days</span>
                </div>

                {activeTask.practical_exercise && (
                  <div className="p-3 bg-white rounded-lg border border-slate-200 text-xs text-slate-700">
                    <span className="font-bold text-slate-900">Hands-on Mini Project: </span>
                    {activeTask.practical_exercise}
                  </div>
                )}

                <div className="flex items-center justify-between pt-2">
                  {activeTask.resource_url ? (
                    <a
                      href={activeTask.resource_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-blue-600 hover:underline flex items-center space-x-1 font-semibold"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Open Verified Resource</span>
                    </a>
                  ) : <span />}

                  <button
                    onClick={() => handleCompleteTask(activeTask.id)}
                    className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center space-x-1.5 shadow-sm transition-all cursor-pointer"
                  >
                    <CheckCircle className="w-4 h-4" />
                    <span>Mark Milestone Complete</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-slate-500 text-xs">
                All scheduled roadmap items completed! Switch career goals or generate advanced electives.
              </div>
            )}
          </div>

          {/* Upcoming Learning Pipeline */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm">
            <h3 className="text-base font-bold text-slate-900 mb-4">Upcoming Roadmap Pipeline</h3>
            <div className="space-y-3">
              {data?.upcoming_tasks && data.upcoming_tasks.slice(1, 4).map((task, idx) => (
                <div key={task.id} className="p-3.5 rounded-xl border border-slate-200 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div className="flex items-center space-x-3">
                    <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center font-bold text-xs">
                      {idx + 2}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">{task.title}</h4>
                      <p className="text-[11px] text-slate-500 line-clamp-1">{task.learning_objective}</p>
                    </div>
                  </div>
                  <span className="text-[11px] text-slate-400 font-medium">{task.difficulty}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Col: AI Mentor Card & Recent Activity */}
        <div className="space-y-6">
          {/* AI Mentor Quick Interaction Card */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-indigo-50 to-blue-50 border border-indigo-200/80 shadow-sm">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md shadow-blue-500/20">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm">AI Career Mentor</h3>
                <p className="text-[11px] text-slate-500">Context-Aware Guidance Engine</p>
              </div>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed mb-4">
              Your mentor is continuously synchronized with your roadmap, recent test scores, and target career specifications.
            </p>
            <button
              onClick={() => onNavigate('mentor')}
              className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center space-x-1.5 shadow transition-all cursor-pointer"
            >
              <span>Consult AI Mentor</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Recent Multi-Agent Activity Feed */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-slate-900 text-sm">Autonomous Agent Telemetry</h3>
              <button
                onClick={() => onNavigate('agents')}
                className="text-[11px] text-blue-600 hover:underline font-semibold"
              >
                Inspect All
              </button>
            </div>
            <div className="space-y-3">
              {data?.recent_activities && data.recent_activities.length > 0 ? (
                data.recent_activities.map((act, i) => (
                  <div key={i} className="flex items-start space-x-3 text-xs">
                    <div className="w-2 h-2 rounded-full bg-blue-500 mt-1.5 shrink-0" />
                    <div>
                      <span className="font-bold text-slate-800">{act.title}</span>
                      <p className="text-[11px] text-slate-500 line-clamp-2 mt-0.5">{act.description}</p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-400">Telemetry logs will appear as agents execute.</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
