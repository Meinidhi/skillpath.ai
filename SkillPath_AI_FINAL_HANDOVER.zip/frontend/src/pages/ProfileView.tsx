import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { LearnerProfile, CareerRole } from '../types';
import { useAuth } from '../context/AuthContext';
import { User, BookOpen, Briefcase, Award, CheckCircle, Save, AlertCircle } from 'lucide-react';

export const ProfileView: React.FC = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState<LearnerProfile | null>(null);
  const [careers, setCareers] = useState<CareerRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Form states
  const [education, setEducation] = useState('');
  const [institution, setInstitution] = useState('');
  const [academicYear, setAcademicYear] = useState('');
  const [experienceLevel, setExperienceLevel] = useState('Beginner');
  const [preferredStyle, setPreferredStyle] = useState('Hands-on');
  const [targetCareerId, setTargetCareerId] = useState<number | null>(null);
  const [softSkillsInput, setSoftSkillsInput] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [profData, careersData] = await Promise.all([
          api.getProfile(),
          api.getAllCareers()
        ]);
        setProfile(profData);
        setCareers(careersData);

        setEducation(profData.education);
        setInstitution(profData.institution);
        setAcademicYear(profData.academic_year);
        setExperienceLevel(profData.experience_level);
        setPreferredStyle(profData.preferred_learning_style);
        setTargetCareerId(profData.target_career_id);
        setSoftSkillsInput((profData.soft_skills || []).join(', '));
      } catch (err) {
        console.error("Profile fetch error:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSuccessMsg(null);
    try {
      const softSkills = softSkillsInput
        .split(',')
        .map(s => s.trim())
        .filter(s => s.length > 0);

      const updated = await api.updateProfile({
        education,
        institution,
        academic_year: academicYear,
        experience_level: experienceLevel,
        preferred_learning_style: preferredStyle,
        target_career_id: targetCareerId,
        soft_skills: softSkills
      });
      setProfile(updated);
      setSuccessMsg("Profile and career preferences successfully updated! Multi-agent context refreshed.");
      setTimeout(() => setSuccessMsg(null), 4000);
    } catch (err: any) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="p-8 text-center text-xs text-slate-500">Loading learner profile...</div>;
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">Learner Profile Architecture</h1>
        <p className="text-xs text-slate-500 mt-1">
          Maintain your academic background, experience tier, and target career to calibrate agent recommendations.
        </p>
      </div>

      {successMsg && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center space-x-2">
          <CheckCircle className="w-4 h-4 shrink-0 text-emerald-600" />
          <span>{successMsg}</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* Core Personal & Academic Card */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center space-x-2 text-sm font-bold text-slate-900 pb-2 border-b border-slate-100">
            <User className="w-4 h-4 text-blue-600" />
            <span>Academic Background</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
              <input
                type="text"
                disabled
                value={user?.full_name || ''}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-500 cursor-not-allowed"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Email</label>
              <input
                type="email"
                disabled
                value={user?.email || ''}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-500 cursor-not-allowed"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Education Degree</label>
              <input
                type="text"
                value={education}
                onChange={(e) => setEducation(e.target.value)}
                placeholder="B.S. in Computer Science"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">College or Institution</label>
              <input
                type="text"
                value={institution}
                onChange={(e) => setInstitution(e.target.value)}
                placeholder="State Technical University"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Current Academic Year</label>
              <select
                value={academicYear}
                onChange={(e) => setAcademicYear(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
              >
                <option value="1st Year">1st Year</option>
                <option value="2nd Year">2nd Year</option>
                <option value="3rd Year">3rd Year</option>
                <option value="4th Year">4th Year / Senior</option>
                <option value="Graduate / Post-Grad">Graduate / Post-Grad</option>
                <option value="Working Professional">Working Professional</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Overall Experience Tier</label>
              <select
                value={experienceLevel}
                onChange={(e) => setExperienceLevel(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
              >
                <option value="Beginner">Beginner (Foundational)</option>
                <option value="Intermediate">Intermediate (Hands-on experience)</option>
                <option value="Advanced">Advanced (Production projects)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Career & Learning Preferences */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center space-x-2 text-sm font-bold text-slate-900 pb-2 border-b border-slate-100">
            <Briefcase className="w-4 h-4 text-indigo-600" />
            <span>Target Career Ambition & Style</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Target Career Goal</label>
              <select
                value={targetCareerId || ''}
                onChange={(e) => setTargetCareerId(Number(e.target.value))}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
              >
                {careers.map((c) => (
                  <option key={c.id} value={c.id}>{c.title} ({c.category})</option>
                ))}
              </select>
              <p className="text-[11px] text-slate-500 mt-1">Changing your goal triggers automatic roadmap reassessment (Scenario A).</p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Preferred Learning Style</label>
              <select
                value={preferredStyle}
                onChange={(e) => setPreferredStyle(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
              >
                <option value="Hands-on">Hands-on (Code projects & practical exercises)</option>
                <option value="Interactive">Interactive (Guided browser tutorials & sandboxes)</option>
                <option value="Documentation">Documentation (Deep specification reading)</option>
                <option value="Video-first">Video & Guides (Structured visual courses)</option>
              </select>
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">Soft Skills (Comma separated)</label>
              <input
                type="text"
                value={softSkillsInput}
                onChange={(e) => setSoftSkillsInput(e.target.value)}
                placeholder="Problem Solving, Communication, Critical Thinking, Team Collaboration"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Existing Projects and Certifications Display */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center space-x-2 text-sm font-bold text-slate-900 pb-2 border-b border-slate-100">
            <Award className="w-4 h-4 text-purple-600" />
            <span>Verified Portfolio & Credentials</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="text-xs font-bold text-slate-700 mb-2">Completed Projects</h4>
              {profile?.projects && profile.projects.length > 0 ? (
                <div className="space-y-2">
                  {profile.projects.map((p, idx) => (
                    <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                      <div className="font-bold text-slate-900">{p.title}</div>
                      <p className="text-[11px] text-slate-600 mt-0.5">{p.description}</p>
                      <div className="flex flex-wrap gap-1 mt-1.5">
                        {p.technologies?.map((t, ti) => (
                          <span key={ti} className="text-[10px] px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 font-medium">
                            {t}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-400">No projects recorded yet.</p>
              )}
            </div>

            <div>
              <h4 className="text-xs font-bold text-slate-700 mb-2">Certifications</h4>
              {profile?.certifications && profile.certifications.length > 0 ? (
                <div className="space-y-2">
                  {profile.certifications.map((c, idx) => (
                    <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                      <div className="font-bold text-slate-900">{c.title}</div>
                      <p className="text-[11px] text-slate-500">{c.issuer} ({c.year})</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-400">No certifications recorded yet.</p>
              )}
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={saving}
            className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center space-x-2 shadow-md shadow-blue-500/20 transition-all cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'Updating Learner Context...' : 'Save Profile Changes'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
