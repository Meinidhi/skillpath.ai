import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { Assessment, AssessmentAttempt } from '../types';
import {
  GraduationCap, CheckCircle2, XCircle, AlertTriangle, ArrowRight,
  Sparkles, RefreshCw, Zap, ShieldAlert, Award
} from 'lucide-react';

interface AssessmentViewProps {
  onNavigate: (tab: string) => void;
}

export const AssessmentView: React.FC<AssessmentViewProps> = ({ onNavigate }) => {
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [selectedAssessmentId, setSelectedAssessmentId] = useState<number | null>(null);
  const [activeAssessment, setActiveAssessment] = useState<Assessment | null>(null);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [submitting, setSubmitting] = useState(false);
  const [attemptResult, setAttemptResult] = useState<AssessmentAttempt | null>(null);
  const [loading, setLoading] = useState(true);

  // Scenario B Simulation state
  const [simulatingB, setSimulatingB] = useState(false);

  useEffect(() => {
    const fetchAssessments = async () => {
      try {
        setLoading(true);
        const data = await api.listAssessments();
        setAssessments(data);
        if (data.length > 0) {
          loadAssessmentDetail(data[0].id);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchAssessments();
  }, []);

  const loadAssessmentDetail = async (id: number) => {
    setSelectedAssessmentId(id);
    setSelectedAnswers({});
    setAttemptResult(null);
    try {
      const detail = await api.getAssessment(id);
      setActiveAssessment(detail);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSelectOption = (questionId: number, optionIndex: number) => {
    setSelectedAnswers({
      ...selectedAnswers,
      [questionId]: optionIndex
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAssessmentId) return;
    setSubmitting(true);
    try {
      const res = await api.submitAssessment(selectedAssessmentId, selectedAnswers);
      setAttemptResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  // SCENARIO B DEMONSTRATION: Poor JavaScript Assessment (20% score)
  const handleDemonstrateScenarioB = async () => {
    const jsAssessment = assessments.find(a => a.skill_name.toLowerCase().includes('javascript'));
    if (!jsAssessment) return;

    setSimulatingB(true);
    setAttemptResult(null);
    try {
      // Pick intentionally wrong answers (option 3 for all, where only one might match)
      const detail = await api.getAssessment(jsAssessment.id);
      setActiveAssessment(detail);
      setSelectedAssessmentId(jsAssessment.id);

      const deliberateFailingAnswers: Record<number, number> = {};
      detail.questions?.forEach((q, idx) => {
        // Answer only the first question correctly, intentionally miss the rest to score ~20%
        deliberateFailingAnswers[q.id] = (idx === 0) ? 0 : 3;
      });
      setSelectedAnswers(deliberateFailingAnswers);

      const res = await api.submitAssessment(jsAssessment.id, deliberateFailingAnswers);
      setAttemptResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setSimulatingB(false);
    }
  };

  if (loading && assessments.length === 0) {
    return <div className="p-8 text-center text-xs text-slate-500">Loading diagnostic question banks...</div>;
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">Skill Competency Assessments</h1>
          <p className="text-xs text-slate-500 mt-1">
            Empirical diagnostic assessments. Automatically updates verified proficiency and triggers adaptive roadmap adjustments.
          </p>
        </div>

        {/* Assessment Category Selector */}
        <div className="flex overflow-x-auto space-x-2 scrollbar-none">
          {assessments.map(a => (
            <button
              key={a.id}
              onClick={() => loadAssessmentDetail(a.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedAssessmentId === a.id
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              {a.skill_name}
            </button>
          ))}
        </div>
      </div>

      {/* SPECIAL COMPETITION SCENARIO B BANNER */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-amber-900 via-orange-900 to-slate-900 text-white shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur border border-white/20 text-xs font-bold text-amber-200">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>COMPETITION TEST: SCENARIO B</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black">
              Demonstrate Adaptive Intervention on Poor JavaScript Score (20%)
            </h2>
            <p className="text-xs text-amber-100/90 max-w-xl">
              Triggers the autonomous adaptation pipeline: Progress Agent flags concept deficits (Closures, Event Loop),
              calibrates skill evidence, injects remedial tasks into Roadmap Version 2, and delivers diagnostic mentor feedback!
            </p>
          </div>

          <button
            onClick={handleDemonstrateScenarioB}
            disabled={simulatingB}
            className="px-6 py-3.5 rounded-xl font-extrabold text-xs shadow-lg bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-900 shadow-amber-500/25 transition-all flex items-center justify-center space-x-2 cursor-pointer shrink-0"
          >
            <Sparkles className="w-4 h-4" />
            <span>{simulatingB ? 'Evaluating Diagnostic...' : 'Execute Scenario B (20% Score)'}</span>
          </button>
        </div>
      </div>

      {/* Assessment Test Card */}
      {activeAssessment && (
        <div className="p-6 sm:p-8 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-2">
            <div>
              <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                {activeAssessment.category} • {activeAssessment.difficulty}
              </span>
              <h2 className="text-xl font-bold text-slate-900 mt-1">{activeAssessment.title}</h2>
            </div>
            <span className="text-xs font-semibold text-slate-500">
              Pass Benchmark: {activeAssessment.pass_score}%
            </span>
          </div>

          {/* If Result Already Available */}
          {attemptResult && (
            <div className={`p-6 rounded-2xl border space-y-4 animate-fade-in ${
              attemptResult.passed
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-amber-50 border-amber-300 text-amber-950'
            }`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  {attemptResult.passed ? (
                    <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                  ) : (
                    <AlertTriangle className="w-6 h-6 text-amber-600" />
                  )}
                  <div>
                    <h3 className="text-base font-bold">
                      {attemptResult.passed ? 'Assessment Passed!' : 'Performance Deficit Detected'}
                    </h3>
                    <p className="text-xs mt-0.5">
                      Diagnostic Score: <strong>{attemptResult.score}%</strong> ({attemptResult.correct_count}/{attemptResult.total_questions} correct).
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => onNavigate('roadmap')}
                  className="px-4 py-2 rounded-xl bg-slate-900 text-white font-bold text-xs flex items-center space-x-1.5 shadow"
                >
                  <span>View Adapted Roadmap</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {attemptResult.adaptation_triggered && (
                <div className="p-4 bg-white/80 rounded-xl border border-amber-200 text-xs text-amber-900 space-y-1.5">
                  <div className="flex items-center space-x-1.5 font-bold text-amber-800">
                    <ShieldAlert className="w-4 h-4 text-amber-600" />
                    <span>Autonomous Roadmap Adaptation Triggered (Scenario B)</span>
                  </div>
                  <p className="leading-relaxed">
                    Weak Concepts Isolated: <strong>{attemptResult.weak_concepts?.join(', ')}</strong>.
                  </p>
                  <p className="text-[11px] text-amber-800">
                    {attemptResult.adaptation_summary}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Questions Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {activeAssessment.questions?.map((q, qIndex) => {
              const explanationData = attemptResult?.explanations?.find(e => e.question_id === q.id);

              return (
                <div key={q.id} className="p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                  <div className="flex items-start justify-between">
                    <h3 className="text-xs font-bold text-slate-900 flex items-start space-x-2">
                      <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                        {qIndex + 1}
                      </span>
                      <span>{q.question_text}</span>
                    </h3>
                    <span className="text-[10px] font-semibold text-slate-500 bg-white px-2 py-0.5 rounded border border-slate-200 shrink-0">
                      {q.concept_tag}
                    </span>
                  </div>

                  <div className="space-y-2 pt-1">
                    {q.options.map((opt, optIndex) => {
                      const isSelected = selectedAnswers[q.id] === optIndex;
                      return (
                        <label
                          key={optIndex}
                          className={`flex items-center space-x-3 p-3 rounded-lg border text-xs font-medium cursor-pointer transition-all ${
                            isSelected
                              ? 'bg-blue-50 border-blue-500 text-blue-900 shadow-sm'
                              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                          }`}
                        >
                          <input
                            type="radio"
                            name={`question-${q.id}`}
                            checked={isSelected}
                            onChange={() => handleSelectOption(q.id, optIndex)}
                            className="text-blue-600 focus:ring-blue-500"
                          />
                          <span>{opt}</span>
                        </label>
                      );
                    })}
                  </div>

                  {/* Explanation Card if submitted */}
                  {explanationData && (
                    <div className={`p-3 rounded-lg text-xs mt-2 border ${
                      explanationData.is_correct
                        ? 'bg-emerald-50/60 border-emerald-200 text-emerald-900'
                        : 'bg-red-50/60 border-red-200 text-red-900'
                    }`}>
                      <span className="font-bold">
                        {explanationData.is_correct ? '✓ Correct! ' : '✗ Incorrect. '}
                      </span>
                      {explanationData.explanation}
                    </div>
                  )}
                </div>
              );
            })}

            <div className="flex justify-end pt-4">
              <button
                type="submit"
                disabled={submitting}
                className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-500/20 transition-all cursor-pointer"
              >
                {submitting ? 'Evaluating Diagnostic...' : 'Submit Assessment Answers'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
