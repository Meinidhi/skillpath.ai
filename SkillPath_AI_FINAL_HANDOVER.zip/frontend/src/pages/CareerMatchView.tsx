import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { CareerRole, CareerMatchResult } from '../types';
import {
  TrendingUp, CheckCircle2, AlertCircle, XCircle, ArrowRight,
  Sparkles, RefreshCw, Zap, Bot, Layers, Info
} from 'lucide-react';

interface CareerMatchViewProps {
  initialCareerId?: number;
  onNavigate: (tab: string) => void;
}

export const CareerMatchView: React.FC<CareerMatchViewProps> = ({ initialCareerId, onNavigate }) => {
  const [careers, setCareers] = useState<CareerRole[]>([]);
  const [selectedCareerId, setSelectedCareerId] = useState<number>(initialCareerId || 1);
  const [matchData, setMatchData] = useState<CareerMatchResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [switching, setSwitching] = useState(false);
  const [scenarioAResult, setScenarioAResult] = useState<any>(null);

  const fetchCareersAndMatch = async (careerId: number) => {
    try {
      setLoading(true);
      const [allCareers, match] = await Promise.all([
        api.getAllCareers(),
        api.matchCareer(careerId)
      ]);
      setCareers(allCareers);
      setMatchData(match);
      setSelectedCareerId(careerId);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCareersAndMatch(initialCareerId || 1);
  }, [initialCareerId]);

  const handleCareerSelect = async (careerId: number) => {
    setSelectedCareerId(careerId);
    try {
      setLoading(true);
      const match = await api.matchCareer(careerId);
      setMatchData(match);
    } finally {
      setLoading(false);
    }
  };

  // SCENARIO A DEMONSTRATION: Switch Career Goal to AI Engineer
  const handleDemonstrateScenarioA = async () => {
    const aiCareer = careers.find(c => c.title.toLowerCase().includes('ai engineer'));
    if (!aiCareer) return;

    setSwitching(true);
    setScenarioAResult(null);
    try {
      const res = await api.changeCareerGoal(aiCareer.id);
      setScenarioAResult(res);
      await fetchCareersAndMatch(aiCareer.id);
    } catch (err) {
      console.error(err);
    } finally {
      setSwitching(false);
    }
  };

  if (loading && !matchData) {
    return <div className="p-8 text-center text-xs text-slate-500">Matching profile competencies against career specifications...</div>;
  }

  const aiCareerObj = careers.find(c => c.title.toLowerCase().includes('ai engineer'));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">Career Competency Benchmarking</h1>
          <p className="text-xs text-slate-500 mt-1">
            Empirical gap analysis executed by the Career Agent. Computes weighted readiness scores based on required proficiencies.
          </p>
        </div>

        {/* Career Goal Selector */}
        <div className="flex items-center space-x-2">
          <label className="text-xs font-bold text-slate-600">Select Role:</label>
          <select
            value={selectedCareerId}
            onChange={(e) => handleCareerSelect(Number(e.target.value))}
            className="px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-semibold bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
          >
            {careers.map((c) => (
              <option key={c.id} value={c.id}>{c.title}</option>
            ))}
          </select>
        </div>
      </div>

      {/* SPECIAL COMPETITION SCENARIO A BANNER */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 text-white shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur border border-white/20 text-xs font-bold text-purple-200">
              <Zap className="w-3.5 h-3.5 text-amber-300" />
              <span>COMPETITION TEST: SCENARIO A</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black">
              Demonstrate Career Goal Change (Full Stack → AI Engineer)
            </h2>
            <p className="text-xs text-purple-100/90 max-w-xl">
              Triggers the autonomous pipeline: Profile → Skill Analysis → Career → Learning Agent.
              Recalculates readiness score, generates Version 3 roadmap, and preserves previous roadmaps!
            </p>
          </div>

          <button
            onClick={handleDemonstrateScenarioA}
            disabled={switching || matchData?.career_title === 'AI Engineer'}
            className={`px-6 py-3.5 rounded-xl font-extrabold text-xs shadow-lg transition-all flex items-center justify-center space-x-2 cursor-pointer shrink-0 ${
              matchData?.career_title === 'AI Engineer'
                ? 'bg-emerald-500/30 text-emerald-200 border border-emerald-400/50 cursor-default'
                : 'bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-900 shadow-amber-500/25'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>
              {switching
                ? 'Executing Multi-Agent Workflow...'
                : matchData?.career_title === 'AI Engineer'
                ? '✓ Switched to AI Engineer'
                : 'Execute Scenario A Now'}
            </span>
          </button>
        </div>

        {scenarioAResult && (
          <div className="mt-5 p-4 rounded-xl bg-white/10 backdrop-blur border border-white/20 text-xs space-y-2 animate-fade-in">
            <div className="flex items-center space-x-2 text-emerald-300 font-bold">
              <CheckCircle2 className="w-4 h-4" />
              <span>Scenario A Workflow Completed Successfully!</span>
            </div>
            <p className="text-purple-100">
              {scenarioAResult.summary || `Transitioned from ${scenarioAResult.from_career} to ${scenarioAResult.to_career}. New Roadmap Version: ${scenarioAResult.roadmap_version}.`}
            </p>
            <div className="p-3 bg-black/20 rounded-lg text-slate-200 text-[11px] font-mono">
              <strong>Mentor Welcome:</strong> {scenarioAResult.mentor_welcome}
            </div>
          </div>
        )}
      </div>

      {/* Main Readiness Gauge & Formula Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Score Card */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Career Readiness Score</span>
            <div className="flex items-baseline space-x-2 mt-2">
              <span className="text-5xl font-black text-slate-900">{matchData?.career_readiness_score || 0}%</span>
              <span className="text-xs text-slate-500 font-semibold">for {matchData?.career_title}</span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-3 mt-4">
              <div
                className="bg-blue-600 h-3 rounded-full transition-all duration-500"
                style={{ width: `${matchData?.career_readiness_score || 0}%` }}
              ></div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100">
            <div className="flex justify-between text-xs text-slate-600">
              <span>Competencies Meeting Spec:</span>
              <span className="font-bold text-emerald-600">{matchData?.meeting_skills?.length || 0}</span>
            </div>
            <div className="flex justify-between text-xs text-slate-600 mt-1">
              <span>Underdeveloped Competencies:</span>
              <span className="font-bold text-amber-600">{matchData?.underdeveloped_skills?.length || 0}</span>
            </div>
            <div className="flex justify-between text-xs text-slate-600 mt-1">
              <span>Missing Competencies:</span>
              <span className="font-bold text-rose-600">{matchData?.missing_skills?.length || 0}</span>
            </div>
          </div>
        </div>

        {/* Formula Transparency Card */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center space-x-2 text-sm font-bold text-slate-900 pb-2 border-b border-slate-100">
            <Info className="w-4 h-4 text-blue-600" />
            <span>Transparent Mathematical Calculation</span>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed">
            SkillPath AI avoids arbitrary percentage generators. Readiness is calculated deterministically by weighting required competencies by industry importance (Critical = 1.5x, High = 1.2x, Medium = 1.0x).
          </p>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs font-mono text-slate-700">
            {matchData?.formula_breakdown}
          </div>

          <div className="grid grid-cols-3 gap-3 text-center text-xs pt-2">
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl">
              <span className="font-bold text-emerald-800 block text-lg">{matchData?.meeting_skills?.length || 0}</span>
              <span className="text-[11px] text-emerald-700 font-semibold">100% Credit</span>
            </div>
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl">
              <span className="font-bold text-amber-800 block text-lg">{matchData?.underdeveloped_skills?.length || 0}</span>
              <span className="text-[11px] text-amber-700 font-semibold">Partial Credit</span>
            </div>
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl">
              <span className="font-bold text-rose-800 block text-lg">{matchData?.missing_skills?.length || 0}</span>
              <span className="text-[11px] text-rose-700 font-semibold">0% Credit</span>
            </div>
          </div>
        </div>
      </div>

      {/* Competency Gap Breakdown Tables */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Missing Skills */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center space-x-2 text-xs font-bold text-rose-700 pb-2 border-b border-rose-100">
            <XCircle className="w-4 h-4" />
            <span>Missing Competencies ({matchData?.missing_skills?.length || 0})</span>
          </div>
          <div className="space-y-2">
            {matchData?.missing_skills && matchData.missing_skills.length > 0 ? (
              matchData.missing_skills.map((s, idx) => (
                <div key={idx} className="p-3 bg-rose-50/50 rounded-xl border border-rose-100 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-slate-900">{s.skill_name}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded font-bold bg-rose-100 text-rose-800">
                      {s.importance}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">Requires: {s.required_proficiency}</p>
                </div>
              ))
            ) : (
              <p className="text-xs text-slate-400">All required skills exist in profile.</p>
            )}
          </div>
        </div>

        {/* Underdeveloped Skills */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center space-x-2 text-xs font-bold text-amber-700 pb-2 border-b border-amber-100">
            <AlertCircle className="w-4 h-4" />
            <span>Underdeveloped ({matchData?.underdeveloped_skills?.length || 0})</span>
          </div>
          <div className="space-y-2">
            {matchData?.underdeveloped_skills && matchData.underdeveloped_skills.length > 0 ? (
              matchData.underdeveloped_skills.map((s, idx) => (
                <div key={idx} className="p-3 bg-amber-50/50 rounded-xl border border-amber-100 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-slate-900">{s.skill_name}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded font-bold bg-amber-100 text-amber-800">
                      {s.importance}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Current: {s.current_proficiency} → Target: {s.required_proficiency}
                  </p>
                </div>
              ))
            ) : (
              <p className="text-xs text-slate-400">No skills currently below required level.</p>
            )}
          </div>
        </div>

        {/* Meeting Skills */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center space-x-2 text-xs font-bold text-emerald-700 pb-2 border-b border-emerald-100">
            <CheckCircle2 className="w-4 h-4" />
            <span>Meets Requirements ({matchData?.meeting_skills?.length || 0})</span>
          </div>
          <div className="space-y-2">
            {matchData?.meeting_skills && matchData.meeting_skills.length > 0 ? (
              matchData.meeting_skills.map((s, idx) => (
                <div key={idx} className="p-3 bg-emerald-50/50 rounded-xl border border-emerald-100 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-slate-900">{s.skill_name}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded font-bold bg-emerald-100 text-emerald-800">
                      Meets
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Verified at {s.current_proficiency} (Required: {s.required_proficiency})
                  </p>
                </div>
              ))
            ) : (
              <p className="text-xs text-slate-400">No matching skills verified yet.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
