import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { CareerRole } from '../types';
import { Briefcase, TrendingUp, DollarSign, ArrowRight, CheckCircle2, Search } from 'lucide-react';

interface CareerExploreViewProps {
  onSelectCareer: (careerId: number) => void;
}

export const CareerExploreView: React.FC<CareerExploreViewProps> = ({ onSelectCareer }) => {
  const [careers, setCareers] = useState<CareerRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  useEffect(() => {
    const fetchCareers = async () => {
      try {
        setLoading(true);
        const data = await api.getAllCareers();
        setCareers(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchCareers();
  }, []);

  if (loading) {
    return <div className="p-8 text-center text-xs text-slate-500">Loading career database...</div>;
  }

  const categories = ['All', ...Array.from(new Set(careers.map(c => c.category)))];

  const filteredCareers = careers.filter(c => {
    const matchesSearch = c.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          c.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCat = selectedCategory === 'All' || c.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">Career Trajectory Exploration</h1>
        <p className="text-xs text-slate-500 mt-1">
          Explore production roles, industry salary benchmarks, market demand projections, and prerequisite technical competencies.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search roles or technologies..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
          />
        </div>

        <div className="flex overflow-x-auto space-x-1.5 w-full sm:w-auto pb-1 sm:pb-0 scrollbar-none">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Career Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCareers.map((career) => (
          <div
            key={career.id}
            className="p-6 rounded-2xl bg-white border border-slate-200 hover:border-blue-400 hover:shadow-lg transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-[10px] font-bold text-blue-700 bg-blue-50 border border-blue-200/60 px-2 py-0.5 rounded">
                  {career.category}
                </span>
                <span className="text-[11px] text-emerald-600 font-semibold flex items-center">
                  <TrendingUp className="w-3.5 h-3.5 mr-1" />
                  {career.growth_rate}
                </span>
              </div>

              <h3 className="text-lg font-bold text-slate-900">{career.title}</h3>
              <p className="text-xs text-slate-600 mt-2 line-clamp-3 leading-relaxed">
                {career.description}
              </p>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-700">
                <span className="font-semibold text-slate-500">Average Compensation:</span>
                <span className="font-bold text-slate-900">{career.average_salary}</span>
              </div>

              {/* Required Skills tags */}
              <div className="mt-4 space-y-1.5">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                  Core Requirements ({career.requirements?.length || 0})
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {career.requirements?.slice(0, 5).map((req, ri) => (
                    <span
                      key={ri}
                      className={`text-[10px] px-2 py-0.5 rounded font-semibold ${
                        req.importance === 'Critical'
                          ? 'bg-rose-50 text-rose-700 border border-rose-200/60'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {req.skill_name}
                    </span>
                  ))}
                  {career.requirements && career.requirements.length > 5 && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-500 font-semibold">
                      +{career.requirements.length - 5} more
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100">
              <button
                onClick={() => onSelectCareer(career.id)}
                className="w-full py-2 px-4 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center space-x-1.5 transition-all cursor-pointer"
              >
                <span>Match My Skills & Gap Analysis</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
