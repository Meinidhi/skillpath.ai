import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { LearnerSkill, Skill } from '../types';
import {
  ShieldAlert, ShieldCheck, CheckCircle2, AlertCircle,
  BarChart2, Award, Zap, Plus, RefreshCw, ArrowUpRight
} from 'lucide-react';

interface SkillAnalysisViewProps {
  onNavigate: (tab: string) => void;
}

export const SkillAnalysisView: React.FC<SkillAnalysisViewProps> = ({ onNavigate }) => {
  const [analysis, setAnalysis] = useState<any>(null);
  const [mySkills, setMySkills] = useState<LearnerSkill[]>([]);
  const [allSkills, setAllSkills] = useState<Skill[]>([]);
  const [loading, setLoading] = useState(true);

  // Quick skill add state
  const [selectedSkillName, setSelectedSkillName] = useState('');
  const [selectedLevel, setSelectedLevel] = useState('Beginner');
  const [adding, setAdding] = useState(false);

  const loadData = async () => {
    try {
      setLoading(true);
      const [anaData, myData, allData] = await Promise.all([
        api.getSkillAnalysis(),
        api.getMySkills(),
        api.getAllSkills()
      ]);
      setAnalysis(anaData);
      setMySkills(myData);
      setAllSkills(allData);
      if (allData.length > 0) setSelectedSkillName(allData[0].name);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleAddSkill = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSkillName) return;
    setAdding(true);
    try {
      await api.batchUpdateSkills([
        {
          skill_name: selectedSkillName,
          proficiency_level: selectedLevel,
          evidence_source: 'Self-Declared'
        }
      ]);
      await loadData();
    } catch (err) {
      console.error(err);
    } finally {
      setAdding(false);
    }
  };

  if (loading) {
    return <div className="p-8 text-center text-xs text-slate-500">Analyzing skills against empirical evidence...</div>;
  }

  const distribution = analysis?.skill_distribution || { Beginner: 0, Intermediate: 0, Advanced: 0, Expert: 0 };
  const coverage = analysis?.category_coverage || {};

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">Skill Analysis Dashboard</h1>
          <p className="text-xs text-slate-500 mt-1">
            Empirical evidence calibration by the Skill Analysis Agent. Self-declarations are weighted lower until validated via assessments.
          </p>
        </div>
        <button
          onClick={loadData}
          className="inline-flex items-center space-x-1.5 px-3.5 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 shadow-sm"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Analysis</span>
        </button>
      </div>

      {/* Top 3 Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Overall Proficiency Tier</span>
          <div className="text-2xl font-extrabold text-blue-600 mt-2">{analysis?.overall_proficiency || 'Intermediate'}</div>
          <p className="text-xs text-slate-500 mt-1">
            Weighted across {analysis?.total_skills_recorded || 0} recorded competencies.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Average Evidence Confidence</span>
          <div className="text-2xl font-extrabold text-slate-900 mt-2">
            {Math.round((analysis?.average_confidence || 0.45) * 100)}%
          </div>
          <div className="w-full bg-slate-100 rounded-full h-2 mt-2">
            <div
              className="bg-emerald-500 h-2 rounded-full transition-all"
              style={{ width: `${Math.round((analysis?.average_confidence || 0.45) * 100)}%` }}
            ></div>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Assessments elevate confidence from 35% up to 95%.</p>
        </div>

        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Proficiency Breakdown</span>
          <div className="grid grid-cols-4 gap-2 mt-2 text-center">
            <div className="p-2 bg-slate-50 rounded-lg">
              <span className="text-[10px] text-slate-500 block font-semibold">Beg</span>
              <span className="text-base font-bold text-slate-800">{distribution.Beginner}</span>
            </div>
            <div className="p-2 bg-blue-50 rounded-lg">
              <span className="text-[10px] text-blue-600 block font-semibold">Int</span>
              <span className="text-base font-bold text-blue-800">{distribution.Intermediate}</span>
            </div>
            <div className="p-2 bg-indigo-50 rounded-lg">
              <span className="text-[10px] text-indigo-600 block font-semibold">Adv</span>
              <span className="text-base font-bold text-indigo-800">{distribution.Advanced}</span>
            </div>
            <div className="p-2 bg-purple-50 rounded-lg">
              <span className="text-[10px] text-purple-600 block font-semibold">Exp</span>
              <span className="text-base font-bold text-purple-800">{distribution.Expert}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Strengths vs Growth Areas */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center space-x-2 text-sm font-bold text-slate-900 pb-2 border-b border-slate-100">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            <span>Validated Strengths ({analysis?.strengths?.length || 0})</span>
          </div>
          <div className="space-y-2.5">
            {analysis?.strengths && analysis.strengths.length > 0 ? (
              analysis.strengths.map((s: any, idx: number) => (
                <div key={idx} className="p-3 bg-emerald-50/50 rounded-xl border border-emerald-100 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-xs text-slate-900">{s.skill_name}</span>
                    <span className="text-[10px] text-emerald-700 bg-emerald-100 font-semibold px-2 py-0.5 rounded ml-2">
                      {s.proficiency_level}
                    </span>
                    <p className="text-[10px] text-slate-500 mt-0.5">{s.evidence_source}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold text-emerald-700">{Math.round(s.confidence_level * 100)}%</span>
                    <span className="block text-[10px] text-slate-400">Confidence</span>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-xs text-slate-400">Take assessments to establish verified strengths.</p>
            )}
          </div>
        </div>

        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center space-x-2 text-sm font-bold text-slate-900 pb-2 border-b border-slate-100">
            <ShieldAlert className="w-5 h-5 text-amber-600" />
            <span>Identified Growth Areas ({analysis?.weaknesses?.length || 0})</span>
          </div>
          <div className="space-y-2.5">
            {analysis?.weaknesses && analysis.weaknesses.length > 0 ? (
              analysis.weaknesses.map((s: any, idx: number) => (
                <div key={idx} className="p-3 bg-amber-50/40 rounded-xl border border-amber-100 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-xs text-slate-900">{s.skill_name}</span>
                    <span className="text-[10px] text-amber-700 bg-amber-100 font-semibold px-2 py-0.5 rounded ml-2">
                      {s.proficiency_level}
                    </span>
                    <p className="text-[10px] text-slate-500 mt-0.5">{s.evidence_source}</p>
                  </div>
                  <button
                    onClick={() => onNavigate('assessments')}
                    className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center space-x-0.5"
                  >
                    <span>Verify</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            ) : (
              <p className="text-xs text-slate-400">No weak competencies identified.</p>
            )}
          </div>
        </div>
      </div>

      {/* Category Coverage Bars */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm">
        <h3 className="text-sm font-bold text-slate-900 mb-4">Competency Domain Coverage</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Object.entries(coverage).map(([cat, pct]: any) => (
            <div key={cat} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex justify-between text-xs font-bold text-slate-800 mb-1.5">
                <span>{cat}</span>
                <span>{pct}%</span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full"
                  style={{ width: `${pct}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* All Recorded Skills Table & Quick Add Form */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Recorded Skills Inventory</h3>
            <p className="text-xs text-slate-500">Every recorded skill is tracked with its evidence source and confidence metric.</p>
          </div>

          {/* Quick Add Form */}
          <form onSubmit={handleAddSkill} className="flex flex-wrap items-center gap-2">
            <select
              value={selectedSkillName}
              onChange={(e) => setSelectedSkillName(e.target.value)}
              className="px-3 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
            >
              {allSkills.map(s => (
                <option key={s.id} value={s.name}>{s.name} ({s.category})</option>
              ))}
            </select>
            <select
              value={selectedLevel}
              onChange={(e) => setSelectedLevel(e.target.value)}
              className="px-3 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
            >
              <option value="Beginner">Beginner</option>
              <option value="Intermediate">Intermediate</option>
              <option value="Advanced">Advanced</option>
              <option value="Expert">Expert</option>
            </select>
            <button
              type="submit"
              disabled={adding}
              className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center space-x-1 shadow-sm cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{adding ? 'Adding...' : 'Declare Skill'}</span>
            </button>
          </form>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">Skill Name</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3">Proficiency Level</th>
                <th className="py-2.5 px-3">Evidence Source</th>
                <th className="py-2.5 px-3">Confidence Rating</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {mySkills.map((ls) => (
                <tr key={ls.id} className="hover:bg-slate-50/60">
                  <td className="py-3 px-3 font-bold text-slate-900">{ls.skill_name}</td>
                  <td className="py-3 px-3 text-slate-500">{ls.category}</td>
                  <td className="py-3 px-3">
                    <span className={`px-2 py-0.5 rounded font-semibold text-[10px] ${
                      ls.proficiency_level === 'Advanced' || ls.proficiency_level === 'Expert'
                        ? 'bg-purple-100 text-purple-800'
                        : ls.proficiency_level === 'Intermediate'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-slate-100 text-slate-700'
                    }`}>
                      {ls.proficiency_level}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-600">{ls.evidence_source}</td>
                  <td className="py-3 px-3">
                    <div className="flex items-center space-x-2">
                      <div className="w-16 bg-slate-200 rounded-full h-1.5">
                        <div
                          className="bg-blue-600 h-1.5 rounded-full"
                          style={{ width: `${Math.round(ls.confidence_level * 100)}%` }}
                        ></div>
                      </div>
                      <span className="text-[11px] font-bold text-slate-700">{Math.round(ls.confidence_level * 100)}%</span>
                    </div>
                  </td>
                  <td className="py-3 px-3 text-right">
                    <button
                      onClick={() => onNavigate('assessments')}
                      className="text-blue-600 hover:text-blue-800 font-semibold"
                    >
                      Test Skill
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
