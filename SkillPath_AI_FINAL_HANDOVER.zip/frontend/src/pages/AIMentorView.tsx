import React, { useState, useEffect, useRef } from 'react';
import { api } from '../services/api';
import { MentorMessage } from '../types';
import { Bot, User, Send, Sparkles, Compass, CheckCircle2 } from 'lucide-react';

export const AIMentorView: React.FC = () => {
  const [messages, setMessages] = useState<MentorMessage[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const fetchHistory = async () => {
    try {
      setLoading(true);
      const history = await api.getMentorHistory();
      setMessages(history);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (textToSend?: string) => {
    const text = textToSend || input;
    if (!text.trim() || sending) return;

    // Optimistic user message
    const tempUserMsg: MentorMessage = {
      id: Date.now(),
      message: text,
      sender: 'user',
      context_metadata: {},
      timestamp: new Date().toISOString()
    };
    setMessages(prev => [...prev, tempUserMsg]);
    setInput('');
    setSending(true);

    try {
      const mentorReply = await api.sendMentorMessage(text);
      setMessages(prev => [...prev, mentorReply]);
    } catch (err) {
      console.error(err);
    } finally {
      setSending(false);
    }
  };

  const quickPrompts = [
    "How ready am I for my target career?",
    "What should I learn next from my roadmap?",
    "How did I do on my recent assessment?",
    "What changes if I switch my goal to AI Engineer?"
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Mentor Header */}
      <div className="flex items-center space-x-3 pb-4 border-b border-slate-200">
        <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
          <Bot className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-xl font-extrabold text-slate-900">AI Career Mentor</h1>
          <p className="text-xs text-slate-500">
            Autonomous Agent 6 • Synchronized with your profile, verified competencies, and active roadmap.
          </p>
        </div>
      </div>

      {/* Quick Prompts Pills */}
      <div className="flex overflow-x-auto space-x-2 py-1 scrollbar-none">
        {quickPrompts.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(prompt)}
            disabled={sending}
            className="px-3 py-1.5 rounded-full bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-semibold border border-blue-200/80 whitespace-nowrap transition-all cursor-pointer flex items-center space-x-1"
          >
            <Sparkles className="w-3 h-3 text-blue-500" />
            <span>{prompt}</span>
          </button>
        ))}
      </div>

      {/* Chat Messages Box */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 sm:p-6 min-h-[450px] max-h-[550px] overflow-y-auto space-y-4">
        {messages.length === 0 && !loading && (
          <div className="text-center py-16 text-slate-400 space-y-2">
            <Compass className="w-10 h-10 mx-auto text-slate-300" />
            <p className="text-xs">No conversation history yet. Ask a question or click a suggestion above!</p>
          </div>
        )}

        {messages.map((m) => {
          const isUser = m.sender === 'user';
          return (
            <div
              key={m.id}
              className={`flex items-start space-x-3 ${isUser ? 'flex-row-reverse space-x-reverse' : ''}`}
            >
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                isUser ? 'bg-slate-900 text-white' : 'bg-blue-100 text-blue-700'
              }`}>
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed ${
                isUser
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-slate-50 border border-slate-200 text-slate-800'
              }`}>
                <div className="whitespace-pre-line font-medium">
                  {m.message}
                </div>
                <span className={`block text-[10px] mt-1.5 ${isUser ? 'text-blue-200' : 'text-slate-400'}`}>
                  {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
          );
        })}

        {sending && (
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
              <Bot className="w-4 h-4 animate-spin" />
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-500">
              Consulting multi-agent telemetry...
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Box */}
      <form onSubmit={(e) => { e.preventDefault(); handleSend(); }} className="flex items-center space-x-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask anything about your readiness, next learning steps, or career transitions..."
          className="flex-1 px-4 py-3 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white shadow-sm"
        />
        <button
          type="submit"
          disabled={sending || !input.trim()}
          className="p-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-500/20 transition-all cursor-pointer disabled:opacity-50"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
