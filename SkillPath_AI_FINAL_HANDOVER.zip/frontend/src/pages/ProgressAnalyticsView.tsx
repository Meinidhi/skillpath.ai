import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { ProgressOverview } from '../types';
import {
  TrendingUp, Award, CheckCircle, BarChart3, Activity,
  Target, PieChart as PieIcon, RefreshCw
} from 'lucide-react';
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer,
  BarChart, Bar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend
} from 'recharts';

export const ProgressAnalyticsView: React.FC = () => {
  const [data, setData] = useState<ProgressOverview | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProgress = async () => {
    try {
      setLoading(true);
      const res = await api.getProgressOverview();
      setData(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProgress();
  }, []);

  if (loading && !data) {
    return <div className="p-8 text-center text-xs text-slate-500">Calculating real-time telemetry metrics...</div>;
  }

  const radarData = data?.skill_radar_data || [];
  const trendData = data?.history_trend || [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">Learning Analytics & Telemetry</h1>
          <p className="text-xs text-slate-500 mt-1">
            Empirical progress computed directly from stored roadmap milestones, assessment scores, and verified skills.
          </p>
        </div>
        <button
          onClick={fetchProgress}
          className="inline-flex items-center space-x-1.5 px-3.5 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 shadow-sm"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Analytics</span>
        </button>
      </div>

      {/* Top Key Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-500">Career Readiness</span>
          <div className="text-3xl font-black text-slate-900 mt-1">{data?.career_readiness_score || 0}%</div>
          <span className="text-[11px] text-blue-600 font-semibold">{data?.target_career}</span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-500">Overall Progress Index</span>
          <div className="text-3xl font-black text-emerald-600 mt-1">{data?.overall_progress_pct || 0}%</div>
          <span className="text-[11px] text-slate-400">Weighted composite</span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-500">Roadmap Completion</span>
          <div className="text-3xl font-black text-indigo-600 mt-1">{data?.roadmap_completion_pct || 0}%</div>
          <span className="text-[11px] text-slate-400">{data?.active_tasks_count || 0} active milestones</span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-500">Diagnostic Pass Rate</span>
          <div className="text-3xl font-black text-purple-600 mt-1">{data?.average_assessment_score || 0}%</div>
          <span className="text-[11px] text-slate-400">{data?.assessments_completed_count || 0} attempts verified</span>
        </div>
      </div>

      {/* Recharts Visualizations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Career Readiness Growth Trajectory */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center space-x-2 text-sm font-bold text-slate-900 pb-2 border-b border-slate-100">
            <TrendingUp className="w-4 h-4 text-blue-600" />
            <span>Readiness Trajectory Timeline</span>
          </div>

          <div className="h-72 w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trendData}>
                <XAxis dataKey="milestone" stroke="#94a3b8" fontSize={11} />
                <YAxis domain={[0, 100]} stroke="#94a3b8" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', border: 'none', color: '#fff', fontSize: '12px' }}
                />
                <Line
                  type="monotone"
                  dataKey="readiness"
                  stroke="#2563eb"
                  strokeWidth={3}
                  dot={{ r: 5, fill: '#2563eb' }}
                  activeDot={{ r: 7 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Competency Domain Coverage (Radar or Bar) */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center space-x-2 text-sm font-bold text-slate-900 pb-2 border-b border-slate-100">
            <BarChart3 className="w-4 h-4 text-indigo-600" />
            <span>Competency Domain Proficiency</span>
          </div>

          <div className="h-72 w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={radarData}>
                <XAxis dataKey="category" stroke="#94a3b8" fontSize={10} interval={0} angle={-15} textAnchor="end" />
                <YAxis domain={[0, 100]} stroke="#94a3b8" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', border: 'none', color: '#fff', fontSize: '12px' }}
                />
                <Bar dataKey="current" fill="#4f46e5" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
