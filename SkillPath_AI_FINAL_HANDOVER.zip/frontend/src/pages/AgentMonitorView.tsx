import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { AgentExecution } from '../types';
import {
  Activity, CheckCircle2, Clock, Play, RefreshCw,
  Cpu, Shield, Sparkles, AlertCircle, FileText
} from 'lucide-react';

export const AgentMonitorView: React.FC = () => {
  const [agents, setAgents] = useState<any[]>([]);
  const [executions, setExecutions] = useState<AgentExecution[]>([]);
  const [loading, setLoading] = useState(true);
  const [runningWorkflow, setRunningWorkflow] = useState(false);
  const [workflowMsg, setWorkflowMsg] = useState<string | null>(null);

  const loadData = async () => {
    try {
      setLoading(true);
      const [agentList, execList] = await Promise.all([
        api.getAgentsStatus(),
        api.getAgentExecutions(50)
      ]);
      setAgents(agentList);
      setExecutions(execList);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleTriggerWorkflow = async () => {
    setRunningWorkflow(true);
    setWorkflowMsg(null);
    try {
      const res = await api.triggerAgentWorkflow();
      setWorkflowMsg(res.summary || 'Full 6-agent analysis pipeline executed successfully!');
      await loadData();
    } catch (err: any) {
      console.error(err);
    } finally {
      setRunningWorkflow(false);
    }
  };

  if (loading && agents.length === 0) {
    return <div className="p-8 text-center text-xs text-slate-500">Connecting to autonomous agent orchestrator...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl font-extrabold text-slate-900">Agent Activity & Telemetry Monitor</h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
              6 Agents Active
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Real-time telemetry and execution logs from SkillPath AI's centralized orchestrator and Python agent modules.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={loadData}
            className="inline-flex items-center space-x-1.5 px-3.5 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 shadow-sm cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh Telemetry</span>
          </button>
          <button
            onClick={handleTriggerWorkflow}
            disabled={runningWorkflow}
            className="inline-flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-500/20 transition-all cursor-pointer"
          >
            <Play className="w-3.5 h-3.5" />
            <span>{runningWorkflow ? 'Executing Pipeline...' : 'Run Full Workflow'}</span>
          </button>
        </div>
      </div>

      {workflowMsg && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center space-x-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
          <span>{workflowMsg}</span>
        </div>
      )}

      {/* 6 Specialized Agents Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {agents.map((ag) => (
          <div
            key={ag.id}
            className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-[10px] font-bold text-blue-700 bg-blue-50 border border-blue-200/60 px-2 py-0.5 rounded">
                  {ag.role}
                </span>
                <span className="flex items-center text-[10px] font-bold text-emerald-600">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 mr-1.5 animate-pulse"></span>
                  READY
                </span>
              </div>

              <h3 className="text-base font-bold text-slate-900">{ag.name}</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">{ag.responsibility}</p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>{ag.engine}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Historical Execution Log Table */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Orchestrator Execution Ledger</h3>
            <p className="text-xs text-slate-500">Persisted execution audit trail stored in SQLite.</p>
          </div>
          <span className="text-xs text-slate-400 font-semibold">{executions.length} Logs Persisted</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">Agent</th>
                <th className="py-2.5 px-3">Workflow ID</th>
                <th className="py-2.5 px-3">Input Context Summary</th>
                <th className="py-2.5 px-3">Output Result Summary</th>
                <th className="py-2.5 px-3">Duration</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {executions.map((ex) => (
                <tr key={ex.id} className="hover:bg-slate-50/60 font-mono">
                  <td className="py-3 px-3 font-sans font-bold text-slate-900 whitespace-nowrap">
                    {ex.agent_name}
                  </td>
                  <td className="py-3 px-3 text-slate-400 text-[11px]">{ex.workflow_id}</td>
                  <td className="py-3 px-3 font-sans text-slate-600 max-w-xs truncate" title={ex.input_summary}>
                    {ex.input_summary || 'Context ingested'}
                  </td>
                  <td className="py-3 px-3 font-sans text-slate-800 max-w-sm truncate" title={ex.output_summary}>
                    {ex.output_summary}
                  </td>
                  <td className="py-3 px-3 text-slate-500">{ex.execution_time_ms} ms</td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded font-sans font-bold text-[10px] bg-emerald-100 text-emerald-800">
                      {ex.status}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right text-slate-400 text-[11px]">
                    {new Date(ex.timestamp).toLocaleTimeString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
