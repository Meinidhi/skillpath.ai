import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Settings, ShieldCheck, Database, Cpu, ExternalLink, RefreshCw } from 'lucide-react';
import { api } from '../services/api';

export const SettingsView: React.FC = () => {
  const { user, demoLogin } = useAuth();

  const handleResetDemo = async () => {
    await demoLogin();
    window.location.reload();
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">System Architecture & Settings</h1>
        <p className="text-xs text-slate-500 mt-1">
          Technical specifications adhering strictly to Claude's Engineering Blueprint.
        </p>
      </div>

      {/* Blueprint Conformance Card */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center space-x-2 text-sm font-bold text-slate-900 pb-2 border-b border-slate-100">
          <ShieldCheck className="w-5 h-5 text-emerald-600" />
          <span>Technical Architecture Conformance</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <span className="font-bold text-slate-900 block mb-1">Frontend Stack</span>
            <p className="text-slate-600">React 18 + TypeScript + Vite + Tailwind CSS + Lucide Icons + Recharts.</p>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <span className="font-bold text-slate-900 block mb-1">Backend Stack</span>
            <p className="text-slate-600">FastAPI + SQLAlchemy 2.0 (Synchronous operations) + Pydantic v2.</p>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <span className="font-bold text-slate-900 block mb-1">Database & Persistence</span>
            <p className="text-slate-600">SQLite local zero-config database with relational models and automatic schema initialization.</p>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <span className="font-bold text-slate-900 block mb-1">Security & Authentication</span>
            <p className="text-slate-600">PyJWT token authentication + hashlib.pbkdf2_hmac sha256 password salting.</p>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <span className="font-bold text-slate-900 block mb-1">Autonomous AI Intelligence</span>
            <p className="text-slate-600">Six specialized Python agent classes under <code>backend/agents/</code> orchestrated by <code>CustomOrchestrator</code> using <code>RuleBasedProvider</code>.</p>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <span className="font-bold text-slate-900 block mb-1">Adaptive Engine</span>
            <p className="text-slate-600">Full end-to-end implementation of Scenario A (Career Goal Transition) and Scenario B (Assessment Deficit Remediation).</p>
          </div>
        </div>
      </div>

      {/* Demo Account Controls */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
        <h3 className="text-sm font-bold text-slate-900">Competition Evaluation Tools</h3>
        <p className="text-xs text-slate-600">
          Reset session state or inspect API Swagger documentation.
        </p>

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={handleResetDemo}
            className="px-4 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs flex items-center space-x-1.5 border border-blue-200 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset Demo Account Session</span>
          </button>

          <a
            href="http://127.0.0.1:8000/docs"
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center space-x-1.5 shadow cursor-pointer"
          >
            <span>Open FastAPI Swagger Documentation</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </div>
  );
};
