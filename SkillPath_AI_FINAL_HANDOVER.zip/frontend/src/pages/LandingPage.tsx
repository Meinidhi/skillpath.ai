import React from 'react';
import { Compass, Sparkles, ArrowRight, ShieldCheck, Zap, Layers, Target, CheckCircle2, TrendingUp } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface LandingPageProps {
  onStart: () => void;
  onOpenAuth: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onStart, onOpenAuth }) => {
  const { demoLogin } = useAuth();

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-semibold mb-8 animate-fade-in shadow-sm">
            <Sparkles className="w-4 h-4 text-blue-600" />
            <span>Multi-Agent Career Architecture for PromptWars X RTC</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-slate-900 max-w-4xl mx-auto leading-tight">
            Stop guessing your learning path. <br />
            <span className="bg-gradient-to-r from-blue-600 via-indigo-600 to-sky-500 bg-clip-text text-transparent">
              Architect your career with autonomous agents.
            </span>
          </h1>

          <p className="mt-6 text-lg sm:text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed">
            SkillPath AI calibrates your existing skills with empirical assessments, matches you against real market careers, and dynamically adapts your roadmap when your goals or performance change.
          </p>

          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={async () => {
                await demoLogin();
                onStart();
              }}
              className="w-full sm:w-auto px-8 py-4 rounded-xl text-base font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-500/25 transition-all flex items-center justify-center space-x-2 cursor-pointer"
            >
              <span>Explore Demo as Alex Chen</span>
              <ArrowRight className="w-5 h-5" />
            </button>
            <button
              onClick={onOpenAuth}
              className="w-full sm:w-auto px-8 py-4 rounded-xl text-base font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 shadow-sm transition-all"
            >
              Create Account / Sign In
            </button>
          </div>

          <div className="mt-8 flex items-center justify-center space-x-6 text-xs text-slate-500 font-medium">
            <span className="flex items-center"><CheckCircle2 className="w-4 h-4 text-emerald-500 mr-1.5" /> 100% Local Intelligence</span>
            <span className="flex items-center"><CheckCircle2 className="w-4 h-4 text-emerald-500 mr-1.5" /> Zero External LLM APIs</span>
            <span className="flex items-center"><CheckCircle2 className="w-4 h-4 text-emerald-500 mr-1.5" /> 6 Real Specialized Python Agents</span>
          </div>
        </div>
      </section>

      {/* 6 Specialized Agents Showcase */}
      <section className="py-16 bg-white border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">
              Six Specialized Python Agents Working as One
            </h2>
            <p className="mt-3 text-slate-600 text-sm sm:text-base">
              A centralized orchestrator sequences structured context across specialized agents executing verifiable algorithms.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                name: "Profile Agent",
                role: "Normalization & Completeness",
                desc: "Ingests education, declared skills, projects, and learning style to construct a structured LearnerContext.",
                tag: "Agent 1"
              },
              {
                name: "Skill Analysis Agent",
                role: "Evidence Calibration",
                desc: "Weights self-declared skills against empirical assessment scores to assign grounded confidence ratings.",
                tag: "Agent 2"
              },
              {
                name: "Career Agent",
                role: "Competency Matching",
                desc: "Computes a transparent Career Readiness Score and categorizes skills into Meets, Underdeveloped, and Missing.",
                tag: "Agent 3"
              },
              {
                name: "Learning Agent",
                role: "Curriculum Sequencing",
                desc: "Arranges prerequisite skills into sequenced roadmap versions, matching hands-on exercises and real vetted links.",
                tag: "Agent 4"
              },
              {
                name: "Progress Agent",
                role: "Adaptive Interventions",
                desc: "Monitors test results, flags concept deficits (<65%), and triggers roadmap revisions with targeted practice.",
                tag: "Agent 5"
              },
              {
                name: "AI Mentor Agent",
                role: "Contextual Guidance",
                desc: "Answers questions grounded in real stored telemetry, explains skill gaps, and welcomes career transitions.",
                tag: "Agent 6"
              }
            ].map((agent, i) => (
              <div key={i} className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-blue-300 hover:shadow-md transition-all">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold text-blue-600 bg-blue-100/70 px-2.5 py-1 rounded-full">{agent.tag}</span>
                  <span className="text-[11px] text-slate-400 font-mono">Python Module</span>
                </div>
                <h3 className="text-lg font-bold text-slate-900">{agent.name}</h3>
                <p className="text-xs font-semibold text-slate-500 mb-2">{agent.role}</p>
                <p className="text-xs text-slate-600 leading-relaxed">{agent.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Two Mandatory Adaptive Scenarios */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">
              Live Adaptive Engine Scenarios
            </h2>
            <p className="mt-3 text-slate-600 text-sm">
              Tested and verified in real-time with versioned roadmap persistence.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="p-8 rounded-2xl bg-white border border-slate-200 shadow-sm">
              <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center font-bold mb-4">
                A
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Scenario A: Career Goal Transition</h3>
              <p className="text-sm text-slate-600 mb-4 leading-relaxed">
                When Alex Chen changes their career goal from <strong>Full Stack Developer</strong> to <strong>AI Engineer</strong>:
              </p>
              <ul className="text-xs text-slate-600 space-y-2 mb-6">
                <li className="flex items-start"><CheckCircle2 className="w-4 h-4 text-emerald-500 mr-2 shrink-0 mt-0.5" /> Recalculates readiness score against new requirements</li>
                <li className="flex items-start"><CheckCircle2 className="w-4 h-4 text-emerald-500 mr-2 shrink-0 mt-0.5" /> Identifies newly missing competencies (Deep Learning, PyTorch)</li>
                <li className="flex items-start"><CheckCircle2 className="w-4 h-4 text-emerald-500 mr-2 shrink-0 mt-0.5" /> Generates new roadmap version while preserving version history</li>
                <li className="flex items-start"><CheckCircle2 className="w-4 h-4 text-emerald-500 mr-2 shrink-0 mt-0.5" /> AI Mentor delivers personalized transition welcome</li>
              </ul>
              <div className="p-3 bg-purple-50 rounded-lg border border-purple-200 text-xs text-purple-800 font-medium">
                ⚡ Demonstrated in 1-Click on Career Match Page
              </div>
            </div>

            <div className="p-8 rounded-2xl bg-white border border-slate-200 shadow-sm">
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold mb-4">
                B
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Scenario B: Poor Assessment Adaptation</h3>
              <p className="text-sm text-slate-600 mb-4 leading-relaxed">
                When a learner performs poorly on the <strong>JavaScript Assessment (20% score)</strong>:
              </p>
              <ul className="text-xs text-slate-600 space-y-2 mb-6">
                <li className="flex items-start"><CheckCircle2 className="w-4 h-4 text-amber-500 mr-2 shrink-0 mt-0.5" /> Progress Agent detects deficit and isolates weak concepts (Closures, Event Loop)</li>
                <li className="flex items-start"><CheckCircle2 className="w-4 h-4 text-amber-500 mr-2 shrink-0 mt-0.5" /> Calibrates skill confidence and flags under-proficiency</li>
                <li className="flex items-start"><CheckCircle2 className="w-4 h-4 text-amber-500 mr-2 shrink-0 mt-0.5" /> Injects high-priority remedial tasks into roadmap Version 2</li>
                <li className="flex items-start"><CheckCircle2 className="w-4 h-4 text-amber-500 mr-2 shrink-0 mt-0.5" /> AI Mentor provides encouraging, targeted diagnostic feedback</li>
              </ul>
              <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 text-xs text-amber-800 font-medium">
                ⚡ Demonstrated in 1-Click on Assessment Page
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
