import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { LearningRoadmap, RoadmapVersion, RoadmapItem } from '../types';
import {
  Map, CheckCircle, Clock, AlertTriangle, ExternalLink,
  History, Sparkles, ArrowRight, BookOpen, Code2, RefreshCw
} from 'lucide-react';

export const RoadmapView: React.FC = () => {
  const [roadmap, setRoadmap] = useState<LearningRoadmap | null>(null);
  const [selectedVersion, setSelectedVersion] = useState<RoadmapVersion | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchRoadmap = async () => {
    try {
      setLoading(true);
      const data = await api.getCurrentRoadmap();
      setRoadmap(data);
      if (data.versions && data.versions.length > 0) {
        setSelectedVersion(data.versions[0]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRoadmap();
  }, []);

  const handleStatusChange = async (itemId: number, newStatus: string) => {
    try {
      await api.updateItemStatus(itemId, newStatus);
      // Update local state smoothly
      if (selectedVersion) {
        const updatedItems = selectedVersion.items.map(item =>
          item.id === itemId ? { ...item, status: newStatus as any } : item
        );
        setSelectedVersion({ ...selectedVersion, items: updatedItems });
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (loading && !roadmap) {
    return <div className="p-8 text-center text-xs text-slate-500">Synthesizing personalized curriculum...</div>;
  }

  const items = selectedVersion?.items || [];
  const completedCount = items.filter(i => i.status === 'completed').length;
  const progressPct = items.length > 0 ? Math.round((completedCount / items.length) * 100) : 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl font-extrabold text-slate-900">Personalized Learning Roadmap</h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full font-bold bg-blue-100 text-blue-800 border border-blue-200">
              v{selectedVersion?.version_number || 1}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Sequenced specifically for <strong>{roadmap?.career_title}</strong> based on missing prerequisites and validated competencies.
          </p>
        </div>

        {/* Version History Selector */}
        <div className="flex items-center space-x-3 bg-white p-2 rounded-2xl border border-slate-200 shadow-sm">
          <History className="w-4 h-4 text-slate-400 ml-2" />
          <span className="text-xs font-semibold text-slate-600">Roadmap Version:</span>
          <select
            value={selectedVersion?.version_number || 1}
            onChange={(e) => {
              const vNum = Number(e.target.value);
              const found = roadmap?.versions.find(v => v.version_number === vNum);
              if (found) setSelectedVersion(found);
            }}
            className="px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-bold bg-slate-50 focus:ring-2 focus:ring-blue-500 focus:outline-none"
          >
            {roadmap?.versions.map((v) => (
              <option key={v.id} value={v.version_number}>
                Version {v.version_number} ({v.change_trigger})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Version Change Details Banner */}
      {selectedVersion && (
        <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200/80 text-xs space-y-1">
          <div className="flex items-center justify-between">
            <span className="font-bold text-blue-900">
              Trigger: {selectedVersion.change_trigger}
            </span>
            <span className="text-[11px] text-blue-600 font-medium">
              Created: {new Date(selectedVersion.created_at).toLocaleDateString()}
            </span>
          </div>
          <p className="text-blue-800 leading-relaxed">
            {selectedVersion.change_reason || selectedVersion.summary || 'Initial personalized roadmap synthesis.'}
          </p>
        </div>
      )}

      {/* Progress Metric Bar */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
        <div className="flex justify-between items-center text-xs font-bold text-slate-700">
          <span>Curriculum Mastery Progress</span>
          <span>{completedCount} of {items.length} Modules Completed ({progressPct}%)</span>
        </div>
        <div className="w-full bg-slate-100 rounded-full h-3">
          <div
            className="bg-emerald-500 h-3 rounded-full transition-all duration-500"
            style={{ width: `${progressPct}%` }}
          ></div>
        </div>
      </div>

      {/* Interactive Roadmap Timeline */}
      <div className="space-y-4">
        {items.map((item, index) => {
          const isCompleted = item.status === 'completed';
          const isRevision = item.status === 'needs_revision';
          const isInProgress = item.status === 'in_progress';

          return (
            <div
              key={item.id}
              className={`p-6 rounded-2xl border transition-all ${
                isCompleted
                  ? 'bg-slate-50/80 border-slate-200 opacity-90'
                  : isRevision
                  ? 'bg-amber-50/60 border-amber-300 shadow-sm'
                  : 'bg-white border-slate-200 shadow-sm hover:border-blue-300'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                <div className="flex items-start space-x-4">
                  {/* Step Order Badge */}
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                    isCompleted
                      ? 'bg-emerald-100 text-emerald-700'
                      : isRevision
                      ? 'bg-amber-200 text-amber-900'
                      : 'bg-blue-100 text-blue-700'
                  }`}>
                    {isCompleted ? <CheckCircle className="w-5 h-5 text-emerald-600" /> : index + 1}
                  </div>

                  <div className="space-y-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className={`text-base font-bold ${isCompleted ? 'text-slate-500 line-through' : 'text-slate-900'}`}>
                        {item.title}
                      </h3>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        item.priority === 'Critical' ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {item.priority} Priority
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                        {item.difficulty} Level
                      </span>
                      {isRevision && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-200 text-amber-900 flex items-center">
                          <AlertTriangle className="w-3 h-3 mr-1" />
                          Remedial Diagnostic Task
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed">
                      {item.learning_objective}
                    </p>

                    {item.practical_exercise && (
                      <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-800 flex items-start space-x-2">
                        <Code2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-bold text-slate-900">Hands-on Mini Project: </span>
                          <span>{item.practical_exercise}</span>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center space-x-4 pt-1 text-xs">
                      {item.resource_url && (
                        <a
                          href={item.resource_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:underline flex items-center space-x-1 font-semibold"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                          <span>Curated Study Resource</span>
                        </a>
                      )}
                      <span className="text-slate-400 font-medium">~{item.estimated_duration_days} days estimated</span>
                    </div>
                  </div>
                </div>

                {/* Status Toggle Buttons */}
                <div className="flex items-center space-x-2 shrink-0 self-end md:self-start">
                  <button
                    onClick={() => handleStatusChange(item.id, 'in_progress')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                      isInProgress
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    In Progress
                  </button>
                  <button
                    onClick={() => handleStatusChange(item.id, isCompleted ? 'pending' : 'completed')}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-bold border transition-all flex items-center space-x-1 ${
                      isCompleted
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-white text-emerald-700 border-emerald-200 hover:bg-emerald-50'
                    }`}
                  >
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>{isCompleted ? 'Completed' : 'Mark Done'}</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
