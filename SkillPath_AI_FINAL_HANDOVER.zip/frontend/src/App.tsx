import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { LandingPage } from './pages/LandingPage';
import { AuthModal } from './pages/AuthModal';
import { DashboardView } from './pages/DashboardView';
import { ProfileView } from './pages/ProfileView';
import { SkillAnalysisView } from './pages/SkillAnalysisView';
import { CareerExploreView } from './pages/CareerExploreView';
import { CareerMatchView } from './pages/CareerMatchView';
import { RoadmapView } from './pages/RoadmapView';
import { AssessmentView } from './pages/AssessmentView';
import { ResourceLibraryView } from './pages/ResourceLibraryView';
import { ProgressAnalyticsView } from './pages/ProgressAnalyticsView';
import { AIMentorView } from './pages/AIMentorView';
import { AgentMonitorView } from './pages/AgentMonitorView';
import { SettingsView } from './pages/SettingsView';

const MainLayout: React.FC = () => {
  const { user } = useAuth();
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [selectedCareerId, setSelectedCareerId] = useState<number>(1);

  const handleNavigate = (tab: string) => {
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectCareerToMatch = (careerId: number) => {
    setSelectedCareerId(careerId);
    setCurrentTab('career-match');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      <Navbar
        currentTab={currentTab}
        setCurrentTab={handleNavigate}
        onOpenAuth={() => setAuthModalOpen(true)}
      />

      <main className="flex-1">
        {currentTab === 'landing' && (
          <LandingPage
            onStart={() => handleNavigate('dashboard')}
            onOpenAuth={() => setAuthModalOpen(true)}
          />
        )}
        {currentTab === 'dashboard' && <DashboardView onNavigate={handleNavigate} />}
        {currentTab === 'profile' && <ProfileView />}
        {currentTab === 'skills' && <SkillAnalysisView onNavigate={handleNavigate} />}
        {currentTab === 'careers' && <CareerExploreView onSelectCareer={handleSelectCareerToMatch} />}
        {currentTab === 'career-match' && (
          <CareerMatchView
            initialCareerId={selectedCareerId}
            onNavigate={handleNavigate}
          />
        )}
        {currentTab === 'roadmap' && <RoadmapView />}
        {currentTab === 'assessments' && <AssessmentView onNavigate={handleNavigate} />}
        {currentTab === 'resources' && <ResourceLibraryView />}
        {currentTab === 'analytics' && <ProgressAnalyticsView />}
        {currentTab === 'mentor' && <AIMentorView />}
        {currentTab === 'agents' && <AgentMonitorView />}
        {currentTab === 'settings' && <SettingsView />}
      </main>

      <footer className="bg-white border-t border-slate-200 py-6 mt-12 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>SkillPath AI • Developed for PromptWars X RTC Competition</span>
          <div className="flex items-center space-x-4 font-semibold text-slate-600">
            <button onClick={() => handleNavigate('settings')} className="hover:text-blue-600">System Specs</button>
            <button onClick={() => handleNavigate('agents')} className="hover:text-blue-600">6 Agents</button>
            <a href="http://127.0.0.1:8000/docs" target="_blank" rel="noopener noreferrer" className="hover:text-blue-600">FastAPI Docs</a>
          </div>
        </div>
      </footer>

      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={() => {
          setAuthModalOpen(false);
          handleNavigate('dashboard');
        }}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <MainLayout />
    </AuthProvider>
  );
}
