import {
  User, LearnerProfile, Skill, LearnerSkill, CareerRole, CareerMatchResult,
  LearningRoadmap, RoadmapVersion, RoadmapItem, LearningResource,
  Assessment, AssessmentAttempt, MentorMessage, AgentExecution, ProgressOverview
} from '../types';

const API_BASE = '/api';

function getAuthHeader(): Record<string, string> {
  const token = localStorage.getItem('skillpath_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const headers = {
    'Content-Type': 'application/json',
    ...getAuthHeader(),
    ...(options.headers || {})
  };

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers
  });

  if (!response.ok) {
    let errorDetail = 'Network request failed';
    try {
      const err = await response.json();
      errorDetail = err.detail || err.message || errorDetail;
    } catch {
      // ignore json parse error
    }
    throw new Error(errorDetail);
  }

  return response.json();
}

export const api = {
  // Auth
  login: (data: any) => request<{ access_token: string; user: User }>('/auth/login', {
    method: 'POST',
    body: JSON.stringify(data)
  }),
  register: (data: any) => request<{ access_token: string; user: User }>('/auth/register', {
    method: 'POST',
    body: JSON.stringify(data)
  }),
  demoLogin: () => request<{ access_token: string; user: User }>('/auth/demo', {
    method: 'POST'
  }),
  getMe: () => request<User>('/auth/me'),

  // Profile
  getProfile: () => request<LearnerProfile>('/profile'),
  updateProfile: (data: Partial<LearnerProfile>) => request<LearnerProfile>('/profile', {
    method: 'PUT',
    body: JSON.stringify(data)
  }),

  // Skills
  getAllSkills: () => request<Skill[]>('/skills'),
  getMySkills: () => request<LearnerSkill[]>('/skills/my'),
  batchUpdateSkills: (skills: Array<{ skill_name: string; proficiency_level: string; evidence_source?: string }>) =>
    request('/skills/batch-update', {
      method: 'POST',
      body: JSON.stringify({ skills })
    }),
  getSkillAnalysis: () => request<any>('/skills/analysis'),

  // Careers
  getAllCareers: () => request<CareerRole[]>('/careers'),
  getCareer: (id: number) => request<CareerRole>(`/careers/${id}`),
  matchCareer: (id: number) => request<CareerMatchResult>(`/careers/match/${id}`),
  changeCareerGoal: (newCareerId: number) => request<any>('/careers/goal', {
    method: 'POST',
    body: JSON.stringify({ new_career_id: newCareerId })
  }),

  // Roadmaps
  getCurrentRoadmap: () => request<LearningRoadmap>('/roadmaps/current'),
  getRoadmapVersions: () => request<RoadmapVersion[]>('/roadmaps/versions'),
  updateItemStatus: (itemId: number, status: string) => request<RoadmapItem>(`/roadmaps/items/${itemId}`, {
    method: 'PATCH',
    body: JSON.stringify({ status })
  }),
  regenerateRoadmap: () => request<any>('/roadmaps/generate', { method: 'POST' }),

  // Assessments
  listAssessments: () => request<Assessment[]>('/assessments'),
  getAssessment: (id: number) => request<Assessment>(`/assessments/${id}`),
  submitAssessment: (assessmentId: number, answers: Record<number, number>) =>
    request<AssessmentAttempt>('/assessments/submit', {
      method: 'POST',
      body: JSON.stringify({ assessment_id: assessmentId, answers })
    }),
  getMyAttempts: () => request<AssessmentAttempt[]>('/assessments/history/my'),

  // Resources
  listResources: (skillName?: string, difficulty?: string) => {
    const params = new URLSearchParams();
    if (skillName) params.append('skill_name', skillName);
    if (difficulty) params.append('difficulty', difficulty);
    const query = params.toString() ? `?${params.toString()}` : '';
    return request<LearningResource[]>(`/resources${query}`);
  },

  // Mentor
  sendMentorMessage: (message: string) => request<MentorMessage>('/mentor/chat', {
    method: 'POST',
    body: JSON.stringify({ message })
  }),
  getMentorHistory: () => request<MentorMessage[]>('/mentor/history'),

  // Agents
  getAgentsStatus: () => request<any[]>('/agents/status'),
  getAgentExecutions: (limit: number = 50) => request<AgentExecution[]>(`/agents/executions?limit=${limit}`),
  triggerAgentWorkflow: () => request<any>('/agents/workflow', { method: 'POST' }),

  // Progress
  getProgressOverview: () => request<ProgressOverview>('/progress/overview'),
};
