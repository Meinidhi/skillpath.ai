export interface User {
  id: number;
  email: string;
  full_name: string;
  is_active: boolean;
  is_demo: boolean;
  created_at: string;
}

export interface LearnerProfile {
  id: number;
  user_id: number;
  education: string;
  institution: string;
  academic_year: string;
  experience_level: string;
  target_career_id: number | null;
  target_career_title?: string;
  preferred_learning_style: string;
  soft_skills: string[];
  certifications: Array<{ title: string; issuer: string; year: number }>;
  projects: Array<{ title: string; description: string; technologies: string[] }>;
  created_at: string;
  updated_at: string;
}

export interface Skill {
  id: number;
  name: string;
  category: string;
  description?: string;
}

export interface LearnerSkill {
  id: number;
  skill_id: number;
  skill_name: string;
  category: string;
  proficiency_level: "Beginner" | "Intermediate" | "Advanced" | "Expert";
  evidence_source: string;
  confidence_level: number;
  last_assessed_date: string;
}

export interface CareerRequirement {
  id: number;
  skill_id: number;
  skill_name: string;
  required_proficiency: string;
  importance: "Critical" | "High" | "Medium" | "Nice-to-have";
  prerequisite_skills: string[];
}

export interface CareerRole {
  id: number;
  title: string;
  description: string;
  category: string;
  average_salary: string;
  growth_rate: string;
  requirements: CareerRequirement[];
}

export interface CareerMatchSkillDetail {
  skill_name: string;
  status: "meets" | "underdeveloped" | "missing";
  required_proficiency: string;
  current_proficiency: string | null;
  importance: string;
  confidence: number;
}

export interface CareerMatchResult {
  career_id: number;
  career_title: string;
  career_readiness_score: number;
  formula_breakdown: string;
  meeting_skills: CareerMatchSkillDetail[];
  underdeveloped_skills: CareerMatchSkillDetail[];
  missing_skills: CareerMatchSkillDetail[];
  total_required: number;
  critical_missing: string[];
}

export interface RoadmapItem {
  id: number;
  skill_id: number;
  skill_name: string;
  title: string;
  learning_objective: string;
  priority: "Critical" | "High" | "Medium" | "Low";
  difficulty: string;
  estimated_duration_days: number;
  status: "pending" | "in_progress" | "completed" | "needs_revision";
  resource_url?: string;
  practical_exercise?: string;
  order_index: number;
  completed_at?: string | null;
}

export interface RoadmapVersion {
  id: number;
  version_number: number;
  change_trigger: string;
  change_reason?: string;
  summary?: string;
  created_at: string;
  items: RoadmapItem[];
}

export interface LearningRoadmap {
  id: number;
  career_id: number;
  career_title: string;
  current_version: number;
  is_active: boolean;
  current_items: RoadmapItem[];
  versions: RoadmapVersion[];
}

export interface LearningResource {
  id: number;
  skill_id: number;
  skill_name: string;
  title: string;
  url: string;
  provider: string;
  resource_type: string;
  difficulty: string;
  estimated_hours: number;
  rating: number;
}

export interface AssessmentQuestion {
  id: number;
  question_text: string;
  options: string[];
  concept_tag: string;
}

export interface Assessment {
  id: number;
  skill_id: number;
  skill_name: string;
  title: string;
  category: string;
  difficulty: string;
  pass_score: number;
  questions_count?: number;
  questions?: AssessmentQuestion[];
}

export interface AssessmentAttempt {
  id: number;
  assessment_id: number;
  skill_name: string;
  score: number;
  total_questions: number;
  correct_count: number;
  passed: boolean;
  weak_concepts: string[];
  attempted_at: string;
  explanations?: Array<{
    question_id: number;
    question_text: string;
    user_choice: number | null;
    correct_choice: number;
    is_correct: boolean;
    explanation: string;
    concept_tag: string;
  }>;
  adaptation_triggered?: boolean;
  adaptation_summary?: string;
}

export interface MentorMessage {
  id: number;
  message: string;
  sender: "user" | "mentor";
  context_metadata: Record<string, any>;
  timestamp: string;
}

export interface AgentExecution {
  id: number;
  workflow_id: string;
  agent_name: string;
  responsibility: string;
  status: string;
  input_summary?: string;
  output_summary?: string;
  execution_time_ms: number;
  timestamp: string;
}

export interface ProgressOverview {
  career_readiness_score: number;
  target_career: string;
  overall_progress_pct: number;
  skills_mastered_count: number;
  skills_in_progress_count: number;
  total_skills_count: number;
  assessments_completed_count: number;
  average_assessment_score: number;
  roadmap_completion_pct: number;
  active_tasks_count: number;
  recent_activities: Array<{
    title: string;
    description: string;
    timestamp: string;
    status: string;
  }>;
  upcoming_tasks: RoadmapItem[];
  skill_radar_data: Array<{
    category: string;
    current: number;
    target: number;
  }>;
  history_trend: Array<{
    milestone: string;
    readiness: number;
  }>;
}
